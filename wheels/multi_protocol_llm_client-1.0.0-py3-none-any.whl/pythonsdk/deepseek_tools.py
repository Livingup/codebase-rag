from __future__ import annotations

import urllib.parse
from typing import Optional, TypedDict

from .base_client import ClientConfig, RequestOptions
from .errors import ErrorKind, LLMClientError
from .json_api_client import BaseJsonApiClient
from .transport import AsyncHttpTransport
from .retry import BackoffStrategy

DEFAULT_DEEPSEEK_TOOLS_BASE_URL = "https://api.deepseek.com"

SEARCH_PATH = "/v1/tools/search"
FETCH_PATH = "/v1/tools/fetch"

# Wire-level request/response types (docs/DEEPSEEK_TOOLS_API.md Sections 2-3).
# TypedDicts are structural hints over raw dicts — unknown fields pass through.


class DeepSeekSearchRequest(TypedDict, total=False):
    query: str
    count: int
    ori_question: Optional[str]
    localization: str
    need_content: bool


class DeepSeekSearchResultItem(TypedDict, total=False):
    rerank_score: float
    title: str
    url: str
    snippet: str
    summary: str
    content: str
    site_name: Optional[str]
    site_icon: Optional[str]
    date: Optional[str]
    authority: int


class DeepSeekSearchResponse(TypedDict):
    results: list[DeepSeekSearchResultItem]


class DeepSeekFetchResult(TypedDict, total=False):
    title: str
    content: str


def _bad_request(message: str) -> LLMClientError:
    return LLMClientError(
        kind=ErrorKind.BAD_REQUEST,
        message=message,
        is_retryable=False,
        attempt=0,
    )


class DeepSeekToolsClient(BaseJsonApiClient):
    """
    Client for DeepSeek's web Search & Fetch tool APIs (FR: DEEPSEEK_TOOLS_API.md).

    Read-only JSON APIs sharing the DeepSeek Bearer auth. Retries transient
    failures (408/429/5xx) per the SDK RetryPolicy; other 4xx fail fast.
    Request parameters are validated locally (BAD_REQUEST, attempt=0) before
    any network round-trip.
    """

    def __init__(
        self,
        config: ClientConfig,
        transport: Optional[AsyncHttpTransport] = None,
        backoff_strategy: Optional[BackoffStrategy] = None,
    ) -> None:
        super().__init__(config=config, transport=transport, backoff_strategy=backoff_strategy)

    @property
    def provider_name(self):
        return "deepseek"

    def _base_url(self) -> str:
        return self._config.base_url or DEFAULT_DEEPSEEK_TOOLS_BASE_URL

    def _auth_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._config.api_key}"}

    # ------------------------------------------------------------- search

    async def search(
        self,
        query: str,
        *,
        count: Optional[int] = None,
        ori_question: Optional[str] = None,
        localization: Optional[str] = None,
        need_content: bool = False,
        options: Optional[RequestOptions] = None,
    ) -> DeepSeekSearchResponse:
        """Searches the web by query (Section 2). Returns `{"results": [...]}`;
        a successful search with no matches returns an empty list."""
        if not isinstance(query, str) or not query.strip() or len(query) > 128:
            raise _bad_request("query must be 1-128 non-blank Unicode characters")
        if count is not None and not (1 <= count <= 50):
            raise _bad_request("count must be between 1 and 50")
        if ori_question is not None and (not ori_question.strip() or len(ori_question) > 128):
            raise _bad_request("ori_question must be 1-128 non-blank characters (or None)")

        body: dict = {"query": query}
        if count is not None:
            body["count"] = count
        if ori_question is not None:
            body["ori_question"] = ori_question
        if localization:
            body["localization"] = localization
        if need_content:
            body["need_content"] = True

        payload = await self.post_json(SEARCH_PATH, body, options=options)
        results = payload.get("results")
        if not isinstance(results, list):
            raise LLMClientError(
                kind=ErrorKind.PROTOCOL_ERROR,
                message="Search response must contain a 'results' array",
                is_retryable=False,
                attempt=0,
            )
        return {"results": results}

    # -------------------------------------------------------------- fetch

    async def fetch(
        self,
        url: str,
        *,
        options: Optional[RequestOptions] = None,
    ) -> DeepSeekFetchResult:
        """Fetches a single page as Markdown (Section 3)."""
        if not isinstance(url, str) or not url or len(url) > 8192:
            raise _bad_request("url must be a non-empty string of at most 8192 chars")
        parsed = urllib.parse.urlsplit(url)
        if parsed.scheme not in ("http", "https") or not parsed.hostname:
            raise _bad_request("url must be an HTTP/HTTPS URL with a host")
        if parsed.username is not None or parsed.password is not None:
            raise _bad_request("url must not carry a username or password")

        payload = await self.post_json(FETCH_PATH, {"url": url}, options=options)
        return {
            "title": str(payload.get("title", "")),
            "content": str(payload.get("content", "")),
        }
