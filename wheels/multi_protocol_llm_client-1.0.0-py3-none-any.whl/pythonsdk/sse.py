from __future__ import annotations

import codecs
from dataclasses import dataclass
from typing import Optional


@dataclass(frozen=True)
class SseEventFrame:
    """Represents a single parsed Server-Sent Events (SSE) frame."""

    event: Optional[str]
    data: str
    id: Optional[str] = None
    retry: Optional[int] = None


class ChunkSafeSseParser:
    """
    Stateful, zero-buffering incremental SSE parser (NFR-3).
    Safely handles:
    1. Multi-byte UTF-8 characters split across arbitrary TCP byte chunks.
    2. Partial lines split across chunks.
    3. Standard LF (\\n), CRLF (\\r\\n), and CR (\\r) line endings, including a
       CRLF pair whose \\r and \\n land in different TCP chunks.
    4. Multi-line `data:` fields concatenated with \\n.
    5. SSE comment keep-alive lines starting with `:`.
    6. A leading UTF-8 BOM, which the SSE spec requires to be ignored.
    """

    def __init__(self) -> None:
        self._utf8_decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
        self._text_buffer: str = ""
        self._current_event: Optional[str] = None
        self._current_data_lines: list[str] = []
        self._current_id: Optional[str] = None
        self._current_retry: Optional[int] = None
        self._checked_bom: bool = False

    def feed_bytes(self, raw_bytes: bytes, final: bool = False) -> tuple[str, list[SseEventFrame]]:
        """
        Decodes raw TCP bytes incrementally and returns `(decoded_text_chunk, parsed_frames)`.
        """
        decoded_text = self._utf8_decoder.decode(raw_bytes, final=final)
        frames = self.feed_text(decoded_text, final=final)
        return decoded_text, frames

    def feed_text(self, text_chunk: str, final: bool = False) -> list[SseEventFrame]:
        """Feeds decoded UTF-8 text and yields all completed SSE event frames."""
        if text_chunk:
            self._text_buffer += text_chunk

        # Strip a UTF-8 BOM at the very start of the stream exactly once.
        if not self._checked_bom:
            if not self._text_buffer:
                return []
            self._checked_bom = True
            if self._text_buffer.startswith("\ufeff"):
                self._text_buffer = self._text_buffer[1:]
                if not self._text_buffer:
                    return []

        frames: list[SseEventFrame] = []

        if final:
            # Normalize the entire remaining buffer; a trailing lone \r is a
            # line terminator and produces the closing blank line.
            searchable = self._text_buffer.replace("\r\n", "\n").replace("\r", "\n")
            self._text_buffer = ""
            for line in searchable.split("\n"):
                frame = self._process_line(line)
                if frame is not None:
                    frames.append(frame)
            # A buffer without a trailing blank line still holds a pending
            # event that must be dispatched at EOF.
            flushed = self._flush_current_event()
            if flushed is not None:
                frames.append(flushed)
            return frames

        # A trailing "\r" is ambiguous (CR terminator vs first half of CRLF);
        # hold it back until the next chunk arrives so it is never split into
        # two line terminators.
        searchable = self._text_buffer
        hold = ""
        if searchable.endswith("\r"):
            searchable = searchable[:-1]
            hold = "\r"
            if not searchable:
                return frames

        searchable = searchable.replace("\r\n", "\n").replace("\r", "\n")
        parts = searchable.split("\n")
        # Everything before the last \n is a complete line; the remainder is
        # the still-unfinished tail (plus the held-back \r).
        self._text_buffer = parts.pop() + hold

        for line in parts:
            frame = self._process_line(line)
            if frame is not None:
                frames.append(frame)

        return frames

    def _process_line(self, line: str) -> Optional[SseEventFrame]:
        # Empty line marks the end of an SSE event block
        if line == "":
            return self._flush_current_event()

        # Comment line (e.g., `: ping`)
        if line.startswith(":"):
            return None

        if ":" in line:
            field_name, value = line.split(":", 1)
            if value.startswith(" "):
                value = value[1:]
        else:
            field_name, value = line, ""

        if field_name == "event":
            self._current_event = value
        elif field_name == "data":
            self._current_data_lines.append(value)
        elif field_name == "id":
            self._current_id = value
        elif field_name == "retry":
            try:
                self._current_retry = int(value)
            except ValueError:
                pass

        return None

    def _flush_current_event(self) -> Optional[SseEventFrame]:
        # Per the SSE spec, an event with no `data:` field is not dispatched.
        if not self._current_data_lines:
            return None

        data_str = "\n".join(self._current_data_lines)
        frame = SseEventFrame(
            event=self._current_event,
            data=data_str,
            id=self._current_id,
            retry=self._current_retry,
        )
        self._current_event = None
        self._current_data_lines = []
        self._current_id = None
        self._current_retry = None
        return frame
