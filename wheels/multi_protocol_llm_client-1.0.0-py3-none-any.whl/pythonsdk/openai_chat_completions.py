"""
OpenAI `POST /v1/chat/completions` protocol client
(docs/OPENAI_CHAT_COMPLETIONS_API.md).

The Chat Completions SSE stream carries *untyped* `data:` JSON frames
(`object: "chat.completion.chunk"`) terminated by the literal `data: [DONE]`
sentinel — there are no `event:` names and no explicit block boundaries.
The state machine therefore synthesizes stage boundaries the same way the
Gemini adapter does (Section 5.4.3): it tracks the currently open stage per
`choices[i]` and closes it whenever a different delta field arrives, when
`finish_reason` is set, or at EOF.

Industry-standard reasoning extensions (`delta.reasoning_content` /
`delta.reasoning`, docs Section 4.2) are mapped onto the unified
`thinking_*` lifecycle so one client covers both the official OpenAI
endpoint (no thinking text in chat completions) and every
OpenAI-compatible gateway (DeepSeek / vLLM / OpenRouter / ...).
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal, Mapping, Optional, Sequence, TypedDict, Union

from .base_client import (
    BaseProtocolClient,
    ClientConfig,
    ProtocolStreamStateMachine,
    RequestOptions,
    to_serializable_dict,
)
from .errors import ErrorKind, LLMClientError
from .events import (
    LLMStreamEvent,
    ResponseCompleteEvent,
    ResponseStartEvent,
    TextDeltaEvent,
    TextStartEvent,
    TextStopEvent,
    ThinkingDeltaEvent,
    ThinkingStartEvent,
    ThinkingStopEvent,
    TokenUsage,
    ToolCallDeltaEvent,
    ToolCallStartEvent,
    ToolCallStopEvent,
    AudioStartEvent,
    AudioDeltaEvent,
    AudioStopEvent,
)
from .inspector import ProviderName
from .retry import BackoffStrategy
from .sse import SseEventFrame
from .transport import AsyncHttpTransport

DEFAULT_OPENAI_CHAT_COMPLETIONS_BASE_URL = "https://api.openai.com/v1"

# ============================================================================
# 1. Content Part Types (docs Section 2.3)
# ============================================================================


class TextContentPart(TypedDict, total=False):
    type: Literal["text"]
    text: str


class ImageUrlObject(TypedDict, total=False):
    url: str
    detail: Literal["auto", "low", "high"]


class ImageUrlContentPart(TypedDict, total=False):
    type: Literal["image_url"]
    image_url: ImageUrlObject


class InputAudioData(TypedDict):
    data: str
    format: Literal["wav", "mp3"]


class InputAudioContentPart(TypedDict, total=False):
    type: Literal["input_audio"]
    input_audio: InputAudioData


class FileContentObject(TypedDict, total=False):
    file_id: str
    file_data: str
    filename: str


class FileContentPart(TypedDict, total=False):
    type: Literal["file"]
    file: FileContentObject


class RefusalContentPart(TypedDict, total=False):
    type: Literal["refusal"]
    refusal: str


UserContentPart = Union[
    TextContentPart,
    ImageUrlContentPart,
    InputAudioContentPart,
    FileContentPart,
    dict[str, Any],
]

AssistantContentPart = Union[TextContentPart, RefusalContentPart, dict[str, Any]]

TextOrRefusalPart = Union[TextContentPart, RefusalContentPart, dict[str, Any]]

# ============================================================================
# 2. Message Param Types (docs Section 2.3)
# ============================================================================


class ChatCompletionSystemMessageParam(TypedDict, total=False):
    role: Literal["system"]
    name: str
    content: Union[str, Sequence[TextContentPart]]


class ChatCompletionDeveloperMessageParam(TypedDict, total=False):
    role: Literal["developer"]
    name: str
    content: Union[str, Sequence[TextContentPart]]


class ChatCompletionUserMessageParam(TypedDict, total=False):
    role: Literal["user"]
    name: str
    content: Union[str, Sequence[UserContentPart]]


class ChatCompletionAudioReference(TypedDict, total=False):
    """Replay form of a previously generated audio block (id only)."""

    id: str


class ChatCompletionFunctionToolCall(TypedDict, total=False):
    """Native assistant.tool_calls[i] entry for `function` tools."""

    id: str
    type: Literal["function"]
    function: "ChatCompletionFunctionCallObject"


class ChatCompletionCustomToolCall(TypedDict, total=False):
    """Native assistant.tool_calls[i] entry for `custom` tools."""

    id: str
    type: Literal["custom"]
    custom: "ChatCompletionCustomCallObject"


class ChatCompletionFunctionCallObject(TypedDict, total=False):
    name: str
    arguments: str


class ChatCompletionCustomCallObject(TypedDict, total=False):
    name: str
    input: str


AssistantToolCall = Union[
    ChatCompletionFunctionToolCall,
    ChatCompletionCustomToolCall,
    dict[str, Any],
]


class ChatCompletionAssistantMessageParam(TypedDict, total=False):
    role: Literal["assistant"]
    name: str
    content: Optional[Union[str, Sequence[AssistantContentPart]]]
    refusal: Optional[str]
    audio: ChatCompletionAudioReference
    tool_calls: Sequence[AssistantToolCall]
    # Industry-standard reasoning replay fields (docs Section 4.2): DeepSeek
    # style `reasoning_content` / OpenRouter style `reasoning`. The state
    # machine echoes back whichever field name the gateway itself used.
    reasoning_content: str
    reasoning: str


class ChatCompletionToolMessageParam(TypedDict, total=False):
    role: Literal["tool"]
    tool_call_id: str
    content: Union[str, Sequence[TextContentPart]]


class ChatCompletionFunctionMessageParam(TypedDict, total=False):
    """Legacy `function` role (deprecated but still accepted)."""

    role: Literal["function"]
    name: str
    content: Optional[str]


ChatCompletionMessageParam = Union[
    ChatCompletionSystemMessageParam,
    ChatCompletionDeveloperMessageParam,
    ChatCompletionUserMessageParam,
    ChatCompletionAssistantMessageParam,
    ChatCompletionToolMessageParam,
    ChatCompletionFunctionMessageParam,
    dict[str, Any],
]

# ============================================================================
# 3. Tool Definitions & Tool Choice (docs Sections 2.4 / 2.5)
# ============================================================================


class ChatCompletionFunctionObject(TypedDict, total=False):
    name: str
    description: str
    strict: bool
    parameters: dict[str, Any]


class ChatCompletionFunctionTool(TypedDict, total=False):
    type: Literal["function"]
    function: ChatCompletionFunctionObject


class ChatCompletionCustomToolGrammarFormat(TypedDict, total=False):
    type: Literal["grammar"]
    syntax: Literal["lark", "regex"]
    definition: str


class ChatCompletionCustomToolTextFormat(TypedDict, total=False):
    type: Literal["text"]


class ChatCompletionCustomToolObject(TypedDict, total=False):
    name: str
    description: str
    format: Union[
        ChatCompletionCustomToolTextFormat,
        ChatCompletionCustomToolGrammarFormat,
    ]


class ChatCompletionCustomTool(TypedDict, total=False):
    type: Literal["custom"]
    custom: ChatCompletionCustomToolObject


ChatCompletionTool = Union[
    ChatCompletionFunctionTool,
    ChatCompletionCustomTool,
    dict[str, Any],
]

ChatCompletionToolChoice = Union[
    Literal["none", "auto", "required"],
    Mapping[str, Any],
]

# ============================================================================
# 4. Response Format / Web Search / Prediction / Audio configs (docs 2.6/2.7)
# ============================================================================


class ChatCompletionResponseFormatText(TypedDict, total=False):
    type: Literal["text"]


class ChatCompletionResponseFormatJsonObject(TypedDict, total=False):
    type: Literal["json_object"]


class ChatCompletionJsonSchemaFormat(TypedDict, total=False):
    name: str
    description: str
    strict: bool
    schema: dict[str, Any]


class ChatCompletionResponseFormatJsonSchema(TypedDict, total=False):
    type: Literal["json_schema"]
    json_schema: ChatCompletionJsonSchemaFormat


ChatCompletionResponseFormat = Union[
    ChatCompletionResponseFormatText,
    ChatCompletionResponseFormatJsonObject,
    ChatCompletionResponseFormatJsonSchema,
    Mapping[str, Any],
]


class ChatCompletionUserLocationApproximate(TypedDict, total=False):
    country: str
    region: str
    city: str
    timezone: str


class ChatCompletionUserLocation(TypedDict, total=False):
    type: Literal["approximate"]
    approximate: ChatCompletionUserLocationApproximate


class ChatCompletionWebSearchOptions(TypedDict, total=False):
    search_context_size: Literal["low", "medium", "high"]
    user_location: ChatCompletionUserLocation


class ChatCompletionPrediction(TypedDict, total=False):
    type: Literal["content"]
    content: Union[str, Sequence[TextContentPart]]


class ChatCompletionAudioConfig(TypedDict, total=False):
    voice: str
    format: str


class ChatCompletionStreamOptions(TypedDict, total=False):
    include_usage: bool
    include_obfuscation: bool


# ============================================================================
# 5. Top-Level Request (docs Section 2.1 / 2.2)
# ============================================================================


@dataclass
class OpenAIChatCompletionsRequest:
    """
    Complete, non-simplified native request payload for OpenAI
    `POST /v1/chat/completions` (docs/OPENAI_CHAT_COMPLETIONS_API.md).
    """

    model: str
    messages: Sequence[ChatCompletionMessageParam]
    stream_options: Optional[Union[ChatCompletionStreamOptions, dict[str, Any]]] = None
    store: Optional[bool] = None
    metadata: Optional[Mapping[str, str]] = None
    reasoning_effort: Optional[
        Literal["none", "minimal", "low", "medium", "high", "xhigh"]
    ] = None
    verbosity: Optional[Literal["low", "medium", "high"]] = None
    max_completion_tokens: Optional[int] = None
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    n: Optional[int] = None
    stop: Optional[Union[str, Sequence[str]]] = None
    presence_penalty: Optional[float] = None
    frequency_penalty: Optional[float] = None
    logit_bias: Optional[Mapping[str, int]] = None
    logprobs: Optional[bool] = None
    top_logprobs: Optional[int] = None
    seed: Optional[int] = None
    modalities: Optional[Sequence[Literal["text", "audio"]]] = None
    audio: Optional[ChatCompletionAudioConfig] = None
    prediction: Optional[ChatCompletionPrediction] = None
    web_search_options: Optional[ChatCompletionWebSearchOptions] = None
    response_format: Optional[ChatCompletionResponseFormat] = None
    tools: Optional[Sequence[ChatCompletionTool]] = None
    tool_choice: Optional[ChatCompletionToolChoice] = None
    parallel_tool_calls: Optional[bool] = None
    prompt_cache_key: Optional[str] = None
    prompt_cache_retention: Optional[Literal["in_memory", "24h"]] = None
    service_tier: Optional[Literal["auto", "default", "flex", "priority"]] = None
    safety_identifier: Optional[str] = None
    user: Optional[str] = None
    extra_fields: Mapping[str, Any] = field(default_factory=dict)


# ============================================================================
# 6. Response / Chunk Object Types (docs Sections 3 / 4)
# ============================================================================


class ChatCompletionMessage(TypedDict, total=False):
    role: Literal["assistant"]
    content: Optional[Union[str, Sequence[AssistantContentPart]]]
    refusal: Optional[str]
    annotations: list[dict[str, Any]]
    audio: dict[str, Any]
    tool_calls: list[AssistantToolCall]


class ChatCompletionChoice(TypedDict, total=False):
    index: int
    message: ChatCompletionMessage
    finish_reason: Optional[
        Literal["stop", "length", "tool_calls", "content_filter", "function_call"]
    ]
    logprobs: Optional[dict[str, Any]]


class ChatCompletionUsageObject(TypedDict, total=False):
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    prompt_tokens_details: dict[str, int]
    completion_tokens_details: dict[str, int]


class ChatCompletionObject(TypedDict, total=False):
    id: str
    object: Literal["chat.completion"]
    created: int
    model: str
    service_tier: Optional[str]
    system_fingerprint: Optional[str]
    choices: list[ChatCompletionChoice]
    usage: Optional[ChatCompletionUsageObject]


class ChatCompletionChunkDelta(TypedDict, total=False):
    role: str
    content: Optional[str]
    refusal: Optional[str]
    reasoning_content: Optional[str]
    reasoning: Optional[str]
    tool_calls: list[dict[str, Any]]
    audio: dict[str, Any]
    annotations: list[dict[str, Any]]


class ChatCompletionChunk(TypedDict, total=False):
    id: str
    object: Literal["chat.completion.chunk"]
    created: int
    model: str
    service_tier: Optional[str]
    system_fingerprint: Optional[str]
    choices: list[dict[str, Any]]
    usage: Optional[ChatCompletionUsageObject]


# ============================================================================
# 7. Stream State Machine (docs Section 4)
# ============================================================================


def _safe_int(value: Any, default: int) -> int:
    """Tolerates malformed wire values (e.g. `"index": null`)."""
    try:
        return int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return default


@dataclass
class _TrackedToolCall:
    """One accumulating `tool_calls` bucket, keyed by its wire `index`."""

    tool_index: int
    block_index: int
    call_id: str
    name: str
    tool_type: Literal["function", "custom"]
    args_buffer: list[str] = field(default_factory=list)

    def to_native_tool_call(self) -> dict[str, Any]:
        args = "".join(self.args_buffer)
        if self.tool_type == "custom":
            return {
                "id": self.call_id,
                "type": "custom",
                "custom": {"name": self.name, "input": args},
            }
        return {
            "id": self.call_id,
            "type": "function",
            "function": {"name": self.name, "arguments": args},
        }


@dataclass
class _ChoiceState:
    """Per-`choices[i]` accumulation state (supports n > 1)."""

    choice_index: int
    # Stage boundary synthesis: at most one of THINKING / TEXT is open at a
    # time; audio and tool calls live in their own blocks.
    open_stage: Literal["NONE", "THINKING", "TEXT"] = "NONE"
    thinking_block_index: Optional[int] = None
    thinking_buffer: list[str] = field(default_factory=list)
    reasoning_field: Optional[str] = None  # "reasoning_content" | "reasoning"
    text_block_index: Optional[int] = None
    text_buffer: list[str] = field(default_factory=list)
    refusal_buffer: list[str] = field(default_factory=list)
    tool_calls: dict[int, _TrackedToolCall] = field(default_factory=dict)
    annotations: list[Any] = field(default_factory=list)
    audio_started: bool = False
    audio_block_index: Optional[int] = None
    audio_id: Optional[str] = None
    audio_data_length: int = 0
    audio_transcript_buffer: list[str] = field(default_factory=list)
    finish_reason: Optional[str] = None
    closed: bool = False


ChatCompletionStreamItem = dict[str, Any]
ChatCompletionOutputPayload = list[dict[str, Any]]


class OpenAIChatCompletionsStateMachine(
    ProtocolStreamStateMachine[ChatCompletionStreamItem, ChatCompletionOutputPayload]
):
    """
    Maps the untyped `chat.completion.chunk` SSE stream onto the unified
    lifecycle events (docs Section 4; requirements Section 5.4).

    Boundary synthesis rules (chat completions has no explicit start/stop
    frames — the Gemini-style approach):

    * ``delta.reasoning_content ?? delta.reasoning`` opens (or continues) the
      THINKING stage; any other delta field closes it first.
    * ``delta.content`` / ``delta.refusal`` open (or continue) the TEXT stage;
      any other delta field closes it first.
    * The first frame of a ``delta.tool_calls[i]`` bucket carries ``id`` +
      name and fires ``tool_call_start`` immediately (FR-STATE-06);
      subsequent frames append argument fragments to that bucket.
    * ``finish_reason`` (or ``[DONE]`` / EOF) closes every open block of the
      choice and, on ``[DONE]``, emits ``response_complete`` whose ``output``
      is the assembled native assistant message per choice — directly
      appendable to the next turn's ``messages`` (stateless replay).
    """

    def __init__(self, audio_format: Optional[str] = None) -> None:
        self._audio_format = audio_format or "pcm16"
        self._response_id: str = ""
        self._model: str = ""
        self._response_started: bool = False
        self._emitted_complete: bool = False
        self._saw_done: bool = False
        self._saw_any_finish_reason: bool = False
        self._usage: Optional[TokenUsage] = None
        self._choices: dict[int, _ChoiceState] = {}
        self._next_block_index: int = 0

    # ------------------------------------------------------------------
    # ProtocolStreamStateMachine API
    # ------------------------------------------------------------------

    def process_frame(
        self,
        frame: SseEventFrame,
        trace_id: str,
        attempt: int,
    ) -> list[LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]]:
        raw_data = frame.data.strip()
        if not raw_data:
            return []

        if raw_data == "[DONE]":
            self._saw_done = True
            if self._emitted_complete:
                return []
            events = self._close_all_choices()
            events.append(self._build_response_complete())
            return events

        try:
            payload: dict[str, Any] = json.loads(raw_data)
            if not isinstance(payload, dict):
                raise ValueError("frame root is not a JSON object")
        except Exception as exc:
            raise LLMClientError(
                kind=ErrorKind.PROTOCOL_ERROR,
                message=f"Failed to parse chat.completion.chunk JSON frame: {exc}",
                is_retryable=False,
                attempt=attempt,
                raw_body=raw_data,
                cause=exc,
            ) from exc

        events: list[
            LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]
        ] = []

        # 1. In-stream error frame (gateway convention: {"error": {...}}).
        if "error" in payload and "choices" not in payload:
            events.extend(self._raise_in_stream_error(payload, attempt))
            return events

        # 2. First valid chunk -> response_start (FR-STATE-03).
        if not self._response_started:
            self._response_id = str(payload.get("id", ""))
            self._model = str(payload.get("model", ""))
            self._response_started = True
            events.append(
                ResponseStartEvent(
                    trace_id=trace_id,
                    attempt=attempt,
                    response_id=self._response_id,
                    model=self._model,
                )
            )

        # 3. Usage-only frame (choices == []; docs Section 4.3).
        usage_obj = payload.get("usage")
        if usage_obj is not None:
            self._usage = self._parse_usage(usage_obj)

        choices = payload.get("choices")
        if not isinstance(choices, list):
            return events

        for choice in choices:
            if not isinstance(choice, Mapping):
                continue
            choice_index = _safe_int(choice.get("index"), 0)
            state = self._choices.get(choice_index)
            if state is None:
                state = _ChoiceState(choice_index=choice_index)
                self._choices[choice_index] = state

            delta = choice.get("delta")
            if isinstance(delta, Mapping):
                events.extend(self._process_delta(state, delta, trace_id, attempt))

            finish_reason = choice.get("finish_reason")
            if finish_reason is not None and not state.closed:
                state.finish_reason = str(finish_reason)
                self._saw_any_finish_reason = True
                events.extend(self._close_choice(state))

        return events

    def finish_stream(
        self,
        trace_id: str,
        attempt: int,
    ) -> list[LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]]:
        if self._emitted_complete:
            return []
        if self._saw_any_finish_reason:
            # EOF without the [DONE] sentinel but after finish_reason: the
            # response is logically complete (e.g. a proxy dropped the tail);
            # complete tolerantly instead of failing the whole exchange.
            events = self._close_all_choices()
            events.append(self._build_response_complete())
            return events
        # A clean EOF without [DONE] and without any finish_reason means the
        # stream was truncated mid-generation — surface it as an error, never
        # as a fabricated "successful" zero-usage response.
        raise LLMClientError(
            kind=ErrorKind.PROTOCOL_ERROR,
            message="SSE stream ended without a [DONE] terminator or finish_reason",
            is_retryable=False,
            attempt=attempt,
        )

    # ------------------------------------------------------------------
    # Delta processing
    # ------------------------------------------------------------------

    def _process_delta(
        self,
        state: _ChoiceState,
        delta: Mapping[str, Any],
        trace_id: str,
        attempt: int,
    ) -> list[LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]]:
        events: list[
            LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]
        ] = []

        # --- 1. Thinking deltas (industry extension, docs Section 4.2) ---
        reasoning = delta.get("reasoning_content")
        reasoning_src: Optional[str] = None
        if reasoning is None:
            reasoning = delta.get("reasoning")
            if reasoning is not None:
                reasoning_src = "reasoning"
        else:
            reasoning_src = "reasoning_content"

        if isinstance(reasoning, str):
            if state.open_stage == "TEXT":
                events.extend(self._close_text_stage(state))
            if state.open_stage == "NONE":
                state.open_stage = "THINKING"
                state.thinking_block_index = self._alloc_block_index()
                if state.reasoning_field is None and reasoning_src is not None:
                    state.reasoning_field = reasoning_src
                events.append(
                    ThinkingStartEvent(
                        block_index=state.thinking_block_index,
                    )
                )
            if reasoning:
                state.thinking_buffer.append(reasoning)
                events.append(
                    ThinkingDeltaEvent(
                        block_index=state.thinking_block_index or 0,
                        delta=reasoning,
                    )
                )

        # --- 2. Ordinary text / refusal deltas ---
        content = delta.get("content")
        if isinstance(content, str):
            if state.open_stage == "THINKING":
                events.extend(self._close_thinking_stage(state))
            if state.open_stage == "NONE":
                state.open_stage = "TEXT"
                state.text_block_index = self._alloc_block_index()
                events.append(TextStartEvent(block_index=state.text_block_index))
            if content:
                state.text_buffer.append(content)
                events.append(
                    TextDeltaEvent(
                        block_index=state.text_block_index or 0,
                        delta=content,
                    )
                )

        refusal = delta.get("refusal")
        if isinstance(refusal, str) and refusal:
            if state.open_stage == "THINKING":
                events.extend(self._close_thinking_stage(state))
            if state.open_stage == "NONE":
                state.open_stage = "TEXT"
                state.text_block_index = self._alloc_block_index()
                events.append(TextStartEvent(block_index=state.text_block_index))
            state.refusal_buffer.append(refusal)
            events.append(
                TextDeltaEvent(
                    block_index=state.text_block_index or 0,
                    delta=refusal,
                )
            )

        # --- 3. Tool call deltas (docs Section 4.1: index-bucketed) ---
        tool_calls = delta.get("tool_calls")
        if isinstance(tool_calls, list):
            events.extend(self._process_tool_call_deltas(state, tool_calls))

        # --- 4. Audio output deltas (docs Section 4.1 delta.audio) ---
        audio = delta.get("audio")
        if isinstance(audio, Mapping):
            events.extend(self._process_audio_delta(state, audio))

        # --- 5. Annotation chunks (accumulate; delivered on text_stop /
        #     the assembled output message). ---
        annotations = delta.get("annotations")
        if isinstance(annotations, list):
            state.annotations.extend(annotations)

        return events

    def _process_tool_call_deltas(
        self,
        state: _ChoiceState,
        tool_calls: Sequence[Any],
    ) -> list[LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]]:
        events: list[
            LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]
        ] = []

        # Any tool-call activity closes the THINKING/TEXT stage first.
        if state.open_stage == "THINKING":
            events.extend(self._close_thinking_stage(state))
        elif state.open_stage == "TEXT":
            events.extend(self._close_text_stage(state))

        for tc in tool_calls:
            if not isinstance(tc, Mapping):
                continue
            tool_index = _safe_int(tc.get("index"), 0)
            tracked = state.tool_calls.get(tool_index)

            if tracked is None:
                # First frame of this index: carries id + type + name.
                tc_type = str(tc.get("type") or "function")
                if tc_type not in ("function", "custom"):
                    tc_type = "function"
                fn_obj = tc.get("function")
                custom_obj = tc.get("custom")
                if tc_type == "custom":
                    name = str(
                        (custom_obj or {}).get("name")
                        or (fn_obj or {}).get("name")
                        or ""
                    )
                else:
                    name = str(
                        (fn_obj or {}).get("name")
                        or (custom_obj or {}).get("name")
                        or ""
                    )
                tracked = _TrackedToolCall(
                    tool_index=tool_index,
                    block_index=self._alloc_block_index(),
                    call_id=str(tc.get("id") or f"call_{tool_index}"),
                    name=name,
                    tool_type=tc_type,  # type: ignore[arg-type]
                )
                state.tool_calls[tool_index] = tracked
                # FR-STATE-06: fire immediately upon name + callId.
                events.append(
                    ToolCallStartEvent(
                        block_index=tracked.block_index,
                        call_id=tracked.call_id,
                        name=tracked.name,
                        tool_type=tracked.tool_type,
                    )
                )

            # Argument fragment: function.arguments vs custom.input (docs 3.2.4).
            fn_obj = tc.get("function")
            if isinstance(fn_obj, Mapping) and fn_obj.get("arguments") is not None:
                fragment = str(fn_obj["arguments"] or "")
                if fragment:
                    tracked.args_buffer.append(fragment)
                    events.append(
                        ToolCallDeltaEvent(
                            block_index=tracked.block_index,
                            call_id=tracked.call_id,
                            arguments_delta=fragment,
                        )
                    )
            custom_obj = tc.get("custom")
            if isinstance(custom_obj, Mapping) and custom_obj.get("input") is not None:
                fragment = str(custom_obj["input"] or "")
                if fragment:
                    tracked.args_buffer.append(fragment)
                    events.append(
                        ToolCallDeltaEvent(
                            block_index=tracked.block_index,
                            call_id=tracked.call_id,
                            arguments_delta=fragment,
                        )
                    )

        return events

    def _process_audio_delta(
        self,
        state: _ChoiceState,
        audio: Mapping[str, Any],
    ) -> list[LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]]:
        events: list[
            LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]
        ] = []

        if not state.audio_started:
            state.audio_started = True
            state.audio_block_index = self._alloc_block_index()
            events.append(
                AudioStartEvent(
                    block_index=state.audio_block_index,
                    mime_type=self._audio_format,
                )
            )

        audio_id = audio.get("id")
        if audio_id is not None:
            state.audio_id = str(audio_id)

        data = audio.get("data")
        if isinstance(data, str) and data:
            state.audio_data_length += len(data)
            events.append(
                AudioDeltaEvent(
                    block_index=state.audio_block_index or 0,
                    audio_delta=data,
                    mime_type=self._audio_format,
                )
            )

        transcript = audio.get("transcript")
        if isinstance(transcript, str) and transcript:
            state.audio_transcript_buffer.append(transcript)

        return events

    # ------------------------------------------------------------------
    # Stage closing & output assembly
    # ------------------------------------------------------------------

    def _close_thinking_stage(
        self,
        state: _ChoiceState,
    ) -> list[LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]]:
        text = "".join(state.thinking_buffer)
        raw_item: dict[str, Any] = {"role": "assistant"}
        if state.reasoning_field is not None:
            raw_item[state.reasoning_field] = text
        else:
            raw_item["reasoning_content"] = text
        event = ThinkingStopEvent(
            block_index=state.thinking_block_index or 0,
            text=text,
            raw_item=raw_item,
        )
        state.open_stage = "NONE"
        state.thinking_block_index = None
        return [event]  # type: ignore[list-item]

    def _close_text_stage(
        self,
        state: _ChoiceState,
    ) -> list[LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]]:
        text = "".join(state.text_buffer) + "".join(state.refusal_buffer)
        raw_item: dict[str, Any] = {"role": "assistant", "content": text}
        if state.refusal_buffer:
            raw_item["refusal"] = "".join(state.refusal_buffer)
        if state.annotations:
            raw_item["annotations"] = list(state.annotations)
        event = TextStopEvent(
            block_index=state.text_block_index or 0,
            text=text,
            raw_item=raw_item,
        )
        state.open_stage = "NONE"
        state.text_block_index = None
        return [event]  # type: ignore[list-item]

    def _close_choice(
        self,
        state: _ChoiceState,
    ) -> list[LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]]:
        if state.closed:
            return []
        state.closed = True
        events: list[
            LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]
        ] = []
        if state.open_stage == "THINKING":
            events.extend(self._close_thinking_stage(state))
        elif state.open_stage == "TEXT":
            events.extend(self._close_text_stage(state))
        for tool_index in sorted(state.tool_calls):
            tracked = state.tool_calls[tool_index]
            events.append(
                ToolCallStopEvent(
                    block_index=tracked.block_index,
                    call_id=tracked.call_id,
                    name=tracked.name,
                    arguments_raw="".join(tracked.args_buffer),
                    raw_item=tracked.to_native_tool_call(),
                )
            )
        if state.audio_started:
            events.append(
                AudioStopEvent(
                    block_index=state.audio_block_index or 0,
                    mime_type=self._audio_format,
                    total_base64_length=state.audio_data_length,
                )
            )
        return events

    def _close_all_choices(
        self,
    ) -> list[LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]]:
        events: list[
            LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]
        ] = []
        for choice_index in sorted(self._choices):
            events.extend(self._close_choice(self._choices[choice_index]))
        return events

    def _assemble_assistant_message(self, state: _ChoiceState) -> dict[str, Any]:
        """Assembles the native assistant message for stateless replay:
        appendable verbatim to the next turn's ``messages`` array."""
        message: dict[str, Any] = {"role": "assistant"}

        reasoning_text = "".join(state.thinking_buffer)
        if reasoning_text:
            field = state.reasoning_field or "reasoning_content"
            message[field] = reasoning_text

        if state.text_buffer:
            message["content"] = "".join(state.text_buffer)
        elif state.tool_calls or state.audio_id is not None or state.refusal_buffer:
            # Tool-call / audio / refusal turns conventionally replay with
            # content: null (matching the non-streaming message shape).
            message["content"] = None
        else:
            message["content"] = ""

        if state.refusal_buffer:
            message["refusal"] = "".join(state.refusal_buffer)

        if state.tool_calls:
            message["tool_calls"] = [
                state.tool_calls[i].to_native_tool_call()
                for i in sorted(state.tool_calls)
            ]

        if state.audio_id is not None:
            message["audio"] = {"id": state.audio_id}

        if state.annotations:
            message["annotations"] = list(state.annotations)

        return message

    def _build_response_complete(
        self,
    ) -> LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]:
        self._emitted_complete = True
        output: ChatCompletionOutputPayload = [
            self._assemble_assistant_message(self._choices[i])
            for i in sorted(self._choices)
        ]
        first_choice = self._choices.get(0)
        stop_reason = first_choice.finish_reason if first_choice else None
        return ResponseCompleteEvent(
            response_id=self._response_id,
            stop_reason=stop_reason,
            usage=self._usage or TokenUsage(),
            output=output,
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _alloc_block_index(self) -> int:
        idx = self._next_block_index
        self._next_block_index += 1
        return idx

    @staticmethod
    def _parse_usage(usage_obj: Any) -> TokenUsage:
        if not isinstance(usage_obj, Mapping):
            return TokenUsage()
        prompt_tokens = _safe_int(usage_obj.get("prompt_tokens"), 0)
        completion_tokens = _safe_int(usage_obj.get("completion_tokens"), 0)
        total_tokens = _safe_int(
            usage_obj.get("total_tokens"), prompt_tokens + completion_tokens
        )
        prompt_details = usage_obj.get("prompt_tokens_details") or {}
        completion_details = usage_obj.get("completion_tokens_details") or {}
        cached = (
            _safe_int(prompt_details.get("cached_tokens"), 0)
            if isinstance(prompt_details, Mapping)
            else 0
        )
        reasoning = (
            _safe_int(completion_details.get("reasoning_tokens"), 0)
            if isinstance(completion_details, Mapping)
            else 0
        )
        return TokenUsage(
            input_tokens=prompt_tokens,
            output_tokens=completion_tokens,
            reasoning_tokens=reasoning,
            cache_read_input_tokens=cached,
            total_tokens=total_tokens,
            raw_usage=dict(usage_obj),
        )

    @staticmethod
    def _raise_in_stream_error(
        payload: Mapping[str, Any],
        attempt: int,
    ) -> list[LLMStreamEvent[ChatCompletionStreamItem, ChatCompletionOutputPayload]]:
        """Gateway-style in-stream ``{"error": {...}}`` frame classification
        (mirrors the /v1/responses `error` event handling)."""
        err_info = payload.get("error")
        if not isinstance(err_info, Mapping):
            err_info = dict(payload)
        code = str(
            err_info.get("code") or err_info.get("type") or "stream_error"
        )
        message = str(err_info.get("message") or "Chat Completions stream error")
        if code == "rate_limit_exceeded":
            kind, retryable = ErrorKind.RATE_LIMIT, True
        elif code == "overloaded" or code == "overloaded_error":
            kind, retryable = ErrorKind.OVERLOADED, True
        elif code == "server_error":
            kind, retryable = ErrorKind.SERVER_ERROR, True
        elif code in ("invalid_request_error", "invalid_prompt", "context_length_exceeded"):
            kind, retryable = ErrorKind.BAD_REQUEST, False
        else:
            kind, retryable = ErrorKind.PROTOCOL_ERROR, False
        raise LLMClientError(
            kind=kind,
            message=message,
            is_retryable=retryable,
            attempt=attempt,
            provider_error_code=code,
            raw_body=json.dumps(payload, ensure_ascii=False),
        )


# ============================================================================
# 8. Client
# ============================================================================


class OpenAIChatCompletionsClient(
    BaseProtocolClient[
        OpenAIChatCompletionsRequest,
        ChatCompletionStreamItem,
        ChatCompletionOutputPayload,
    ]
):
    """
    Dedicated client for OpenAI `POST /v1/chat/completions`
    (docs/OPENAI_CHAT_COMPLETIONS_API.md) — also the entry point for every
    OpenAI-compatible gateway (DeepSeek, vLLM, OpenRouter, ...) via
    ``base_url``.
    """

    def __init__(
        self,
        config: ClientConfig,
        transport: Optional[AsyncHttpTransport] = None,
        backoff_strategy: Optional[BackoffStrategy] = None,
    ) -> None:
        super().__init__(
            config=config,
            transport=transport,
            backoff_strategy=backoff_strategy,
        )

    @property
    def provider_name(self) -> ProviderName:
        return "openai"

    def _build_url_and_headers(
        self,
        request: OpenAIChatCompletionsRequest,
        options: RequestOptions,
    ) -> tuple[str, dict[str, str]]:
        base = (
            self._config.base_url
            or DEFAULT_OPENAI_CHAT_COMPLETIONS_BASE_URL
        ).rstrip("/")
        url = f"{base}/chat/completions"
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "Authorization": f"Bearer {self._config.api_key}",
        }
        for k, v in self._config.custom_headers.items():
            headers[k] = v
        if options.custom_headers:
            for k, v in options.custom_headers.items():
                headers[k] = v
        return url, headers

    def _serialize_request_to_root_dict(
        self,
        request: OpenAIChatCompletionsRequest,
        options: RequestOptions,
    ) -> dict[str, Any]:
        root: dict[str, Any] = {
            "model": request.model,
            "messages": to_serializable_dict(request.messages),
            "stream": True,
        }

        optional_fields = (
            "store",
            "metadata",
            "reasoning_effort",
            "verbosity",
            "max_completion_tokens",
            "max_tokens",
            "temperature",
            "top_p",
            "n",
            "stop",
            "presence_penalty",
            "frequency_penalty",
            "logit_bias",
            "logprobs",
            "top_logprobs",
            "seed",
            "modalities",
            "audio",
            "prediction",
            "web_search_options",
            "response_format",
            "tools",
            "tool_choice",
            "parallel_tool_calls",
            "prompt_cache_key",
            "prompt_cache_retention",
            "service_tier",
            "safety_identifier",
            "user",
        )
        for field_name in optional_fields:
            val = getattr(request, field_name)
            if val is not None:
                root[field_name] = to_serializable_dict(val)

        # Always request in-stream usage: response_complete.usage depends on
        # the usage-only chunk (docs Section 4.3) which only arrives when
        # stream_options.include_usage is true. User-provided options are
        # merged (never dropped); the whole key can still be replaced via
        # custom_body_json afterwards.
        stream_options: dict[str, Any] = dict(request.stream_options or {})
        stream_options["include_usage"] = True
        root["stream_options"] = stream_options

        if request.extra_fields:
            for k, v in request.extra_fields.items():
                root[k] = to_serializable_dict(v)

        return root

    def _create_state_machine(
        self,
        request: OpenAIChatCompletionsRequest,
    ) -> ProtocolStreamStateMachine[
        ChatCompletionStreamItem, ChatCompletionOutputPayload
    ]:
        audio_format: Optional[str] = None
        if isinstance(request.audio, Mapping):
            fmt = request.audio.get("format")
            if isinstance(fmt, str) and fmt:
                audio_format = fmt
        return OpenAIChatCompletionsStateMachine(audio_format=audio_format)
