from __future__ import annotations

import asyncio
import copy
import dataclasses
import json
import time
import uuid
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import (
    Any,
    AsyncIterator,
    Generic,
    Mapping,
    Optional,
    Sequence,
    TypeVar,
)

from .cancellation import CancellationToken, interruptible_sleep
from .errors import (
    ErrorKind,
    LLMClientError,
    classify_http_error,
    classify_stream_or_network_error,
)
from .events import LLMStreamEvent, RequestStartEvent, RetryingEvent
from .inspector import (
    ExchangeCompleteWireContext,
    HttpInspector,
    HttpInspectorDispatcher,
    ProviderName,
    RawStreamChunkContext,
    RequestWireContext,
    ResponseHeadersWireContext,
)
from .retry import (
    BackoffStrategy,
    ExponentialFullJitterBackoffStrategy,
    RetryPolicy,
)
from .sse import ChunkSafeSseParser, SseEventFrame
from .transport import AsyncHttpResponse, AsyncHttpTransport, AsyncioHttpTransport, TransportTimeouts

TRequest = TypeVar("TRequest")
TOutputItem = TypeVar("TOutputItem")
TOutputPayload = TypeVar("TOutputPayload")


def _now_ms() -> int:
    return int(time.time() * 1000)


def to_serializable_dict(obj: Any) -> Any:
    """
    Recursively converts dataclasses/mappings/lists into plain JSON-serializable
    structures. Only *dataclass* fields with a None value are omitted (omitting
    an unset optional field). Plain mappings supplied by the caller (tool inputs,
    JSON schemas, extra_fields...) are passed through verbatim: a semantic JSON
    null inside user data must survive serialization (NFR-2 field fidelity).
    """
    if dataclasses.is_dataclass(obj) and not isinstance(obj, type):
        result: dict[str, Any] = {}
        for f in dataclasses.fields(obj):
            val = getattr(obj, f.name)
            if val is not None:
                result[f.name] = to_serializable_dict(val)
        return result
    if isinstance(obj, Mapping):
        return {k: to_serializable_dict(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [to_serializable_dict(v) for v in obj]
    return obj


@dataclass(frozen=True)
class ClientConfig:
    """Client-level default configuration (FR-PROTO-04)."""

    api_key: str
    base_url: Optional[str] = None
    custom_headers: Mapping[str, str] = field(default_factory=dict)
    default_custom_body_json: Optional[str] = None
    retry_policy: RetryPolicy = field(default_factory=RetryPolicy)
    timeouts: TransportTimeouts = field(default_factory=TransportTimeouts)
    inspectors: Sequence[HttpInspector] = field(default_factory=tuple)


@dataclass(frozen=True)
class RequestOptions:
    """Per-request override options (cancellation, customBodyJson, headers, retry, inspectors)."""

    cancel_token: Optional[CancellationToken] = None
    custom_body_json: Optional[str] = None
    custom_headers: Optional[Mapping[str, str]] = None
    retry_policy: Optional[RetryPolicy] = None
    timeouts: Optional[TransportTimeouts] = None
    inspectors: Optional[Sequence[HttpInspector]] = None


class ProtocolStreamStateMachine(ABC, Generic[TOutputItem, TOutputPayload]):
    """
    State Pattern interface for transforming protocol-specific SSE frames
    into unified semantic `LLMStreamEvent` instances (Section 5.4).
    A fresh instance is created via Factory Method for every HTTP attempt.
    """

    @abstractmethod
    def process_frame(
        self,
        frame: SseEventFrame,
        trace_id: str,
        attempt: int,
    ) -> list[LLMStreamEvent[TOutputItem, TOutputPayload]]:
        raise NotImplementedError

    @abstractmethod
    def finish_stream(
        self,
        trace_id: str,
        attempt: int,
    ) -> list[LLMStreamEvent[TOutputItem, TOutputPayload]]:
        raise NotImplementedError


class BaseProtocolClient(ABC, Generic[TRequest, TOutputItem, TOutputPayload]):
    """
    Template Method base class shared by OpenAIResponsesClient, ClaudeMessagesClient,
    and GeminiStreamClient (Section 5.1 ~ 5.5).
    """

    def __init__(
        self,
        config: ClientConfig,
        transport: Optional[AsyncHttpTransport] = None,
        backoff_strategy: Optional[BackoffStrategy] = None,
    ) -> None:
        self._config = config
        self._transport: AsyncHttpTransport = transport or AsyncioHttpTransport()
        self._backoff_strategy: BackoffStrategy = (
            backoff_strategy or ExponentialFullJitterBackoffStrategy()
        )
        self._inspector_dispatcher = HttpInspectorDispatcher(config.inspectors)

    @property
    @abstractmethod
    def provider_name(self) -> ProviderName:
        raise NotImplementedError

    def use_inspector(self, inspector: HttpInspector) -> BaseProtocolClient[TRequest, TOutputItem, TOutputPayload]:
        """Registers an HttpInspector observer on this client instance (FR-HOOK-01)."""
        self._inspector_dispatcher.add(inspector)
        return self

    @abstractmethod
    def _build_url_and_headers(
        self,
        request: TRequest,
        options: RequestOptions,
    ) -> tuple[str, dict[str, str]]:
        """Hook method: returns `(full_url, request_headers)` for the target protocol."""
        raise NotImplementedError

    @abstractmethod
    def _serialize_request_to_root_dict(
        self,
        request: TRequest,
        options: RequestOptions,
    ) -> dict[str, Any]:
        """Hook method: converts the strongly-typed native request into a mutable root JSON dict.

        `options` is provided so protocol serializers can honor per-request
        overrides (e.g. an `anthropic-version` header overridden at request
        level must also drive version-dependent body transforms).
        """
        raise NotImplementedError

    @abstractmethod
    def _create_state_machine(
        self,
        request: TRequest,
    ) -> ProtocolStreamStateMachine[TOutputItem, TOutputPayload]:
        """Factory Method: creates a fresh protocol state machine per HTTP attempt."""
        raise NotImplementedError

    def build_final_request_body(
        self,
        request: TRequest,
        custom_body_json: Optional[str] = None,
        options: Optional[RequestOptions] = None,
    ) -> tuple[str, dict[str, Any]]:
        """
        Implements the `BuildFinalRequestBody` pipeline (FR-PROTO-05 & Section 5.2):
        1. Assembles standard typed request into a mutable root dictionary.
        2. Applies `custom_body_json` via Shallow Root Override (top-level keys added or replaced as a whole).
        3. Does NOT judge or validate whether custom keys/values conform to target LLM rules.
        """
        root_map = dict(
            self._serialize_request_to_root_dict(request, options or RequestOptions())
        )

        effective_custom_json = (
            custom_body_json
            if custom_body_json is not None
            else self._config.default_custom_body_json
        )

        if effective_custom_json is not None and effective_custom_json.strip() != "":
            try:
                parsed_custom = json.loads(effective_custom_json)
            except Exception as exc:
                raise LLMClientError(
                    kind=ErrorKind.BAD_REQUEST,
                    message=f"custom_body_json is not valid JSON: {exc}",
                    is_retryable=False,
                    attempt=0,
                    cause=exc,
                ) from exc

            if not isinstance(parsed_custom, dict):
                raise LLMClientError(
                    kind=ErrorKind.BAD_REQUEST,
                    message="custom_body_json root must be a JSON object {...}",
                    is_retryable=False,
                    attempt=0,
                )

            # Shallow Root Override (方式 A: 顶层一级 Key 整块覆盖，不做递归子属性合并)
            for key, value in parsed_custom.items():
                root_map[key] = value

        raw_body = json.dumps(root_map, ensure_ascii=False)
        return raw_body, root_map

    async def stream(
        self,
        request: TRequest,
        options: Optional[RequestOptions] = None,
    ) -> AsyncIterator[LLMStreamEvent[TOutputItem, TOutputPayload]]:
        """
        Template Method executing the complete lifecycle:
        Payload assembly -> Retry loop -> HttpInspector hooks -> Cancellation -> SSE framing -> State Machine.
        """
        opts = options or RequestOptions()
        trace_id = str(uuid.uuid4())
        retry_policy = opts.retry_policy or self._config.retry_policy
        timeouts = opts.timeouts or self._config.timeouts
        cancel_token = opts.cancel_token
        dispatcher = self._inspector_dispatcher.with_additional(opts.inspectors)

        max_attempts = max(1, retry_policy.max_attempts)

        # Build URL, Headers, and Final Request Body (including custom_body_json override)
        url, headers = self._build_url_and_headers(request, opts)
        raw_body, body_obj = self.build_final_request_body(
            request, opts.custom_body_json, options=opts
        )
        raw_body_bytes = raw_body.encode("utf-8")
        # Hand inspectors an isolated snapshot so a mutating hook can never
        # corrupt the body that is (re)sent on subsequent retry attempts.
        inspector_body_obj = copy.deepcopy(body_obj)

        for attempt in range(1, max_attempts + 1):
            if cancel_token is not None:
                cancel_token.raise_if_cancelled(attempt)

            # FR-STATE-01: Emit request_start before each attempt
            yield RequestStartEvent(trace_id=trace_id, attempt=attempt)

            has_emitted_content = False
            http_error_reported = False
            start_time_ms = _now_ms()
            raw_response_chunks: list[str] = []
            http_response: Optional[AsyncHttpResponse] = None

            try:
                # 1. Fire HttpInspector.on_request
                await dispatcher.emit_request(
                    RequestWireContext(
                        trace_id=trace_id,
                        attempt=attempt,
                        provider=self.provider_name,
                        timestamp_ms=_now_ms(),
                        method="POST",
                        url=url,
                        headers=dict(headers),
                        body_object=inspector_body_obj,
                        raw_body=raw_body,
                    )
                )

                # 2. Send HTTP request
                http_response = await self._transport.send_stream(
                    method="POST",
                    url=url,
                    headers=headers,
                    body=raw_body_bytes,
                    timeouts=timeouts,
                    cancel_token=cancel_token,
                )
                ttfb_ms = _now_ms() - start_time_ms

                # 3. Fire HttpInspector.on_response_headers
                await dispatcher.emit_response_headers(
                    ResponseHeadersWireContext(
                        trace_id=trace_id,
                        attempt=attempt,
                        provider=self.provider_name,
                        timestamp_ms=_now_ms(),
                        status=http_response.status,
                        status_text=http_response.status_text,
                        headers=dict(http_response.headers),
                        ttfb_ms=ttfb_ms,
                    )
                )

                # 4. Non-2xx status handling
                if http_response.status < 200 or http_response.status >= 300:
                    err_bytes = await http_response.read_all(
                        cancel_token=cancel_token,
                        timeout_ms=timeouts.response_header_timeout_ms,
                    )
                    error_body_str = err_bytes.decode("utf-8", errors="replace")
                    raw_response_chunks.append(error_body_str)
                    llm_http_err = classify_http_error(
                        status_code=http_response.status,
                        headers=http_response.headers,
                        raw_body=error_body_str,
                        attempt=attempt,
                    )
                    await dispatcher.emit_exchange_complete(
                        ExchangeCompleteWireContext(
                            trace_id=trace_id,
                            attempt=attempt,
                            provider=self.provider_name,
                            timestamp_ms=_now_ms(),
                            outcome="http_error",
                            duration_ms=_now_ms() - start_time_ms,
                            raw_response_body=error_body_str,
                            error=llm_http_err,
                        )
                    )
                    http_error_reported = True
                    raise llm_http_err

                # 5. HTTP 200 OK SSE Streaming loop
                sse_parser = ChunkSafeSseParser()
                state_machine = self._create_state_machine(request)

                async for raw_bytes in http_response.iter_bytes(
                    cancel_token=cancel_token,
                    idle_timeout_ms=timeouts.stream_idle_timeout_ms,
                ):
                    decoded_text, frames = sse_parser.feed_bytes(raw_bytes, final=False)
                    if decoded_text:
                        raw_response_chunks.append(decoded_text)
                        await dispatcher.emit_raw_stream_chunk(
                            RawStreamChunkContext(
                                trace_id=trace_id,
                                attempt=attempt,
                                provider=self.provider_name,
                                timestamp_ms=_now_ms(),
                                raw_chunk=decoded_text,
                            )
                        )

                    for frame in frames:
                        domain_events = state_machine.process_frame(
                            frame, trace_id=trace_id, attempt=attempt
                        )
                        for ev in domain_events:
                            if ev.type != "response_start":
                                has_emitted_content = True
                            yield ev

                # Flush any remaining buffered bytes/frames at EOF
                trailing_text, trailing_frames = sse_parser.feed_bytes(b"", final=True)
                if trailing_text:
                    # FR-HOOK-03: 100% raw fidelity — the EOF tail must reach
                    # onRawStreamChunk just like every other decoded chunk.
                    raw_response_chunks.append(trailing_text)
                    await dispatcher.emit_raw_stream_chunk(
                        RawStreamChunkContext(
                            trace_id=trace_id,
                            attempt=attempt,
                            provider=self.provider_name,
                            timestamp_ms=_now_ms(),
                            raw_chunk=trailing_text,
                        )
                    )
                for frame in trailing_frames:
                    for ev in state_machine.process_frame(
                        frame, trace_id=trace_id, attempt=attempt
                    ):
                        if ev.type != "response_start":
                            has_emitted_content = True
                        yield ev

                for final_ev in state_machine.finish_stream(
                    trace_id=trace_id, attempt=attempt
                ):
                    if final_ev.type != "response_start":
                        has_emitted_content = True
                    yield final_ev

                await dispatcher.emit_exchange_complete(
                    ExchangeCompleteWireContext(
                        trace_id=trace_id,
                        attempt=attempt,
                        provider=self.provider_name,
                        timestamp_ms=_now_ms(),
                        outcome="completed",
                        duration_ms=_now_ms() - start_time_ms,
                        raw_response_body="".join(raw_response_chunks),
                    )
                )
                return

            except GeneratorExit:
                # The upstream consumer stopped iterating (break / aclose()).
                # Release the underlying connection, never retry, never convert
                # this into an LLMClientError, and never yield again — the
                # generator must let GeneratorExit propagate for a clean close.
                if http_response is not None:
                    try:
                        await http_response.close()
                    except Exception:
                        pass
                try:
                    await dispatcher.emit_exchange_complete(
                        ExchangeCompleteWireContext(
                            trace_id=trace_id,
                            attempt=attempt,
                            provider=self.provider_name,
                            timestamp_ms=_now_ms(),
                            outcome="aborted",
                            duration_ms=_now_ms() - start_time_ms,
                            raw_response_body="".join(raw_response_chunks),
                        )
                    )
                except Exception:
                    pass
                raise

            except BaseException as exc:
                if http_response is not None:
                    await http_response.close()

                is_cancelled = (
                    (cancel_token is not None and cancel_token.is_cancelled)
                    or isinstance(exc, asyncio.CancelledError)
                    or (
                        isinstance(exc, LLMClientError)
                        and exc.kind == ErrorKind.ABORTED
                    )
                )

                if is_cancelled:
                    aborted_err = classify_stream_or_network_error(
                        exc, attempt=attempt, is_cancelled=True
                    )
                    await dispatcher.emit_exchange_complete(
                        ExchangeCompleteWireContext(
                            trace_id=trace_id,
                            attempt=attempt,
                            provider=self.provider_name,
                            timestamp_ms=_now_ms(),
                            outcome="aborted",
                            duration_ms=_now_ms() - start_time_ms,
                            raw_response_body="".join(raw_response_chunks),
                            error=aborted_err,
                        )
                    )
                    raise aborted_err from exc

                llm_err = classify_stream_or_network_error(
                    exc, attempt=attempt, is_cancelled=False
                )

                # An exchange ends with exactly one terminal outcome hook. The
                # non-2xx path above already emitted "http_error"; every other
                # failure inside this attempt (including in-stream protocol
                # errors that carry a status_code, e.g. Gemini's in-band error
                # frames) must still emit "stream_error".
                if not http_error_reported:
                    await dispatcher.emit_exchange_complete(
                        ExchangeCompleteWireContext(
                            trace_id=trace_id,
                            attempt=attempt,
                            provider=self.provider_name,
                            timestamp_ms=_now_ms(),
                            outcome="stream_error",
                            duration_ms=_now_ms() - start_time_ms,
                            raw_response_body="".join(raw_response_chunks),
                            error=llm_err,
                        )
                    )

                can_retry = (
                    attempt < max_attempts
                    and llm_err.is_retryable
                    and (
                        not has_emitted_content
                        or retry_policy.retry_on_mid_stream_error
                    )
                )

                if not can_retry:
                    raise llm_err from exc

                delay_ms = self._backoff_strategy.compute_delay_ms(
                    attempt=attempt,
                    policy=retry_policy,
                    retry_after_header=llm_err.retry_after_header,
                )

                # FR-STATE-02: Notify upstream before sleeping
                yield RetryingEvent(
                    trace_id=trace_id,
                    attempt=attempt,
                    max_attempts=max_attempts,
                    delay_ms=delay_ms,
                    error=llm_err,
                )

                await interruptible_sleep(
                    delay_ms=delay_ms,
                    cancel_token=cancel_token,
                    attempt=attempt,
                )
