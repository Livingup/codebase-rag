from __future__ import annotations

import asyncio
import ssl
import urllib.parse
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import AsyncIterator, Mapping, Optional

from .cancellation import CancellationToken
from .errors import ErrorKind, LLMClientError


class StreamTruncatedError(Exception):
    """
    Raised when the peer closes the connection before the HTTP response body is
    complete (missing chunked 0-length terminator, or short Content-Length body).
    Proxies/gateways often close idle SSE connections gracefully (FIN, not RST),
    so this must surface as a stream error instead of a normal end-of-stream.
    The retry engine classifies it as a retryable NETWORK_ERROR.
    """


@dataclass(frozen=True)
class TransportTimeouts:
    """Fine-grained timeout settings in milliseconds (FR-PROTO-04.3)."""

    connect_timeout_ms: int = 15000
    response_header_timeout_ms: int = 60000
    stream_idle_timeout_ms: int = 120000


class AsyncHttpResponse(ABC):
    """Abstract streaming HTTP response handle."""

    @property
    @abstractmethod
    def status(self) -> int:
        raise NotImplementedError

    @property
    @abstractmethod
    def status_text(self) -> str:
        raise NotImplementedError

    @property
    @abstractmethod
    def headers(self) -> Mapping[str, str]:
        raise NotImplementedError

    @abstractmethod
    def iter_bytes(
        self,
        cancel_token: Optional[CancellationToken] = None,
        idle_timeout_ms: int = 120000,
    ) -> AsyncIterator[bytes]:
        raise NotImplementedError

    @abstractmethod
    async def read_all(
        self,
        cancel_token: Optional[CancellationToken] = None,
        timeout_ms: int = 30000,
    ) -> bytes:
        raise NotImplementedError

    @abstractmethod
    async def close(self) -> None:
        raise NotImplementedError


class AsyncHttpTransport(ABC):
    """
    Strategy interface for executing low-level streaming HTTP requests.
    Allows swapping between zero-dependency `AsyncioHttpTransport`,
    `HttpxAsyncTransport`, or deterministic mock transports in unit tests.
    """

    @abstractmethod
    async def send_stream(
        self,
        method: str,
        url: str,
        headers: Mapping[str, str],
        body: bytes,
        timeouts: TransportTimeouts,
        cancel_token: Optional[CancellationToken] = None,
    ) -> AsyncHttpResponse:
        raise NotImplementedError


async def _await_with_cancel_and_timeout(
    coro: asyncio.Future | object,
    timeout_ms: int,
    cancel_token: Optional[CancellationToken],
    on_abort_cleanup: Optional[callable] = None,
) -> object:
    """
    Awaits a coroutine while simultaneously watching `cancel_token` and `timeout_ms`.
    Ensures zero-delay interruption if `cancel_token.cancel()` is triggered.
    """
    if cancel_token is not None and cancel_token.is_cancelled:
        if on_abort_cleanup:
            on_abort_cleanup()
        cancel_token.raise_if_cancelled()

    main_task = asyncio.ensure_future(coro)  # type: ignore[arg-type]
    timeout_sec = max(0.001, timeout_ms / 1000.0)

    if cancel_token is None:
        try:
            return await asyncio.wait_for(main_task, timeout=timeout_sec)
        except asyncio.TimeoutError as exc:
            main_task.cancel()
            if on_abort_cleanup:
                on_abort_cleanup()
            raise LLMClientError(
                kind=ErrorKind.NETWORK_ERROR,
                message=f"HTTP operation timed out after {timeout_ms}ms",
                is_retryable=True,
                attempt=1,
                cause=exc,
            ) from exc

    cancel_task = asyncio.create_task(cancel_token.wait_cancelled())
    try:
        done, _ = await asyncio.wait(
            {main_task, cancel_task},
            timeout=timeout_sec,
            return_when=asyncio.FIRST_COMPLETED,
        )
        if not done:
            # Timed out
            main_task.cancel()
            if on_abort_cleanup:
                on_abort_cleanup()
            raise LLMClientError(
                kind=ErrorKind.NETWORK_ERROR,
                message=f"HTTP operation timed out after {timeout_ms}ms",
                is_retryable=True,
                attempt=1,
            )

        if cancel_task in done or cancel_token.is_cancelled:
            main_task.cancel()
            if on_abort_cleanup:
                on_abort_cleanup()
            cancel_token.raise_if_cancelled()

        return main_task.result()
    finally:
        if not cancel_task.done():
            cancel_task.cancel()


class _AsyncioSocketHttpResponse(AsyncHttpResponse):
    """Streaming HTTP/1.1 response backed by asyncio StreamReader/StreamWriter."""

    def __init__(
        self,
        status: int,
        status_text: str,
        headers: dict[str, str],
        reader: asyncio.StreamReader,
        writer: asyncio.StreamWriter,
    ) -> None:
        self._status = status
        self._status_text = status_text
        self._headers = headers
        self._reader = reader
        self._writer = writer
        self._closed = False

    @property
    def status(self) -> int:
        return self._status

    @property
    def status_text(self) -> str:
        return self._status_text

    @property
    def headers(self) -> Mapping[str, str]:
        return self._headers

    def _force_close_socket(self) -> None:
        if not self._closed:
            self._closed = True
            try:
                self._writer.close()
            except Exception:
                pass

    async def close(self) -> None:
        if not self._closed:
            self._closed = True
            try:
                self._writer.close()
                await self._writer.wait_closed()
            except Exception:
                pass

    async def read_all(
        self,
        cancel_token: Optional[CancellationToken] = None,
        timeout_ms: int = 30000,
    ) -> bytes:
        chunks: list[bytes] = []
        async for chunk in self.iter_bytes(
            cancel_token=cancel_token, idle_timeout_ms=timeout_ms
        ):
            chunks.append(chunk)
        return b"".join(chunks)

    async def iter_bytes(
        self,
        cancel_token: Optional[CancellationToken] = None,
        idle_timeout_ms: int = 120000,
    ) -> AsyncIterator[bytes]:
        lower_headers = {k.lower(): v.lower() for k, v in self._headers.items()}
        transfer_encoding = lower_headers.get("transfer-encoding", "")
        content_length_str = lower_headers.get("content-length")

        try:
            if "chunked" in transfer_encoding:
                while True:
                    line_bytes = await _await_with_cancel_and_timeout(
                        self._reader.readline(),
                        idle_timeout_ms,
                        cancel_token,
                        self._force_close_socket,
                    )
                    assert isinstance(line_bytes, bytes)
                    if not line_bytes:
                        raise StreamTruncatedError(
                            "Connection closed before chunked response "
                            "terminator (0-length chunk) was received"
                        )
                    size_str = line_bytes.strip().split(b";", 1)[0]
                    if not size_str:
                        continue
                    chunk_size = int(size_str, 16)
                    if chunk_size == 0:
                        # Consume trailing CRLF
                        await _await_with_cancel_and_timeout(
                            self._reader.readline(),
                            idle_timeout_ms,
                            cancel_token,
                            self._force_close_socket,
                        )
                        break
                    chunk_data = await _await_with_cancel_and_timeout(
                        self._reader.readexactly(chunk_size),
                        idle_timeout_ms,
                        cancel_token,
                        self._force_close_socket,
                    )
                    assert isinstance(chunk_data, bytes)
                    # Consume trailing CRLF after chunk body
                    await _await_with_cancel_and_timeout(
                        self._reader.readexactly(2),
                        idle_timeout_ms,
                        cancel_token,
                        self._force_close_socket,
                    )
                    if chunk_data:
                        yield chunk_data

            elif content_length_str is not None:
                total_expected = int(content_length_str)
                remaining = total_expected
                while remaining > 0:
                    chunk = await _await_with_cancel_and_timeout(
                        self._reader.read(min(65536, remaining)),
                        idle_timeout_ms,
                        cancel_token,
                        self._force_close_socket,
                    )
                    assert isinstance(chunk, bytes)
                    if not chunk:
                        raise StreamTruncatedError(
                            f"Connection closed with {remaining} of "
                            f"{total_expected} Content-Length body bytes unread"
                        )
                    remaining -= len(chunk)
                    yield chunk

            else:
                # Stream until EOF (e.g., standard SSE Connection: close)
                while True:
                    chunk = await _await_with_cancel_and_timeout(
                        self._reader.read(16384),
                        idle_timeout_ms,
                        cancel_token,
                        self._force_close_socket,
                    )
                    assert isinstance(chunk, bytes)
                    if not chunk:
                        break
                    yield chunk
        finally:
            await self.close()


class AsyncioHttpTransport(AsyncHttpTransport):
    """
    Zero-dependency pure Python asyncio HTTP/1.1 & HTTPS streaming transport (NFR-1).
    Supports TLS, chunked transfer encoding, SSE streaming, and instant cancellation
    during TCP/TLS handshake, header waiting, and stream reading (FR-CANCEL-02).
    """

    def __init__(self, ssl_context: Optional[ssl.SSLContext] = None) -> None:
        self._ssl_context = ssl_context
        # Lazily-created shared default context: creating an SSLContext loads
        # and verifies the system CA bundle, which is too costly to repeat
        # for every request.
        self._default_ssl_context: Optional[ssl.SSLContext] = None

    async def send_stream(
        self,
        method: str,
        url: str,
        headers: Mapping[str, str],
        body: bytes,
        timeouts: TransportTimeouts,
        cancel_token: Optional[CancellationToken] = None,
    ) -> AsyncHttpResponse:
        parsed = urllib.parse.urlsplit(url)
        scheme = (parsed.scheme or "https").lower()
        host = parsed.hostname
        if not host:
            raise LLMClientError(
                kind=ErrorKind.BAD_REQUEST,
                message=f"Invalid request URL: {url}",
                is_retryable=False,
                attempt=1,
            )

        port = parsed.port or (443 if scheme == "https" else 80)
        path = parsed.path or "/"
        if parsed.query:
            path = f"{path}?{parsed.query}"

        ssl_ctx: Optional[ssl.SSLContext] = None
        if scheme == "https":
            if self._ssl_context is not None:
                ssl_ctx = self._ssl_context
            else:
                if self._default_ssl_context is None:
                    self._default_ssl_context = ssl.create_default_context()
                ssl_ctx = self._default_ssl_context

        # 1. Connect with cancellation and connect_timeout_ms
        conn_coro = asyncio.open_connection(host=host, port=port, ssl=ssl_ctx)
        reader_writer = await _await_with_cancel_and_timeout(
            conn_coro, timeouts.connect_timeout_ms, cancel_token
        )
        reader, writer = reader_writer  # type: ignore[misc]

        def abort_socket() -> None:
            try:
                writer.close()
            except Exception:
                pass

        try:
            # 2. Build and send HTTP/1.1 request wire frame
            host_header = host if parsed.port is None else f"{host}:{port}"
            req_headers: dict[str, str] = {
                "Host": host_header,
                "Connection": "close",
                # We never decode gzip/deflate; ask gateways for identity so a
                # forced-compression proxy cannot corrupt the raw SSE bytes.
                "Accept-Encoding": "identity",
                "Content-Length": str(len(body)),
            }
            for k, v in headers.items():
                req_headers[k] = v

            header_lines = [f"{method.upper()} {path} HTTP/1.1"]
            for k, v in req_headers.items():
                header_lines.append(f"{k}: {v}")
            raw_head = ("\r\n".join(header_lines) + "\r\n\r\n").encode("utf-8")

            writer.write(raw_head)
            if body:
                writer.write(body)
            await _await_with_cancel_and_timeout(
                writer.drain(),
                timeouts.connect_timeout_ms,
                cancel_token,
                abort_socket,
            )

            # 3. Read HTTP status line
            status_line_bytes = await _await_with_cancel_and_timeout(
                reader.readline(),
                timeouts.response_header_timeout_ms,
                cancel_token,
                abort_socket,
            )
            assert isinstance(status_line_bytes, bytes)
            if not status_line_bytes:
                raise ConnectionResetError("Server closed connection before sending HTTP status")

            status_line = status_line_bytes.decode("iso-8859-1", errors="replace").strip()
            parts = status_line.split(" ", 2)
            if len(parts) < 2 or not parts[1].isdigit():
                raise LLMClientError(
                    kind=ErrorKind.PROTOCOL_ERROR,
                    message=f"Malformed HTTP status line: {status_line}",
                    is_retryable=True,
                    attempt=1,
                )
            status_code = int(parts[1])
            status_text = parts[2] if len(parts) > 2 else ""

            # 4. Read HTTP response headers
            resp_headers: dict[str, str] = {}
            while True:
                hline_bytes = await _await_with_cancel_and_timeout(
                    reader.readline(),
                    timeouts.response_header_timeout_ms,
                    cancel_token,
                    abort_socket,
                )
                assert isinstance(hline_bytes, bytes)
                if not hline_bytes or hline_bytes in (b"\r\n", b"\n"):
                    break
                hline = hline_bytes.decode("iso-8859-1", errors="replace").strip()
                if ":" in hline:
                    hk, hv = hline.split(":", 1)
                    resp_headers[hk.strip()] = hv.strip()

            return _AsyncioSocketHttpResponse(
                status=status_code,
                status_text=status_text,
                headers=resp_headers,
                reader=reader,
                writer=writer,
            )
        except Exception:
            abort_socket()
            raise
