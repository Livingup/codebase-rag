from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Generic, Literal, Optional, TypeVar, Union

from .errors import LLMClientError

TOutputItem = TypeVar("TOutputItem")
TOutputPayload = TypeVar("TOutputPayload")


@dataclass(frozen=True)
class TokenUsage:
    """Normalized token usage statistics reported on response completion."""

    input_tokens: int = 0
    output_tokens: int = 0
    reasoning_tokens: int = 0
    cache_read_input_tokens: int = 0
    cache_creation_input_tokens: int = 0
    total_tokens: int = 0
    raw_usage: dict[str, Any] = field(default_factory=dict)


# ============================================================================
# 1. Transport & Retry Lifecycle Events
# ============================================================================


@dataclass(frozen=True)
class RequestStartEvent:
    """Fired immediately before each HTTP attempt begins (FR-STATE-01)."""

    trace_id: str
    attempt: int
    type: Literal["request_start"] = "request_start"


@dataclass(frozen=True)
class RetryingEvent:
    """Fired when a retryable failure occurs and before backoff sleep (FR-STATE-02)."""

    trace_id: str
    attempt: int
    max_attempts: int
    delay_ms: int
    error: LLMClientError
    type: Literal["retrying"] = "retrying"


@dataclass(frozen=True)
class ResponseStartEvent:
    """Fired when HTTP 200 OK is established and first frame arrives (FR-STATE-03)."""

    trace_id: str
    attempt: int
    response_id: str
    model: str
    type: Literal["response_start"] = "response_start"


# ============================================================================
# 2. Thinking / Reasoning Lifecycle Events (FR-STATE-04)
# ============================================================================


@dataclass(frozen=True)
class ThinkingStartEvent:
    block_index: int
    item_id: Optional[str] = None
    type: Literal["thinking_start"] = "thinking_start"


@dataclass(frozen=True)
class ThinkingDeltaEvent:
    block_index: int
    delta: str
    type: Literal["thinking_delta"] = "thinking_delta"


@dataclass(frozen=True)
class ThinkingStopEvent(Generic[TOutputItem]):
    block_index: int
    text: str
    raw_item: TOutputItem
    signature: Optional[str] = None
    redacted_data: Optional[str] = None
    type: Literal["thinking_stop"] = "thinking_stop"


# ============================================================================
# 3. Ordinary Text Reply Lifecycle Events (FR-STATE-05)
# ============================================================================


@dataclass(frozen=True)
class TextStartEvent:
    block_index: int
    item_id: Optional[str] = None
    type: Literal["text_start"] = "text_start"


@dataclass(frozen=True)
class TextDeltaEvent:
    block_index: int
    delta: str
    type: Literal["text_delta"] = "text_delta"


@dataclass(frozen=True)
class TextStopEvent(Generic[TOutputItem]):
    block_index: int
    text: str
    raw_item: TOutputItem
    type: Literal["text_stop"] = "text_stop"


# ============================================================================
# 4. Client Function / Custom Tool Call Lifecycle Events (FR-STATE-06)
# ============================================================================


@dataclass(frozen=True)
class ToolCallStartEvent:
    """
    Fired immediately upon receiving the tool call name and call_id,
    without waiting for argument streaming to finish.
    """

    block_index: int
    call_id: str
    name: str
    tool_type: Literal["function", "custom"] = "function"
    type: Literal["tool_call_start"] = "tool_call_start"


@dataclass(frozen=True)
class ToolCallDeltaEvent:
    block_index: int
    call_id: str
    arguments_delta: str
    type: Literal["tool_call_delta"] = "tool_call_delta"


@dataclass(frozen=True)
class ToolCallStopEvent(Generic[TOutputItem]):
    block_index: int
    call_id: str
    name: str
    arguments_raw: str
    raw_item: TOutputItem
    type: Literal["tool_call_stop"] = "tool_call_stop"


# ============================================================================
# 5. Server-Side Hosted Tool Lifecycle Events (FR-STATE-07)
# ============================================================================


@dataclass(frozen=True)
class ServerToolStartEvent:
    block_index: int
    item_id: str
    tool_name: str
    type: Literal["server_tool_start"] = "server_tool_start"


@dataclass(frozen=True)
class ServerToolDeltaEvent:
    block_index: int
    item_id: str
    delta_type: str
    delta_payload: Any
    type: Literal["server_tool_delta"] = "server_tool_delta"


@dataclass(frozen=True)
class ServerToolStopEvent(Generic[TOutputItem]):
    block_index: int
    item_id: str
    tool_name: str
    raw_item: TOutputItem
    type: Literal["server_tool_stop"] = "server_tool_stop"


# ============================================================================
# 6. Audio Output Lifecycle Events (FR-STATE-09, TTS models)
# ============================================================================


@dataclass(frozen=True)
class AudioStartEvent:
    """Fired when the first audio `inlineData` output part arrives (e.g. TTS
    voice synthesis models streaming `audio/l16` chunks)."""

    block_index: int
    mime_type: str
    type: Literal["audio_start"] = "audio_start"


@dataclass(frozen=True)
class AudioDeltaEvent:
    """Fired for every streamed audio part; `audio_delta` is the base64-encoded
    chunk exactly as delivered by the server (concatenating the decoded bytes
    of all deltas in order yields the full playable audio stream)."""

    block_index: int
    audio_delta: str
    mime_type: str = ""
    type: Literal["audio_delta"] = "audio_delta"


@dataclass(frozen=True)
class AudioStopEvent:
    """Fired when the audio stream ends: a non-audio part arrives, the audio
    mime type changes, or the SSE stream reaches EOF. The raw audio parts are
    additionally preserved verbatim in `response_complete.output` for replay."""

    block_index: int
    mime_type: str
    total_base64_length: int
    type: Literal["audio_stop"] = "audio_stop"


# ============================================================================
# 7. Response Complete Event (FR-STATE-08)
# ============================================================================


@dataclass(frozen=True)
class ResponseCompleteEvent(Generic[TOutputPayload]):
    """
    Final event emitted when the SSE stream completes normally.
    `output` holds the protocol-native output items/content ready to be appended
    directly into the next stateless multi-turn conversation history.
    `stop_reason` is the server-reported finish reason verbatim; it is None
    when the server ended the stream without reporting one (the SDK never
    fabricates a reason it was not told).
    """

    response_id: str
    stop_reason: Optional[str]
    usage: TokenUsage
    output: TOutputPayload
    type: Literal["response_complete"] = "response_complete"


LLMStreamEvent = Union[
    RequestStartEvent,
    RetryingEvent,
    ResponseStartEvent,
    ThinkingStartEvent,
    ThinkingDeltaEvent,
    ThinkingStopEvent[TOutputItem],
    TextStartEvent,
    TextDeltaEvent,
    TextStopEvent[TOutputItem],
    ToolCallStartEvent,
    ToolCallDeltaEvent,
    ToolCallStopEvent[TOutputItem],
    ServerToolStartEvent,
    ServerToolDeltaEvent,
    ServerToolStopEvent[TOutputItem],
    AudioStartEvent,
    AudioDeltaEvent,
    AudioStopEvent,
    ResponseCompleteEvent[TOutputPayload],
]
