from __future__ import annotations

import asyncio
from typing import Any, Callable, Optional

from .errors import ErrorKind, LLMClientError


class CancellationToken:
    """
    Cooperative and reactive cancellation handle (Observer + Command pattern)
    compatible with Python asyncio.
    Supports instant wakeup during HTTP handshakes, SSE stream reads, and
    retry backoff sleep timers (FR-CANCEL-01 ~ 03).
    """

    def __init__(self, event: Optional[asyncio.Event] = None) -> None:
        self._event: asyncio.Event = event if event is not None else asyncio.Event()
        self._callbacks: list[Callable[[], Any]] = []
        self._reason: str = "Request cancelled by upstream caller"

    @property
    def is_cancelled(self) -> bool:
        return self._event.is_set()

    @property
    def reason(self) -> str:
        return self._reason

    def cancel(self, reason: str = "Request cancelled by upstream caller") -> None:
        """Triggers cancellation immediately and invokes all registered listeners."""
        if self._event.is_set():
            return
        self._reason = reason
        self._event.set()
        for callback in list(self._callbacks):
            try:
                callback()
            except Exception:
                pass

    def on_cancel(self, callback: Callable[[], Any]) -> Callable[[], None]:
        """
        Registers a callback to be invoked immediately when cancel() is called.
        Returns an unsubscribe function.
        """
        if self._event.is_set():
            try:
                callback()
            except Exception:
                pass
            return lambda: None

        self._callbacks.append(callback)

        def unsubscribe() -> None:
            if callback in self._callbacks:
                self._callbacks.remove(callback)

        return unsubscribe

    def raise_if_cancelled(self, attempt: int = 1) -> None:
        if self._event.is_set():
            raise LLMClientError(
                kind=ErrorKind.ABORTED,
                message=self._reason,
                is_retryable=False,
                attempt=attempt,
            )

    async def wait_cancelled(self) -> None:
        await self._event.wait()


async def interruptible_sleep(
    delay_ms: int,
    cancel_token: Optional[CancellationToken],
    attempt: int,
) -> None:
    """
    Sleeps for `delay_ms` milliseconds, but wakes up and raises LLMClientError(ABORTED)
    with zero delay if `cancel_token` is triggered during the backoff window (FR-CANCEL-02.3).
    """
    if cancel_token is not None:
        cancel_token.raise_if_cancelled(attempt)

    if delay_ms <= 0:
        return

    delay_sec = delay_ms / 1000.0
    if cancel_token is None:
        await asyncio.sleep(delay_sec)
        return

    cancel_task = asyncio.create_task(cancel_token.wait_cancelled())
    sleep_task = asyncio.create_task(asyncio.sleep(delay_sec))
    try:
        done, _ = await asyncio.wait(
            {cancel_task, sleep_task},
            return_when=asyncio.FIRST_COMPLETED,
        )
        if cancel_task in done or cancel_token.is_cancelled:
            cancel_token.raise_if_cancelled(attempt)
    finally:
        for task in (cancel_task, sleep_task):
            if not task.done():
                task.cancel()
