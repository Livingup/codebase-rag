from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Literal, Mapping, Optional, Sequence, TypedDict, Union

from .base_client import (
    BaseProtocolClient,
    ClientConfig,
    ProtocolStreamStateMachine,
    RequestOptions,
    to_serializable_dict,
)
from .errors import ErrorKind, LLMClientError
from .events import (
    LLMStreamEvent,
    ResponseCompleteEvent,
    ResponseStartEvent,
    ServerToolDeltaEvent,
    ServerToolStartEvent,
    ServerToolStopEvent,
    TextDeltaEvent,
    TextStartEvent,
    TextStopEvent,
    ThinkingDeltaEvent,
    ThinkingStartEvent,
    ThinkingStopEvent,
    TokenUsage,
    ToolCallDeltaEvent,
    ToolCallStartEvent,
    ToolCallStopEvent,
)
from .inspector import ProviderName
from .retry import BackoffStrategy
from .sse import SseEventFrame
from .transport import AsyncHttpTransport

DEFAULT_OPENAI_BASE_URL = "https://api.openai.com/v1"

# ============================================================================
# 1. Cache & Basic Configuration Types (docs/OPENAI_RESPONSES_API.md Section 5.1)
# ============================================================================

OpenAIResponseRole = Literal["user", "assistant", "system", "developer"]


class PromptCacheBreakpoint(TypedDict, total=False):
    mode: Literal["explicit"]
    ttl: Literal["30m", "12h"]


class PromptCacheOptions(TypedDict, total=False):
    mode: Literal["implicit", "explicit"]
    ttl: Literal["30m", "12h"]


# ============================================================================
# 2. Content Part Types (InputContentPart & OutputContentPart)
# ============================================================================


class InputTextPart(TypedDict, total=False):
    type: Literal["input_text"]
    text: str
    prompt_cache_breakpoint: PromptCacheBreakpoint


class InputImagePart(TypedDict, total=False):
    type: Literal["input_image"]
    image_url: str
    file_id: str
    detail: Literal["low", "high", "auto", "original"]
    prompt_cache_breakpoint: PromptCacheBreakpoint


class InputFilePart(TypedDict, total=False):
    type: Literal["input_file"]
    file_id: str
    file_data: str
    file_url: str
    filename: str
    detail: Literal["low", "high"]
    prompt_cache_breakpoint: PromptCacheBreakpoint


class InputAudioData(TypedDict):
    data: str
    format: Literal["mp3", "wav"]


class InputAudioPart(TypedDict):
    type: Literal["input_audio"]
    input_audio: InputAudioData


InputContentPart = Union[
    InputTextPart,
    InputImagePart,
    InputFilePart,
    InputAudioPart,
    dict[str, Any],
]


class OutputTextAnnotation(TypedDict, total=False):
    type: Literal[
        "url_citation", "file_citation", "container_file_citation", "file_path"
    ]
    start_index: int
    end_index: int
    url: str
    title: str
    file_id: str
    filename: str
    container_id: str


class OutputTextPart(TypedDict, total=False):
    type: Literal["output_text"]
    text: str
    annotations: list[OutputTextAnnotation]
    logprobs: list[dict[str, Any]]


class OutputRefusalPart(TypedDict):
    type: Literal["refusal"]
    refusal: str


OutputContentPart = Union[OutputTextPart, OutputRefusalPart, dict[str, Any]]


# ============================================================================
# 3. Tool Definitions (12 Variants in docs/OPENAI_RESPONSES_API.md Section 5.3)
# ============================================================================


class FunctionToolDefinition(TypedDict, total=False):
    type: Literal["function"]
    name: str
    description: str
    parameters: dict[str, Any]
    strict: bool
    defer_loading: bool


class CustomToolGrammarFormat(TypedDict):
    type: Literal["grammar"]
    syntax: Literal["lark", "regex"]
    definition: str


class CustomToolTextFormat(TypedDict):
    type: Literal["text"]


class CustomToolDefinition(TypedDict, total=False):
    type: Literal["custom"]
    name: str
    description: str
    defer_loading: bool
    format: Union[CustomToolTextFormat, CustomToolGrammarFormat]


class ToolSearchDefinition(TypedDict, total=False):
    type: Literal["tool_search"]
    execution: Literal["server", "client"]
    description: str
    parameters: dict[str, Any]


class NamespaceToolDefinition(TypedDict):
    type: Literal["namespace"]
    name: str
    description: str
    tools: list[Union[FunctionToolDefinition, CustomToolDefinition, dict[str, Any]]]


class McpToolDefinition(TypedDict, total=False):
    type: Literal["mcp"]
    server_label: str
    server_url: str
    connector_id: str
    authorization: str
    headers: dict[str, str]
    allowed_tools: Union[list[str], dict[str, Any]]
    require_approval: Union[Literal["always", "never"], dict[str, Any]]
    defer_loading: bool


class ComparisonFilter(TypedDict):
    type: Literal["eq", "ne", "gt", "gte", "lt", "lte", "in", "nin"]
    key: str
    value: Union[str, int, float, bool, list[Union[str, int, float]]]


class CompoundFilter(TypedDict):
    type: Literal["and", "or"]
    filters: list[Union[ComparisonFilter, dict[str, Any]]]


class WebSearchUserLocation(TypedDict, total=False):
    type: Literal["approximate"]
    country: str
    city: str
    region: str
    timezone: str


class WebSearchToolDefinition(TypedDict, total=False):
    type: Literal["web_search", "web_search_preview"]
    search_context_size: Literal["low", "medium", "high"]
    filters: dict[str, list[str]]
    user_location: WebSearchUserLocation


class FileSearchRankingOptions(TypedDict, total=False):
    ranker: Literal["auto", "default-2024-11-15"]
    score_threshold: float


class FileSearchToolDefinition(TypedDict, total=False):
    type: Literal["file_search"]
    vector_store_ids: list[str]
    max_num_results: int
    ranking_options: FileSearchRankingOptions
    filters: Union[ComparisonFilter, CompoundFilter, dict[str, Any]]


class CodeInterpreterAutoContainer(TypedDict, total=False):
    type: Literal["auto"]
    file_ids: list[str]
    memory_limit: Literal["1g", "4g", "16g", "64g"]


class CodeInterpreterToolDefinition(TypedDict):
    type: Literal["code_interpreter"]
    container: Union[str, CodeInterpreterAutoContainer, dict[str, Any]]


class ImageGenerationMask(TypedDict, total=False):
    image_url: str
    file_id: str


class ImageGenerationToolDefinition(TypedDict, total=False):
    type: Literal["image_generation"]
    model: str
    size: Literal["1024x1024", "1024x1536", "1536x1024", "auto"]
    quality: Literal["low", "medium", "high", "auto"]
    output_format: Literal["png", "webp", "jpeg"]
    output_compression: int
    background: Literal["transparent", "opaque", "auto"]
    moderation: Literal["auto", "low"]
    input_fidelity: Literal["low", "high"]
    input_image_mask: ImageGenerationMask
    partial_images: int


class ComputerUseToolDefinition(TypedDict):
    type: Literal["computer_use_preview"]
    display_width: int
    display_height: int
    environment: Literal["browser", "mac", "windows", "ubuntu"]


class ApplyPatchToolDefinition(TypedDict):
    type: Literal["apply_patch"]


class LocalShellToolDefinition(TypedDict):
    type: Literal["local_shell"]


OpenAIResponseTool = Union[
    FunctionToolDefinition,
    CustomToolDefinition,
    ToolSearchDefinition,
    NamespaceToolDefinition,
    McpToolDefinition,
    WebSearchToolDefinition,
    FileSearchToolDefinition,
    CodeInterpreterToolDefinition,
    ImageGenerationToolDefinition,
    ComputerUseToolDefinition,
    ApplyPatchToolDefinition,
    LocalShellToolDefinition,
    dict[str, Any],
]


# ============================================================================
# 4. Input / Output Item Variants (22 Variants in docs/OPENAI_RESPONSES_API.md Section 5.4)
# ============================================================================


class MessageInputItem(TypedDict, total=False):
    type: Literal["message"]
    id: str
    role: Literal["user", "developer", "system", "assistant"]
    status: Literal["in_progress", "completed", "incomplete"]
    phase: Optional[Literal["commentary", "final_answer"]]
    content: Union[str, list[InputContentPart], list[OutputContentPart]]


class AdditionalToolsInputItem(TypedDict, total=False):
    type: Literal["additional_tools"]
    id: str
    role: Literal["developer"]
    tools: list[OpenAIResponseTool]


class ConfigurationUpdateInputItem(TypedDict, total=False):
    type: Literal["configuration_update"]
    reasoning: dict[str, Any]


class FunctionCallItem(TypedDict, total=False):
    type: Literal["function_call"]
    id: str
    call_id: str
    name: str
    namespace: str
    arguments: str
    status: Literal["in_progress", "completed", "incomplete"]


class FunctionCallOutputItem(TypedDict, total=False):
    type: Literal["function_call_output"]
    id: str
    call_id: str
    output: Union[str, list[InputContentPart]]
    status: Literal["in_progress", "completed", "incomplete"]


class CustomToolCallItem(TypedDict, total=False):
    type: Literal["custom_tool_call"]
    id: str
    call_id: str
    name: str
    namespace: str
    input: str


class CustomToolCallOutputItem(TypedDict, total=False):
    type: Literal["custom_tool_call_output"]
    id: str
    call_id: str
    output: Union[str, list[InputContentPart]]


class ToolSearchCallItem(TypedDict, total=False):
    type: Literal["tool_search_call"]
    id: str
    call_id: Optional[str]
    execution: Literal["server", "client"]
    arguments: Any
    status: Literal["in_progress", "completed", "incomplete"]


class ToolSearchOutputItem(TypedDict, total=False):
    type: Literal["tool_search_output"]
    id: str
    call_id: Optional[str]
    execution: Literal["server", "client"]
    status: Literal["in_progress", "completed", "incomplete"]
    tools: list[OpenAIResponseTool]


class ApplyPatchCallItem(TypedDict, total=False):
    type: Literal["apply_patch_call"]
    id: str
    call_id: str
    status: Literal["in_progress", "completed"]
    operation: dict[str, Any]


class ApplyPatchCallOutputItem(TypedDict, total=False):
    type: Literal["apply_patch_call_output"]
    id: str
    call_id: str
    status: Literal["completed", "failed"]
    output: Optional[str]


class LocalShellCallItem(TypedDict, total=False):
    type: Literal["local_shell_call"]
    id: str
    call_id: str
    status: Literal["in_progress", "completed", "incomplete"]
    action: dict[str, Any]


class LocalShellCallOutputItem(TypedDict, total=False):
    type: Literal["local_shell_call_output"]
    id: str
    call_id: str
    output: str
    status: Literal["in_progress", "completed", "incomplete"]


class ComputerAction(TypedDict, total=False):
    type: Literal[
        "click",
        "double_click",
        "move",
        "type",
        "keypress",
        "scroll",
        "drag",
        "wait",
        "screenshot",
    ]
    x: int
    y: int
    button: Literal["left", "right", "wheel", "back", "forward"]
    text: str
    keys: list[str]
    scroll_x: int
    scroll_y: int
    path: list[dict[str, int]]


class ComputerCallItem(TypedDict, total=False):
    type: Literal["computer_call"]
    id: str
    call_id: str
    action: Union[ComputerAction, dict[str, Any]]
    pending_safety_checks: list[dict[str, str]]
    status: Literal["in_progress", "completed", "incomplete"]


class ComputerCallOutputItem(TypedDict, total=False):
    type: Literal["computer_call_output"]
    id: str
    call_id: str
    acknowledged_safety_checks: list[dict[str, str]]
    output: dict[str, str]


class WebSearchAction(TypedDict, total=False):
    type: Literal["search", "open_page", "find_in_page"]
    query: str
    queries: list[str]
    sources: list[dict[str, str]]
    url: str
    pattern: str


class WebSearchCallItem(TypedDict, total=False):
    type: Literal["web_search_call"]
    id: str
    status: Literal["in_progress", "searching", "completed", "failed"]
    action: Union[WebSearchAction, dict[str, Any]]


class FileSearchCallResultItem(TypedDict, total=False):
    file_id: str
    filename: str
    score: float
    text: str
    attributes: dict[str, Union[str, int, float, bool]]


class FileSearchCallItem(TypedDict, total=False):
    type: Literal["file_search_call"]
    id: str
    status: Literal["in_progress", "searching", "completed", "failed"]
    queries: list[str]
    results: Optional[list[Union[FileSearchCallResultItem, dict[str, Any]]]]


class ImageGenerationCallItem(TypedDict, total=False):
    type: Literal["image_generation_call"]
    id: str
    status: Literal["in_progress", "generating", "completed", "failed"]
    result: Optional[str]
    revised_prompt: str
    background: Literal["transparent", "opaque", "auto"]
    output_format: Literal["png", "webp", "jpeg"]
    quality: Literal["low", "medium", "high"]
    size: Literal["1024x1024", "1024x1536", "1536x1024"]


class CodeInterpreterCallItem(TypedDict, total=False):
    type: Literal["code_interpreter_call"]
    id: str
    status: Literal["in_progress", "interpreting", "completed", "incomplete"]
    container_id: str
    code: Optional[str]
    outputs: Optional[list[dict[str, Any]]]


class McpListToolEntry(TypedDict, total=False):
    name: str
    description: str
    input_schema: dict[str, Any]
    annotations: dict[str, Any]


class McpListToolsItem(TypedDict, total=False):
    type: Literal["mcp_list_tools"]
    id: str
    server_label: str
    tools: list[Union[McpListToolEntry, dict[str, Any]]]


class McpCallItem(TypedDict, total=False):
    type: Literal["mcp_call"]
    id: str
    server_label: str
    name: str
    arguments: str
    output: Optional[str]
    error: Optional[str]


class McpApprovalRequestItem(TypedDict, total=False):
    type: Literal["mcp_approval_request"]
    id: str
    server_label: str
    name: str
    arguments: str


class McpApprovalResponseItem(TypedDict, total=False):
    type: Literal["mcp_approval_response"]
    id: str
    approval_request_id: str
    approve: bool
    reason: Optional[str]


class ReasoningItem(TypedDict, total=False):
    type: Literal["reasoning"]
    id: str
    summary: list[dict[str, str]]
    content: list[dict[str, str]]
    encrypted_content: Optional[str]
    status: Literal["in_progress", "completed", "incomplete"]


class CompactionItem(TypedDict):
    type: Literal["compaction"]
    id: str
    encrypted_content: str


class ItemReferenceItem(TypedDict):
    type: Literal["item_reference"]
    id: str


OpenAIResponseInputItem = Union[
    MessageInputItem,
    AdditionalToolsInputItem,
    ConfigurationUpdateInputItem,
    FunctionCallItem,
    FunctionCallOutputItem,
    CustomToolCallItem,
    CustomToolCallOutputItem,
    ToolSearchCallItem,
    ToolSearchOutputItem,
    ApplyPatchCallItem,
    ApplyPatchCallOutputItem,
    LocalShellCallItem,
    LocalShellCallOutputItem,
    ComputerCallItem,
    ComputerCallOutputItem,
    WebSearchCallItem,
    FileSearchCallItem,
    ImageGenerationCallItem,
    CodeInterpreterCallItem,
    McpListToolsItem,
    McpCallItem,
    McpApprovalRequestItem,
    McpApprovalResponseItem,
    ReasoningItem,
    CompactionItem,
    ItemReferenceItem,
    dict[str, Any],
]

OpenAIResponseOutputItem = OpenAIResponseInputItem


# ============================================================================
# 5. Top-Level Request Configuration Types (CreateResponseRequest)
# ============================================================================


class OpenAIReasoningConfig(TypedDict, total=False):
    effort: Optional[Literal["none", "minimal", "low", "medium", "high", "xhigh"]]
    summary: Optional[Literal["auto", "concise", "detailed"]]


class OpenAITextFormatJsonSchema(TypedDict, total=False):
    type: Literal["json_schema"]
    name: str
    description: str
    schema: dict[str, Any]
    strict: bool


class OpenAITextConfig(TypedDict, total=False):
    verbosity: Optional[Literal["low", "medium", "high"]]
    format: Union[
        dict[str, Literal["text", "json_object"]],
        OpenAITextFormatJsonSchema,
        dict[str, Any],
    ]


class OpenAIStreamOptions(TypedDict, total=False):
    include_obfuscation: bool


class OpenAIContextManagementConfig(TypedDict):
    type: Literal["compaction"]
    compact_threshold: int


OpenAIIncludeOption = Literal[
    "reasoning.encrypted_content",
    "file_search_call.results",
    "web_search_call.results",
    "web_search_call.action.sources",
    "code_interpreter_call.outputs",
    "computer_call_output.output.image_url",
    "message.input_image.image_url",
    "message.output_text.logprobs",
]


OpenAIToolChoice = Union[
    Literal["none", "auto", "required"],
    dict[str, Any],
]


@dataclass
class OpenAIResponsesRequest:
    """
    Complete, non-simplified native request payload for OpenAI `POST /v1/responses`
    matching every field in `docs/OPENAI_RESPONSES_API.md` (Section 5.5).
    Defaults to stateless multi-turn mode (`store=False`).
    """

    model: str
    input: Union[str, Sequence[OpenAIResponseInputItem]]
    instructions: Optional[Union[str, Sequence[OpenAIResponseInputItem]]] = None
    previous_response_id: Optional[str] = None
    conversation: Optional[Union[str, dict[str, str]]] = None
    stream_options: Optional[Union[OpenAIStreamOptions, dict[str, Any]]] = None
    store: bool = False
    background: Optional[bool] = None
    max_output_tokens: Optional[int] = None
    max_tool_calls: Optional[int] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    top_logprobs: Optional[int] = None
    truncation: Optional[Literal["auto", "disabled"]] = None
    parallel_tool_calls: Optional[bool] = None
    tool_choice: Optional[OpenAIToolChoice] = None
    tools: Optional[Sequence[OpenAIResponseTool]] = None
    text: Optional[Union[OpenAITextConfig, dict[str, Any]]] = None
    reasoning: Optional[Union[OpenAIReasoningConfig, dict[str, Any]]] = None
    context_management: Optional[
        Sequence[Union[OpenAIContextManagementConfig, dict[str, Any]]]
    ] = None
    include: Optional[Sequence[Union[OpenAIIncludeOption, str]]] = None
    prompt_cache_key: Optional[str] = None
    prompt_cache_retention: Optional[Literal["in_memory", "in-memory", "24h"]] = None
    prompt_cache_options: Optional[Union[PromptCacheOptions, dict[str, Any]]] = None
    metadata: Optional[Mapping[str, str]] = None
    safety_identifier: Optional[str] = None
    user: Optional[str] = None
    service_tier: Optional[Literal["auto", "default", "flex", "priority"]] = None
    extra_fields: Mapping[str, Any] = field(default_factory=dict)


# ============================================================================
# 6. Response Object & Usage Types (docs/OPENAI_RESPONSES_API.md Section 5.6)
# ============================================================================


class OpenAIResponseUsage(TypedDict, total=False):
    input_tokens: int
    input_tokens_details: dict[str, int]
    output_tokens: int
    output_tokens_details: dict[str, int]
    total_tokens: int


class OpenAIResponseObject(TypedDict, total=False):
    id: str
    object: Literal["response"]
    created_at: int
    completed_at: Optional[int]
    status: Literal[
        "completed",
        "in_progress",
        "failed",
        "incomplete",
        "cancelled",
        "queued",
    ]
    error: Optional[dict[str, str]]
    incomplete_details: Optional[dict[str, str]]
    instructions: Optional[Union[str, list[OpenAIResponseInputItem]]]
    max_output_tokens: Optional[int]
    max_tool_calls: Optional[int]
    model: str
    output: list[OpenAIResponseOutputItem]
    parallel_tool_calls: bool
    previous_response_id: Optional[str]
    conversation: Optional[dict[str, str]]
    reasoning: Optional[OpenAIReasoningConfig]
    store: bool
    temperature: Optional[float]
    top_p: Optional[float]
    truncation: Literal["auto", "disabled"]
    tool_choice: OpenAIToolChoice
    tools: list[OpenAIResponseTool]
    text: dict[str, Any]
    service_tier: Optional[str]
    safety_identifier: Optional[str]
    usage: Optional[OpenAIResponseUsage]
    metadata: dict[str, str]


SERVER_HOSTED_ITEM_TYPES: frozenset[str] = frozenset(
    {
        "web_search_call",
        "file_search_call",
        "code_interpreter_call",
        "image_generation_call",
        "mcp_call",
        "mcp_list_tools",
        "mcp_approval_request",
        "tool_search_call",
        "computer_call",
        "local_shell_call",
        "apply_patch_call",
    }
)

SERVER_TOOL_PROGRESS_EVENTS: frozenset[str] = frozenset(
    {
        "response.image_generation_call.partial_image",
        "response.image_generation_call.in_progress",
        "response.image_generation_call.generating",
        "response.image_generation_call.completed",
        "response.code_interpreter_call_code.delta",
        "response.code_interpreter_call_code.done",
        "response.code_interpreter_call.in_progress",
        "response.code_interpreter_call.interpreting",
        "response.code_interpreter_call.completed",
        "response.web_search_call.in_progress",
        "response.web_search_call.searching",
        "response.web_search_call.completed",
        "response.file_search_call.in_progress",
        "response.file_search_call.searching",
        "response.file_search_call.completed",
        "response.tool_search_call.in_progress",
        "response.tool_search_call.searching",
        "response.tool_search_call.completed",
        "response.mcp_call_arguments.delta",
        "response.mcp_call_arguments.done",
        "response.mcp_call.in_progress",
        "response.mcp_call.completed",
        "response.mcp_call.failed",
        "response.mcp_list_tools.in_progress",
        "response.mcp_list_tools.completed",
        "response.mcp_list_tools.failed",
    }
)


@dataclass
class _TrackedOpenAIItem:
    block_index: int
    item_id: str
    item_type: str
    call_id: str = ""
    name: str = ""
    is_client_tool_search: bool = False
    text_buffer: list[str] = field(default_factory=list)
    args_buffer: list[str] = field(default_factory=list)


def _safe_int(value: Any, default: int) -> int:
    """Tolerates malformed wire values (e.g. `"output_index": null`) that would
    otherwise raise a bare TypeError inside the state machine."""
    try:
        return int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return default


class OpenAIResponsesStateMachine(
    ProtocolStreamStateMachine[OpenAIResponseOutputItem, list[OpenAIResponseOutputItem]]
):
    """
    State Pattern implementation mapping OpenAI `/v1/responses` SSE events
    to unified `LLMStreamEvent` lifecycle events (Section 5.4.1 & docs/OPENAI_RESPONSES_API.md Section 4).
    """

    def __init__(self) -> None:
        self._response_id: str = ""
        self._model: str = ""
        self._items_by_index: dict[int, _TrackedOpenAIItem] = {}
        self._items_by_id: dict[str, _TrackedOpenAIItem] = {}
        self._completed_output_items: list[OpenAIResponseOutputItem] = []
        self._emitted_complete: bool = False
        self._saw_terminal_event: bool = False
        self._next_block_index: int = 0

    def process_frame(
        self,
        frame: SseEventFrame,
        trace_id: str,
        attempt: int,
    ) -> list[LLMStreamEvent[OpenAIResponseOutputItem, list[OpenAIResponseOutputItem]]]:
        raw_data = frame.data.strip()
        if not raw_data or raw_data == "[DONE]":
            return []

        try:
            payload: dict[str, Any] = json.loads(raw_data)
        except Exception as exc:
            raise LLMClientError(
                kind=ErrorKind.PROTOCOL_ERROR,
                message=f"Failed to parse OpenAI SSE JSON frame: {exc}",
                is_retryable=False,
                attempt=attempt,
                raw_body=raw_data,
                cause=exc,
            ) from exc

        event_type = frame.event or payload.get("type", "")
        events: list[
            LLMStreamEvent[OpenAIResponseOutputItem, list[OpenAIResponseOutputItem]]
        ] = []

        # 1. response.created -> response_start
        if event_type == "response.created":
            resp_obj = payload.get("response", {})
            self._response_id = str(resp_obj.get("id", ""))
            self._model = str(resp_obj.get("model", ""))
            events.append(
                ResponseStartEvent(
                    trace_id=trace_id,
                    attempt=attempt,
                    response_id=self._response_id,
                    model=self._model,
                )
            )
            return events

        # 2. response.output_item.added -> immediate start event
        if event_type == "response.output_item.added":
            output_index = _safe_int(
                payload.get("output_index"), self._next_block_index
            )
            self._next_block_index = max(self._next_block_index, output_index + 1)
            item = payload.get("item", {})
            item_type = str(item.get("type", ""))
            item_id = str(item.get("id", f"item_{output_index}"))
            call_id = str(item.get("call_id") or item_id)
            name = str(item.get("name") or item_type)
            is_client_ts = (
                item_type == "tool_search_call"
                and item.get("execution") == "client"
            )

            tracked = _TrackedOpenAIItem(
                block_index=output_index,
                item_id=item_id,
                item_type=item_type,
                call_id=call_id,
                name=name,
                is_client_tool_search=is_client_ts,
            )
            self._items_by_index[output_index] = tracked
            self._items_by_id[item_id] = tracked

            if item_type == "reasoning":
                events.append(
                    ThinkingStartEvent(block_index=output_index, item_id=item_id)
                )
            elif item_type == "message":
                events.append(
                    TextStartEvent(block_index=output_index, item_id=item_id)
                )
            elif item_type in ("function_call", "custom_tool_call") or is_client_ts:
                tool_kind: Literal["function", "custom"] = (
                    "custom" if item_type == "custom_tool_call" else "function"
                )
                events.append(
                    ToolCallStartEvent(
                        block_index=output_index,
                        call_id=call_id,
                        name=name,
                        tool_type=tool_kind,
                    )
                )
            elif item_type in SERVER_HOSTED_ITEM_TYPES:
                events.append(
                    ServerToolStartEvent(
                        block_index=output_index,
                        item_id=item_id,
                        tool_name=item_type,
                    )
                )
            return events

        # 3. Thinking deltas
        if event_type in (
            "response.reasoning_summary_text.delta",
            "response.reasoning_text.delta",
        ):
            tracked = self._resolve_tracked(payload)
            delta = str(payload.get("delta", ""))
            if tracked is not None and delta:
                tracked.text_buffer.append(delta)
                events.append(
                    ThinkingDeltaEvent(block_index=tracked.block_index, delta=delta)
                )
            return events

        # 4. Ordinary text deltas & refusal deltas
        if event_type in ("response.output_text.delta", "response.refusal.delta"):
            tracked = self._resolve_tracked(payload)
            delta = str(payload.get("delta", ""))
            if tracked is not None and delta:
                tracked.text_buffer.append(delta)
                events.append(
                    TextDeltaEvent(block_index=tracked.block_index, delta=delta)
                )
            return events

        # 5. Client tool call argument / input deltas
        if event_type in (
            "response.function_call_arguments.delta",
            "response.custom_tool_call_input.delta",
        ):
            tracked = self._resolve_tracked(payload)
            delta = str(payload.get("delta", ""))
            if tracked is not None and delta:
                tracked.args_buffer.append(delta)
                events.append(
                    ToolCallDeltaEvent(
                        block_index=tracked.block_index,
                        call_id=tracked.call_id,
                        arguments_delta=delta,
                    )
                )
            return events

        # 6. Server-side hosted tool progress & delta events
        if event_type in SERVER_TOOL_PROGRESS_EVENTS:
            tracked = self._resolve_tracked(payload)
            b_idx = tracked.block_index if tracked is not None else 0
            item_id = (
                tracked.item_id
                if tracked is not None
                else str(payload.get("item_id", ""))
            )
            events.append(
                ServerToolDeltaEvent(
                    block_index=b_idx,
                    item_id=item_id,
                    delta_type=event_type,
                    delta_payload=payload,
                )
            )
            return events

        # 7. response.output_item.done -> corresponding *_stop event
        if event_type == "response.output_item.done":
            output_index = _safe_int(payload.get("output_index"), 0)
            item: dict[str, Any] = payload.get("item", {})
            item_type = str(item.get("type", ""))
            tracked = self._items_by_index.get(output_index)
            b_idx = tracked.block_index if tracked is not None else output_index
            is_client_ts = (
                item_type == "tool_search_call"
                and (
                    item.get("execution") == "client"
                    # The done frame may omit `execution`; keep the start/stop
                    # event pair consistent with the added frame's mode.
                    or (tracked is not None and tracked.is_client_tool_search)
                )
            )
            self._completed_output_items.append(item)

            if item_type == "reasoning":
                full_thinking = (
                    "".join(tracked.text_buffer)
                    if tracked and tracked.text_buffer
                    else self._extract_reasoning_summary_text(item)
                )
                encrypted_content = item.get("encrypted_content")
                events.append(
                    ThinkingStopEvent(
                        block_index=b_idx,
                        text=full_thinking,
                        signature=(
                            str(encrypted_content)
                            if encrypted_content is not None
                            else None
                        ),
                        raw_item=item,
                    )
                )
            elif item_type == "message":
                full_text = (
                    "".join(tracked.text_buffer)
                    if tracked and tracked.text_buffer
                    else self._extract_message_text(item)
                )
                events.append(
                    TextStopEvent(
                        block_index=b_idx,
                        text=full_text,
                        raw_item=item,
                    )
                )
            elif item_type in ("function_call", "custom_tool_call") or is_client_ts:
                call_id = str(
                    item.get("call_id")
                    or (tracked.call_id if tracked else "")
                    or item.get("id", "")
                )
                name = str(
                    item.get("name")
                    or (tracked.name if tracked else "")
                    or item_type
                )
                if item_type == "function_call" and "arguments" in item:
                    args_raw = str(item["arguments"])
                elif item_type == "custom_tool_call" and "input" in item:
                    args_raw = str(item["input"])
                elif is_client_ts and "arguments" in item:
                    args_val = item["arguments"]
                    args_raw = (
                        args_val
                        if isinstance(args_val, str)
                        else json.dumps(args_val, ensure_ascii=False)
                    )
                elif tracked:
                    args_raw = "".join(tracked.args_buffer)
                else:
                    args_raw = ""

                events.append(
                    ToolCallStopEvent(
                        block_index=b_idx,
                        call_id=call_id,
                        name=name,
                        arguments_raw=args_raw,
                        raw_item=item,
                    )
                )
            elif item_type in SERVER_HOSTED_ITEM_TYPES:
                item_id = str(item.get("id") or (tracked.item_id if tracked else ""))
                events.append(
                    ServerToolStopEvent(
                        block_index=b_idx,
                        item_id=item_id,
                        tool_name=item_type,
                        raw_item=item,
                    )
                )
            return events

        # 8. response.completed / response.incomplete -> response_complete
        if event_type in ("response.completed", "response.incomplete"):
            self._saw_terminal_event = True
            resp_obj = payload.get("response", {})
            resp_id = str(resp_obj.get("id") or self._response_id)
            status_str = str(resp_obj.get("status", "completed"))
            incomplete_details = resp_obj.get("incomplete_details")
            if status_str == "incomplete" and isinstance(incomplete_details, dict):
                stop_reason = str(incomplete_details.get("reason", "incomplete"))
            else:
                stop_reason = status_str

            raw_output_list = resp_obj.get("output")
            final_output: list[OpenAIResponseOutputItem] = (
                list(raw_output_list)
                if isinstance(raw_output_list, list) and raw_output_list
                else list(self._completed_output_items)
            )
            usage = self._parse_usage(resp_obj.get("usage"))
            self._emitted_complete = True
            events.append(
                ResponseCompleteEvent(
                    response_id=resp_id,
                    stop_reason=stop_reason,
                    usage=usage,
                    output=final_output,
                )
            )
            return events

        # 9. response.failed / error -> raise LLMClientError
        if event_type in ("response.failed", "error"):
            err_info = (
                payload.get("response", {}).get("error")
                or payload.get("error")
                or payload
            )
            code = str(err_info.get("code") or err_info.get("type") or "stream_error")
            msg = str(err_info.get("message") or "OpenAI stream reported an error")
            if code == "rate_limit_exceeded":
                kind = ErrorKind.RATE_LIMIT
                is_retryable = True
            elif code == "overloaded":
                kind = ErrorKind.OVERLOADED
                is_retryable = True
            elif code == "server_error":
                kind = ErrorKind.SERVER_ERROR
                is_retryable = True
            elif code in (
                "invalid_request_error",
                "invalid_prompt",
                "context_length_exceeded",
            ):
                kind = ErrorKind.BAD_REQUEST
                is_retryable = False
            else:
                kind = ErrorKind.PROTOCOL_ERROR
                is_retryable = False
            raise LLMClientError(
                kind=kind,
                message=msg,
                is_retryable=is_retryable,
                attempt=attempt,
                provider_error_code=code,
                raw_body=raw_data,
            )

        return events

    def finish_stream(
        self,
        trace_id: str,
        attempt: int,
    ) -> list[LLMStreamEvent[OpenAIResponseOutputItem, list[OpenAIResponseOutputItem]]]:
        if self._emitted_complete:
            return []
        self._emitted_complete = True
        if not self._saw_terminal_event:
            # A clean EOF without `response.completed` / `response.incomplete`
            # means the stream was truncated (e.g. a proxy terminated the SSE
            # exchange early). That must surface as an error, never as a
            # fabricated "successful" response with zero usage.
            raise LLMClientError(
                kind=ErrorKind.PROTOCOL_ERROR,
                message=(
                    "SSE stream ended without a terminal "
                    "response.completed/response.incomplete event"
                ),
                is_retryable=False,
                attempt=attempt,
            )
        return []

    def _resolve_tracked(self, payload: Mapping[str, Any]) -> Optional[_TrackedOpenAIItem]:
        if "output_index" in payload:
            idx = _safe_int(payload["output_index"], -1)
            if idx in self._items_by_index:
                return self._items_by_index[idx]
        item_id = payload.get("item_id")
        if isinstance(item_id, str) and item_id in self._items_by_id:
            return self._items_by_id[item_id]
        return None

    @staticmethod
    def _extract_reasoning_summary_text(item: Mapping[str, Any]) -> str:
        parts: list[str] = []
        for s in item.get("summary", []) or []:
            if isinstance(s, Mapping) and isinstance(s.get("text"), str):
                parts.append(s["text"])
        for c in item.get("content", []) or []:
            if isinstance(c, Mapping) and isinstance(c.get("text"), str):
                parts.append(c["text"])
        return "".join(parts)

    @staticmethod
    def _extract_message_text(item: Mapping[str, Any]) -> str:
        parts: list[str] = []
        for c in item.get("content", []) or []:
            if isinstance(c, Mapping):
                if c.get("type") == "output_text":
                    parts.append(str(c.get("text", "")))
                elif c.get("type") == "refusal":
                    parts.append(str(c.get("refusal", "")))
        return "".join(parts)

    @staticmethod
    def _parse_usage(usage_obj: Any) -> TokenUsage:
        if not isinstance(usage_obj, Mapping):
            return TokenUsage()
        inp = _safe_int(usage_obj.get("input_tokens"), 0)
        out = _safe_int(usage_obj.get("output_tokens"), 0)
        tot = _safe_int(usage_obj.get("total_tokens"), inp + out)
        inp_details = usage_obj.get("input_tokens_details") or {}
        out_details = usage_obj.get("output_tokens_details") or {}
        cached = (
            _safe_int(inp_details.get("cached_tokens"), 0)
            if isinstance(inp_details, Mapping)
            else 0
        )
        reasoning = (
            _safe_int(out_details.get("reasoning_tokens"), 0)
            if isinstance(out_details, Mapping)
            else 0
        )
        return TokenUsage(
            input_tokens=inp,
            output_tokens=out,
            reasoning_tokens=reasoning,
            cache_read_input_tokens=cached,
            total_tokens=tot,
            raw_usage=dict(usage_obj),
        )


class OpenAIResponsesClient(
    BaseProtocolClient[
        OpenAIResponsesRequest,
        OpenAIResponseOutputItem,
        list[OpenAIResponseOutputItem],
    ]
):
    """
    Dedicated client for OpenAI `POST /v1/responses` (FR-PROTO-01).
    """

    def __init__(
        self,
        config: ClientConfig,
        transport: Optional[AsyncHttpTransport] = None,
        backoff_strategy: Optional[BackoffStrategy] = None,
    ) -> None:
        super().__init__(
            config=config,
            transport=transport,
            backoff_strategy=backoff_strategy,
        )

    @property
    def provider_name(self) -> ProviderName:
        return "openai"

    def _build_url_and_headers(
        self,
        request: OpenAIResponsesRequest,
        options: RequestOptions,
    ) -> tuple[str, dict[str, str]]:
        base = (self._config.base_url or DEFAULT_OPENAI_BASE_URL).rstrip("/")
        url = f"{base}/responses"
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "Authorization": f"Bearer {self._config.api_key}",
        }
        for k, v in self._config.custom_headers.items():
            headers[k] = v
        if options.custom_headers:
            for k, v in options.custom_headers.items():
                headers[k] = v
        return url, headers

    def _serialize_request_to_root_dict(
        self,
        request: OpenAIResponsesRequest,
        options: RequestOptions,
    ) -> dict[str, Any]:
        root: dict[str, Any] = {
            "model": request.model,
            "input": to_serializable_dict(request.input),
            "store": request.store,
            "stream": True,
        }
        optional_fields = (
            "instructions",
            "previous_response_id",
            "conversation",
            "stream_options",
            "background",
            "max_output_tokens",
            "max_tool_calls",
            "temperature",
            "top_p",
            "top_logprobs",
            "truncation",
            "parallel_tool_calls",
            "tool_choice",
            "tools",
            "text",
            "reasoning",
            "context_management",
            "prompt_cache_key",
            "prompt_cache_retention",
            "prompt_cache_options",
            "metadata",
            "safety_identifier",
            "user",
            "service_tier",
        )
        for field_name in optional_fields:
            val = getattr(request, field_name)
            if val is not None:
                root[field_name] = to_serializable_dict(val)

        # FR-PROTO-01.3: In stateless mode (store=False, the default), reasoning
        # models ALWAYS return rs_* reasoning items in the output — even when no
        # `reasoning` config was passed. Without `reasoning.encrypted_content`
        # the reasoning item carries no encrypted payload, and replaying the
        # output in the next turn fails with 404. So the include entry is added
        # unconditionally in stateless mode (users can still replace the whole
        # `include` list via custom_body_json afterwards).
        if not request.store:
            inc_list = list(request.include) if request.include is not None else []
            if "reasoning.encrypted_content" not in inc_list:
                inc_list.append("reasoning.encrypted_content")
            root["include"] = inc_list
        elif request.include is not None:
            root["include"] = list(request.include)

        if request.extra_fields:
            for k, v in request.extra_fields.items():
                root[k] = to_serializable_dict(v)

        return root

    def _create_state_machine(
        self,
        request: OpenAIResponsesRequest,
    ) -> ProtocolStreamStateMachine[
        OpenAIResponseOutputItem, list[OpenAIResponseOutputItem]
    ]:
        return OpenAIResponsesStateMachine()
