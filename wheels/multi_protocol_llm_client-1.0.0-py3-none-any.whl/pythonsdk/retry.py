from __future__ import annotations

import random
import re
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from email.utils import parsedate_to_datetime
from typing import Optional


@dataclass(frozen=True)
class RetryPolicy:
    """
    Configurable retry policy for transient LLM HTTP and network failures (FR-RETRY-01).
    """

    max_attempts: int = 3
    base_delay_ms: int = 1000
    max_delay_ms: int = 30000
    retry_on_mid_stream_error: bool = False


_DURATION_TOKEN_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(ms|s|m|h)")
_DURATION_FULL_RE = re.compile(r"^(?:(?:\d+(?:\.\d+)?)\s*(?:ms|s|m|h))+$")
_UNIT_TO_MS: dict[str, float] = {"ms": 1.0, "s": 1000.0, "m": 60_000.0, "h": 3_600_000.0}


def _parse_duration_ms(raw: str) -> Optional[int]:
    """
    Parses compound duration strings used by OpenAI's `x-ratelimit-reset-*`
    headers, e.g. "6m0s", "1m30s", "1s", "500ms", "0.5s".
    """
    lowered = raw.lower()
    if not _DURATION_FULL_RE.match(lowered):
        return None
    total_ms = 0.0
    for value_str, unit in _DURATION_TOKEN_RE.findall(lowered):
        total_ms += float(value_str) * _UNIT_TO_MS[unit]
    return max(0, int(total_ms))


def parse_retry_after_ms(retry_after_value: Optional[str]) -> Optional[int]:
    """
    Parses a Retry-After or retry-after-ms header into milliseconds (FR-RETRY-04.1).
    Supports integer/float seconds, millisecond headers, compound duration
    strings ("6m0s"), and RFC 2822 HTTP-date strings.
    """
    if not retry_after_value:
        return None
    raw = retry_after_value.strip()
    if not raw:
        return None

    # Check if numeric (seconds or explicit ms suffix)
    if raw.lower().endswith("ms"):
        try:
            ms_val = float(raw[:-2].strip())
            return max(0, int(ms_val))
        except ValueError:
            return None

    try:
        seconds = float(raw)
        return max(0, int(seconds * 1000))
    except ValueError:
        pass

    # Compound duration strings such as "6m0s" / "1m30s500ms"
    duration_ms = _parse_duration_ms(raw)
    if duration_ms is not None:
        return duration_ms

    # Try HTTP-Date format
    try:
        dt = parsedate_to_datetime(raw)
        delta_sec = dt.timestamp() - time.time()
        return max(0, int(delta_sec * 1000))
    except Exception:
        return None


class BackoffStrategy(ABC):
    """Strategy interface for computing retry backoff delay in milliseconds."""

    @abstractmethod
    def compute_delay_ms(
        self,
        attempt: int,
        policy: RetryPolicy,
        retry_after_header: Optional[str] = None,
    ) -> int:
        raise NotImplementedError


class ExponentialFullJitterBackoffStrategy(BackoffStrategy):
    """
    Default backoff strategy (FR-RETRY-04):
    1. First priority: Server-provided `Retry-After` / `retry-after-ms` header (capped by max_delay_ms).
    2. Second priority: Exponential Backoff with Full Jitter in [0.5 * cap, 1.0 * cap].
    """

    def __init__(self, rng: Optional[random.Random] = None) -> None:
        self._rng = rng or random.Random()

    def compute_delay_ms(
        self,
        attempt: int,
        policy: RetryPolicy,
        retry_after_header: Optional[str] = None,
    ) -> int:
        parsed_ms = parse_retry_after_ms(retry_after_header)
        if parsed_ms is not None:
            return min(policy.max_delay_ms, parsed_ms)

        exp_cap = min(
            policy.max_delay_ms,
            policy.base_delay_ms * (2 ** max(0, attempt - 1)),
        )
        low = int(0.5 * exp_cap)
        high = max(low, int(exp_cap))
        return self._rng.randint(low, high)
