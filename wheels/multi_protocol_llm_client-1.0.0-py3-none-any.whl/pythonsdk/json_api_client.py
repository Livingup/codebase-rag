from __future__ import annotations

import asyncio
import json
import time
import uuid
from abc import ABC, abstractmethod
from typing import Any, Mapping, Optional

from .cancellation import CancellationToken, interruptible_sleep
from .errors import ErrorKind, LLMClientError, classify_http_error, classify_stream_or_network_error
from .base_client import ClientConfig, RequestOptions
from .inspector import (
    ExchangeCompleteWireContext,
    HttpInspector,
    HttpInspectorDispatcher,
    ProviderName,
    RequestWireContext,
    ResponseHeadersWireContext,
)
from .retry import BackoffStrategy, ExponentialFullJitterBackoffStrategy
from .transport import AsyncHttpResponse, AsyncHttpTransport, AsyncioHttpTransport


def _now_ms() -> int:
    return int(time.time() * 1000)


class BaseJsonApiClient(ABC):
    """
    Template Method base class for non-streaming JSON-over-HTTP APIs
    (e.g. DeepSeek's /v1/tools/search & /v1/tools/fetch).

    `post_json` fixes the pipeline:
      request assembly -> HttpInspector.on_request -> transport send (with
      cancellation & timeouts) -> non-2xx classification -> retry/backoff ->
      JSON parsing -> HttpInspector.on_exchange_complete.
    Subclasses supply the endpoint path, request body, auth headers and a
    provider name; they reuse the SDK's shared infrastructure: transport
    strategy, cancellation token, RetryPolicy with interruptible backoff,
    inspector observer chain, and the structured LLMClientError taxonomy.

    Unlike the streaming protocol clients this base emits no lifecycle
    events — callers receive plain values or exceptions; per-attempt wire
    outcomes remain observable through HttpInspector.
    """

    def __init__(
        self,
        config: ClientConfig,
        transport: Optional[AsyncHttpTransport] = None,
        backoff_strategy: Optional[BackoffStrategy] = None,
    ) -> None:
        self._config = config
        self._transport: AsyncHttpTransport = transport or AsyncioHttpTransport()
        self._backoff_strategy: BackoffStrategy = (
            backoff_strategy or ExponentialFullJitterBackoffStrategy()
        )
        self._inspector_dispatcher = HttpInspectorDispatcher(config.inspectors)

    @property
    @abstractmethod
    def provider_name(self) -> ProviderName:
        raise NotImplementedError

    @abstractmethod
    def _base_url(self) -> str:
        """Hook: returns the base URL (config override or client default)."""
        raise NotImplementedError

    @abstractmethod
    def _auth_headers(self) -> dict[str, str]:
        """Hook: returns authentication headers for every request."""
        raise NotImplementedError

    def use_inspector(self, inspector: HttpInspector) -> "BaseJsonApiClient":
        """Registers an HttpInspector observer on this client instance (FR-HOOK-01)."""
        self._inspector_dispatcher.add(inspector)
        return self

    async def post_json(
        self,
        path: str,
        body: Mapping[str, Any],
        options: Optional[RequestOptions] = None,
    ) -> dict[str, Any]:
        """Executes one JSON POST with retry/cancellation and returns the parsed object."""
        opts = options or RequestOptions()
        retry_policy = opts.retry_policy or self._config.retry_policy
        timeouts = opts.timeouts or self._config.timeouts
        cancel_token = opts.cancel_token
        dispatcher = self._inspector_dispatcher.with_additional(opts.inspectors)
        max_attempts = max(1, retry_policy.max_attempts)

        url = f"{self._base_url().rstrip('/')}{path}"
        headers: dict[str, str] = {"Content-Type": "application/json"}
        headers.update(self._auth_headers())
        for k, v in self._config.custom_headers.items():
            headers[k] = v
        if opts.custom_headers:
            for k, v in opts.custom_headers.items():
                headers[k] = v

        body_object = dict(body)
        raw_body = json.dumps(body_object, ensure_ascii=False)
        body_bytes = raw_body.encode("utf-8")
        trace_id = str(uuid.uuid4())

        for attempt in range(1, max_attempts + 1):
            if cancel_token is not None:
                cancel_token.raise_if_cancelled(attempt)

            http_error_reported = False
            start_time_ms = _now_ms()
            http_response: Optional[AsyncHttpResponse] = None
            try:
                await dispatcher.emit_request(
                    RequestWireContext(
                        trace_id=trace_id,
                        attempt=attempt,
                        provider=self.provider_name,
                        timestamp_ms=_now_ms(),
                        method="POST",
                        url=url,
                        headers=dict(headers),
                        body_object=body_object,
                        raw_body=raw_body,
                    )
                )

                http_response = await self._transport.send_stream(
                    method="POST",
                    url=url,
                    headers=headers,
                    body=body_bytes,
                    timeouts=timeouts,
                    cancel_token=cancel_token,
                )
                ttfb_ms = _now_ms() - start_time_ms
                await dispatcher.emit_response_headers(
                    ResponseHeadersWireContext(
                        trace_id=trace_id,
                        attempt=attempt,
                        provider=self.provider_name,
                        timestamp_ms=_now_ms(),
                        status=http_response.status,
                        status_text=http_response.status_text,
                        headers=dict(http_response.headers),
                        ttfb_ms=ttfb_ms,
                    )
                )

                data = await http_response.read_all(
                    cancel_token=cancel_token,
                    timeout_ms=timeouts.stream_idle_timeout_ms,
                )
                text = data.decode("utf-8", errors="replace")

                if http_response.status < 200 or http_response.status >= 300:
                    llm_err = classify_http_error(
                        status_code=http_response.status,
                        headers=http_response.headers,
                        raw_body=text,
                        attempt=attempt,
                    )
                    await dispatcher.emit_exchange_complete(
                        ExchangeCompleteWireContext(
                            trace_id=trace_id,
                            attempt=attempt,
                            provider=self.provider_name,
                            timestamp_ms=_now_ms(),
                            outcome="http_error",
                            duration_ms=_now_ms() - start_time_ms,
                            raw_response_body=text,
                            error=llm_err,
                        )
                    )
                    http_error_reported = True
                    raise llm_err

                await dispatcher.emit_exchange_complete(
                    ExchangeCompleteWireContext(
                        trace_id=trace_id,
                        attempt=attempt,
                        provider=self.provider_name,
                        timestamp_ms=_now_ms(),
                        outcome="completed",
                        duration_ms=_now_ms() - start_time_ms,
                        raw_response_body=text,
                    )
                )

                try:
                    payload: Any = json.loads(text)
                except Exception as exc:
                    raise LLMClientError(
                        kind=ErrorKind.PROTOCOL_ERROR,
                        message=f"Failed to parse JSON response: {exc}",
                        is_retryable=False,
                        attempt=attempt,
                        raw_body=text,
                        cause=exc,
                    ) from exc
                if not isinstance(payload, dict):
                    raise LLMClientError(
                        kind=ErrorKind.PROTOCOL_ERROR,
                        message="JSON response root must be an object {...}",
                        is_retryable=False,
                        attempt=attempt,
                        raw_body=text,
                    )
                return payload

            except BaseException as exc:
                if http_response is not None:
                    await http_response.close()

                is_cancelled = (
                    (cancel_token is not None and cancel_token.is_cancelled)
                    or isinstance(exc, asyncio.CancelledError)
                    or (isinstance(exc, LLMClientError) and exc.kind == ErrorKind.ABORTED)
                )
                if is_cancelled:
                    aborted_err = classify_stream_or_network_error(
                        exc, attempt=attempt, is_cancelled=True
                    )
                    await dispatcher.emit_exchange_complete(
                        ExchangeCompleteWireContext(
                            trace_id=trace_id,
                            attempt=attempt,
                            provider=self.provider_name,
                            timestamp_ms=_now_ms(),
                            outcome="aborted",
                            duration_ms=_now_ms() - start_time_ms,
                            raw_response_body="",
                            error=aborted_err,
                        )
                    )
                    raise aborted_err from exc

                llm_err = classify_stream_or_network_error(
                    exc, attempt=attempt, is_cancelled=False
                )
                if not http_error_reported:
                    await dispatcher.emit_exchange_complete(
                        ExchangeCompleteWireContext(
                            trace_id=trace_id,
                            attempt=attempt,
                            provider=self.provider_name,
                            timestamp_ms=_now_ms(),
                            outcome="stream_error",
                            duration_ms=_now_ms() - start_time_ms,
                            raw_response_body="",
                            error=llm_err,
                        )
                    )

                can_retry = attempt < max_attempts and llm_err.is_retryable
                if not can_retry:
                    raise llm_err from exc

                delay_ms = self._backoff_strategy.compute_delay_ms(
                    attempt=attempt,
                    policy=retry_policy,
                    retry_after_header=llm_err.retry_after_header,
                )
                await interruptible_sleep(
                    delay_ms=delay_ms,
                    cancel_token=cancel_token,
                    attempt=attempt,
                )

        raise LLMClientError(  # pragma: no cover - loop always returns or raises
            kind=ErrorKind.SERVER_ERROR,
            message="Retry loop exhausted",
            is_retryable=False,
            attempt=max_attempts,
        )
