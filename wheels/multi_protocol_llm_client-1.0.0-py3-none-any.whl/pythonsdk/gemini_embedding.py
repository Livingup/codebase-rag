from __future__ import annotations

import math
from typing import Any, Literal, Mapping, Optional, Sequence, TypedDict, Union
from urllib.parse import quote

from .base_client import ClientConfig, RequestOptions
from .errors import ErrorKind, LLMClientError
from .json_api_client import BaseJsonApiClient
from .retry import BackoffStrategy
from .transport import AsyncHttpTransport

DEFAULT_GEMINI_EMBEDDING_BASE_URL = "https://generativelanguage.googleapis.com"

# docs/GEMINI_EMBED_CONTENT_API.md Section 1.5 / 2.3 / 2.2 / 3.2
GEMINI_EMBEDDING_MAX_OUTPUT_DIMENSIONALITY = 3072
GEMINI_EMBEDDING_MAX_BATCH_SIZE = 100

GeminiEmbeddingTaskType = Literal[
    "TASK_TYPE_UNSPECIFIED",
    "RETRIEVAL_QUERY",
    "RETRIEVAL_DOCUMENT",
    "SEMANTIC_SIMILARITY",
    "CLASSIFICATION",
    "CLUSTERING",
    "QUESTION_ANSWERING",
    "FACT_VERIFICATION",
    "CODE_RETRIEVAL_QUERY",
]

GEMINI_EMBEDDING_TASK_TYPES: frozenset[str] = frozenset(
    {
        "TASK_TYPE_UNSPECIFIED",
        "RETRIEVAL_QUERY",
        "RETRIEVAL_DOCUMENT",
        "SEMANTIC_SIMILARITY",
        "CLASSIFICATION",
        "CLUSTERING",
        "QUESTION_ANSWERING",
        "FACT_VERIFICATION",
        "CODE_RETRIEVAL_QUERY",
    }
)


# Wire-level types, camelCase to mirror the response exactly (Section 0/4).


class GeminiEmbeddingPart(TypedDict, total=False):
    text: str
    inlineData: dict[str, str]
    fileData: dict[str, str]


class GeminiEmbeddingContent(TypedDict):
    parts: list[GeminiEmbeddingPart]


class GeminiContentEmbedding(TypedDict):
    values: list[float]


class GeminiModalityTokenCount(TypedDict):
    modality: str
    tokenCount: int


class GeminiEmbeddingUsageMetadata(TypedDict, total=False):
    promptTokenCount: int
    promptTokenDetails: list[GeminiModalityTokenCount]


class GeminiEmbedContentResponse(TypedDict, total=False):
    embedding: GeminiContentEmbedding
    usageMetadata: GeminiEmbeddingUsageMetadata


class GeminiBatchEmbedContentsResponse(TypedDict, total=False):
    embeddings: list[GeminiContentEmbedding]
    usageMetadata: GeminiEmbeddingUsageMetadata


class GeminiCountTokensResponse(TypedDict, total=False):
    totalTokens: int
    cachedContentTokenCount: int


EmbedContentRequestLike = Union[str, Mapping[str, Any]]


def _bad_request(message: str) -> LLMClientError:
    return LLMClientError(
        kind=ErrorKind.BAD_REQUEST,
        message=message,
        is_retryable=False,
        attempt=0,
    )


def _validate_parts(content: GeminiEmbeddingContent) -> None:
    parts = content.get("parts")
    if not isinstance(parts, list) or not parts:
        raise _bad_request("content.parts must be a non-empty array")
    for idx, part in enumerate(parts):
        if not isinstance(part, Mapping):
            raise _bad_request(f"content.parts[{idx}] must be an object")
        text = part.get("text")
        has_text = isinstance(text, str) and text != ""
        has_inline = isinstance(part.get("inlineData"), Mapping)
        has_file = isinstance(part.get("fileData"), Mapping)
        if not (has_text or has_inline or has_file):
            raise _bad_request(
                f"content.parts[{idx}] must carry non-empty text, inlineData or fileData"
            )


def l2_normalize(values: Sequence[float]) -> list[float]:
    """L2-normalizes a vector (norm -> 1).

    Required client-side after MRL dimension truncation: the server returns
    full 3072-dim vectors already normalized, but truncated
    (`outputDimensionality < 3072`) sub-vectors are NOT unit-length anymore —
    normalize before indexing into inner-product engines (FAISS/Milvus/
    pgvector). See docs/GEMINI_EMBED_CONTENT_API.md Section 2.4.
    """
    norm = math.sqrt(sum(v * v for v in values))
    if norm == 0.0:
        return list(values)
    return [v / norm for v in values]


def cosine_similarity(a: Sequence[float], b: Sequence[float]) -> float:
    """Cosine similarity in [-1, 1]; raises on dimension mismatch."""
    if len(a) != len(b) or len(a) == 0:
        raise ValueError(f"Vector dimension mismatch: {len(a)} vs {len(b)}")
    dot = sum(x * y for x, y in zip(a, b))
    denom = math.sqrt(sum(x * x for x in a)) * math.sqrt(sum(y * y for y in b))
    return 0.0 if denom == 0.0 else dot / denom


class GeminiEmbeddingClient(BaseJsonApiClient):
    """
    Client for Gemini `:embedContent` / `:batchEmbedContents`
    (docs/GEMINI_EMBED_CONTENT_API.md).

    Single requests accept a plain string or a full `content` object
    (multi-part text/image fusion). Batch requests accept strings or full
    sub-request objects; the protocol-mandatory `"model": "models/{model}"`
    field of every batch sub-request is injected automatically from the
    client-level model. Parameters are validated locally (BAD_REQUEST,
    attempt=0, no network round-trip): non-empty parts, taskType enum,
    title-only-with-RETRIEVAL_DOCUMENT, outputDimensionality 1..3072,
    batch size 1..100. 429/503 retry automatically via RetryPolicy.
    """

    def __init__(
        self,
        config: ClientConfig,
        model: str = "gemini-embedding-2",
        transport: Optional[AsyncHttpTransport] = None,
        backoff_strategy: Optional[BackoffStrategy] = None,
    ) -> None:
        super().__init__(config=config, transport=transport, backoff_strategy=backoff_strategy)
        self._model = model

    @property
    def provider_name(self):
        return "gemini"

    def _base_url(self) -> str:
        return self._config.base_url or DEFAULT_GEMINI_EMBEDDING_BASE_URL

    def _auth_headers(self) -> dict[str, str]:
        return {"x-goog-api-key": self._config.api_key}

    def _model_path(self) -> str:
        return "/".join(quote(seg, safe="") for seg in f"models/{self._model}".split("/"))

    # ------------------------------------------------------ embedContent

    async def embed_content(
        self,
        content: Union[str, Mapping[str, Any]],
        *,
        task_type: Optional[GeminiEmbeddingTaskType] = None,
        title: Optional[str] = None,
        output_dimensionality: Optional[int] = None,
        options: Optional[RequestOptions] = None,
    ) -> GeminiEmbedContentResponse:
        """Embeds one content into a single (optionally truncated) vector."""
        if isinstance(content, str):
            content_obj: GeminiEmbeddingContent = {"parts": [{"text": content}]}
        elif isinstance(content, Mapping):
            content_obj = dict(content)  # type: ignore[assignment]
        else:
            raise _bad_request("content must be a string or a Content object")
        _validate_parts(content_obj)

        if task_type is not None and task_type not in GEMINI_EMBEDDING_TASK_TYPES:
            raise _bad_request(f"taskType must be one of {sorted(GEMINI_EMBEDDING_TASK_TYPES)}")
        if title is not None and task_type != "RETRIEVAL_DOCUMENT":
            raise _bad_request(
                "title is only allowed when taskType is RETRIEVAL_DOCUMENT "
                "(server rejects it with 400 otherwise)"
            )
        if output_dimensionality is not None and not (
            isinstance(output_dimensionality, int)
            and 1 <= output_dimensionality <= GEMINI_EMBEDDING_MAX_OUTPUT_DIMENSIONALITY
        ):
            raise _bad_request(
                f"outputDimensionality must be an integer in "
                f"1..{GEMINI_EMBEDDING_MAX_OUTPUT_DIMENSIONALITY}"
            )

        body: dict[str, Any] = {"content": content_obj}
        if task_type is not None:
            body["taskType"] = task_type
        if title is not None:
            body["title"] = title
        if output_dimensionality is not None:
            body["outputDimensionality"] = output_dimensionality

        payload = await self.post_json(
            f"/v1beta/{self._model_path()}:embedContent", body, options=options
        )
        embedding = payload.get("embedding")
        if not isinstance(embedding, Mapping) or not isinstance(embedding.get("values"), list):
            raise LLMClientError(
                kind=ErrorKind.PROTOCOL_ERROR,
                message="EmbedContent response must contain embedding.values",
                is_retryable=False,
                attempt=0,
            )
        response: GeminiEmbedContentResponse = dict(payload)  # type: ignore[assignment]
        return response

    # ------------------------------------------------- batchEmbedContents

    async def batch_embed_contents(
        self,
        requests: Sequence[EmbedContentRequestLike],
        *,
        options: Optional[RequestOptions] = None,
    ) -> GeminiBatchEmbedContentsResponse:
        """Embeds up to 100 contents; `embeddings[]` preserves request order.

        The protocol-mandatory per-sub-request `model` field is injected
        automatically as `models/{model}` from the client-level model."""
        if not isinstance(requests, (list, tuple)) or not requests:
            raise _bad_request("requests must be a non-empty sequence")
        if len(requests) > GEMINI_EMBEDDING_MAX_BATCH_SIZE:
            raise _bad_request(
                f"batch size must not exceed {GEMINI_EMBEDDING_MAX_BATCH_SIZE}"
            )

        wire_requests: list[dict[str, Any]] = []
        for idx, item in enumerate(requests):
            if isinstance(item, str):
                item = {"content": {"parts": [{"text": item}]}}
            if not isinstance(item, Mapping):
                raise _bad_request(f"requests[{idx}] must be a string or a request object")
            sub = dict(item)
            content_obj = sub.get("content")
            if not isinstance(content_obj, Mapping):
                raise _bad_request(f"requests[{idx}].content must be an object")
            _validate_parts(content_obj)
            # Section 3.2: every sub-request MUST carry model matching the URL.
            sub["model"] = f"models/{self._model}"
            wire_requests.append(sub)

        payload = await self.post_json(
            f"/v1beta/{self._model_path()}:batchEmbedContents",
            {"requests": wire_requests},
            options=options,
        )
        embeddings = payload.get("embeddings")
        if not isinstance(embeddings, list) or len(embeddings) != len(wire_requests):
            raise LLMClientError(
                kind=ErrorKind.PROTOCOL_ERROR,
                message=(
                    "BatchEmbedContents response must contain embeddings[] "
                    "aligned with the request order/length"
                ),
                is_retryable=False,
                attempt=0,
            )
        response: GeminiBatchEmbedContentsResponse = dict(payload)  # type: ignore[assignment]
        return response

    # ------------------------------------------------------- countTokens

    async def count_tokens(
        self,
        text: str,
        *,
        options: Optional[RequestOptions] = None,
    ) -> int:
        """Counts tokens via `models/{model}:countTokens` for one text."""
        if not isinstance(text, str) or text == "":
            raise _bad_request("text must be a non-empty string")

        payload = await self.post_json(
            f"/v1beta/{self._model_path()}:countTokens",
            {"contents": [{"parts": [{"text": text}]}]},
            options=options,
        )
        total = payload.get("totalTokens")
        if not isinstance(total, int) or isinstance(total, bool) or total < 0:
            raise LLMClientError(
                kind=ErrorKind.PROTOCOL_ERROR,
                message="countTokens response must contain a non-negative integer totalTokens",
                is_retryable=False,
                attempt=0,
            )
        return total
