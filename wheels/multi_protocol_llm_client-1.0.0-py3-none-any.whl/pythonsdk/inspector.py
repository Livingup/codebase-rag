from __future__ import annotations

import copy
import inspect
import json
from dataclasses import dataclass
from typing import Any, Callable, Literal, Mapping, Optional, Sequence

from .errors import LLMClientError

ProviderName = Literal["openai", "claude", "gemini", "deepseek", "dashscope"]
ExchangeOutcome = Literal["completed", "http_error", "stream_error", "aborted"]


@dataclass(frozen=True)
class RequestWireContext:
    """Wire context emitted right before the HTTP request is sent (FR-HOOK-02.1)."""

    trace_id: str
    attempt: int
    provider: ProviderName
    timestamp_ms: int
    method: str
    url: str
    headers: Mapping[str, str]
    body_object: Mapping[str, Any]
    raw_body: str


@dataclass(frozen=True)
class ResponseHeadersWireContext:
    """Wire context emitted immediately upon receiving HTTP response headers (FR-HOOK-02.2)."""

    trace_id: str
    attempt: int
    provider: ProviderName
    timestamp_ms: int
    status: int
    status_text: str
    headers: Mapping[str, str]
    ttfb_ms: int


@dataclass(frozen=True)
class RawStreamChunkContext:
    """Wire context emitted whenever a raw decoded SSE text chunk arrives (FR-HOOK-02.3)."""

    trace_id: str
    attempt: int
    provider: ProviderName
    timestamp_ms: int
    raw_chunk: str


@dataclass(frozen=True)
class ExchangeCompleteWireContext:
    """Wire context emitted when a single HTTP attempt finishes for any reason (FR-HOOK-02.4)."""

    trace_id: str
    attempt: int
    provider: ProviderName
    timestamp_ms: int
    outcome: ExchangeOutcome
    duration_ms: int
    raw_response_body: str
    error: Optional[LLMClientError] = None


class HttpInspector:
    """
    Observer interface for pluggable HTTP wire-logging and auditing (FR-HOOK-01 ~ 03).
    Subclasses or custom implementations can override any subset of the 4 lifecycle hooks.
    Both synchronous and async hook methods are supported.
    """

    def on_request(self, ctx: RequestWireContext) -> Any:
        pass

    def on_response_headers(self, ctx: ResponseHeadersWireContext) -> Any:
        pass

    def on_raw_stream_chunk(self, ctx: RawStreamChunkContext) -> Any:
        pass

    def on_exchange_complete(self, ctx: ExchangeCompleteWireContext) -> Any:
        pass


class HttpInspectorDispatcher:
    """
    Composite / Chain Dispatcher that invokes all registered HttpInspectors
    inside an isolated exception sandbox (FR-HOOK-03).
    """

    def __init__(self, inspectors: Sequence[HttpInspector] = ()) -> None:
        self._inspectors: list[HttpInspector] = list(inspectors)

    def add(self, inspector: HttpInspector) -> None:
        self._inspectors.append(inspector)

    def with_additional(
        self, extra: Optional[Sequence[HttpInspector]]
    ) -> HttpInspectorDispatcher:
        if not extra:
            return self
        return HttpInspectorDispatcher([*self._inspectors, *extra])

    async def _safe_invoke(self, method_name: str, ctx: Any) -> None:
        for inspector in self._inspectors:
            hook = getattr(inspector, method_name, None)
            if hook is None:
                continue
            try:
                result = hook(ctx)
                if inspect.isawaitable(result):
                    await result
            except Exception:
                # FR-HOOK-03.2: Inspector exceptions must NEVER interrupt the main LLM request flow
                pass

    async def emit_request(self, ctx: RequestWireContext) -> None:
        await self._safe_invoke("on_request", ctx)

    async def emit_response_headers(self, ctx: ResponseHeadersWireContext) -> None:
        await self._safe_invoke("on_response_headers", ctx)

    async def emit_raw_stream_chunk(self, ctx: RawStreamChunkContext) -> None:
        await self._safe_invoke("on_raw_stream_chunk", ctx)

    async def emit_exchange_complete(self, ctx: ExchangeCompleteWireContext) -> None:
        await self._safe_invoke("on_exchange_complete", ctx)


# ============================================================================
# Pure Helper Functions for Header Masking & Multimodal Payload Truncation (FR-HOOK-04)
# ============================================================================


def _mask_secret_value(val: str) -> str:
    if len(val) <= 10:
        return "***"
    # FR-HOOK-04: keep the first 6 and last 4 characters (e.g. Bearer tokens).
    if val.lower().startswith("bearer "):
        token = val[7:]
        if len(token) > 10:
            return f"Bearer {token[:6]}***{token[-4:]}"
        return "Bearer ***"
    return f"{val[:6]}***{val[-4:]}"


def mask_sensitive_headers(headers: Mapping[str, str]) -> dict[str, str]:
    """
    Pure helper function that masks sensitive authentication headers.
    Recognizes (case-insensitively, by substring) authorization, api-key,
    x-api-key, x-goog-api-key, cookie / set-cookie style keys.
    """
    masked: dict[str, str] = {}
    for k, v in headers.items():
        kl = k.lower()
        if (
            "authorization" in kl
            or "api-key" in kl
            or "cookie" in kl
            or "token" in kl
        ):
            masked[k] = _mask_secret_value(v)
        else:
            masked[k] = v
    return masked


def truncate_large_strings(payload: Any, max_length: int = 512) -> Any:
    """
    Pure helper function that recursively clones a JSON structure (dict, list, or
    plain string) and collapses strings longer than `max_length` (such as
    multi-megabyte Base64 images/PDFs or encrypted reasoning payloads) into a
    concise summary string (FR-HOOK-04).
    """
    if isinstance(payload, str):
        if len(payload) > max_length:
            preview = payload[:48]
            return (
                f"<Truncated string: totalLength={len(payload)}, "
                f"preview='{preview}...'>"
            )
        return payload

    if isinstance(payload, Mapping):
        return {
            k: truncate_large_strings(v, max_length=max_length)
            for k, v in payload.items()
        }

    if isinstance(payload, list):
        return [truncate_large_strings(item, max_length=max_length) for item in payload]

    return copy.deepcopy(payload)


class LoggingHttpInspector(HttpInspector):
    """
    Ready-to-use concrete HttpInspector implementation that formats and outputs
    masked HTTP request/response wire payloads to a custom logger callback (e.g., print or logging.info).
    """

    def __init__(
        self,
        sink: Callable[[str], None] = print,
        truncate_max_length: int = 512,
        log_raw_chunks: bool = False,
    ) -> None:
        self._sink = sink
        self._truncate_max_length = truncate_max_length
        self._log_raw_chunks = log_raw_chunks

    def on_request(self, ctx: RequestWireContext) -> None:
        safe_headers = mask_sensitive_headers(ctx.headers)
        safe_body = truncate_large_strings(
            ctx.body_object, max_length=self._truncate_max_length
        )
        self._sink(
            f"[HTTP-REQ] trace={ctx.trace_id} attempt={ctx.attempt} "
            f"{ctx.method} {ctx.url}\n"
            f"  Headers: {json.dumps(safe_headers, ensure_ascii=False)}\n"
            f"  Body: {json.dumps(safe_body, ensure_ascii=False)}"
        )

    def on_response_headers(self, ctx: ResponseHeadersWireContext) -> None:
        safe_headers = mask_sensitive_headers(ctx.headers)
        self._sink(
            f"[HTTP-RES-HEADERS] trace={ctx.trace_id} attempt={ctx.attempt} "
            f"status={ctx.status} {ctx.status_text} ttfb={ctx.ttfb_ms}ms "
            f"headers={json.dumps(safe_headers, ensure_ascii=False)}"
        )

    def on_raw_stream_chunk(self, ctx: RawStreamChunkContext) -> None:
        if self._log_raw_chunks:
            self._sink(
                f"[HTTP-RAW-CHUNK] trace={ctx.trace_id} attempt={ctx.attempt} "
                f"bytes={len(ctx.raw_chunk)}"
            )

    def on_exchange_complete(self, ctx: ExchangeCompleteWireContext) -> None:
        summary_body = truncate_large_strings(
            ctx.raw_response_body, max_length=self._truncate_max_length
        )
        self._sink(
            f"[HTTP-COMPLETE] trace={ctx.trace_id} attempt={ctx.attempt} "
            f"outcome={ctx.outcome} duration={ctx.duration_ms}ms "
            f"body={summary_body}"
        )
