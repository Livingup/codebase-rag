"""
Complete async unit + local real-socket integration test suite for the
multi-protocol LLM client SDK (see LLM_CLIENT_SDK_REQUIREMENTS.md).

Run from the repository root (G:\\project\\llm-sdk):

    python -m unittest pythonsdk.tests.test_llm_client_sdk -v
"""

from __future__ import annotations

import asyncio
import json
import sys
import time
import unittest
from pathlib import Path
from typing import Any, Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from pythonsdk.base_client import ClientConfig, RequestOptions, to_serializable_dict
from pythonsdk.cancellation import CancellationToken
from pythonsdk.claude_messages import (
    ClaudeMessagesClient,
    ClaudeMessagesRequest,
)
from pythonsdk.deepseek_tools import DeepSeekToolsClient
from pythonsdk.gemini_embedding import (
    GeminiEmbeddingClient,
    cosine_similarity,
    l2_normalize,
)
from pythonsdk.errors import (
    ErrorKind,
    LLMClientError,
    classify_http_error,
    classify_stream_or_network_error,
)
from pythonsdk.gemini_stream import (
    GeminiStreamClient,
    GeminiStreamRequest,
)
from pythonsdk.inspector import (
    HttpInspector,
    mask_sensitive_headers,
    truncate_large_strings,
)
from pythonsdk.openai_chat_completions import (
    OpenAIChatCompletionsClient,
    OpenAIChatCompletionsRequest,
)
from pythonsdk.openai_responses import (
    OpenAIResponsesClient,
    OpenAIResponsesRequest,
)
from pythonsdk.retry import RetryPolicy, parse_retry_after_ms
from pythonsdk.sse import ChunkSafeSseParser
from pythonsdk.transport import (
    AsyncHttpResponse,
    AsyncHttpTransport,
    TransportTimeouts,
)


# ============================================================================
# Test doubles
# ============================================================================


class MockResponse(AsyncHttpResponse):
    def __init__(
        self,
        chunks: Optional[list[bytes]] = None,
        status: int = 200,
        headers: Optional[dict[str, str]] = None,
        stream_error: Optional[BaseException] = None,
    ) -> None:
        self._status = status
        self._status_text = "OK" if status < 400 else "Error"
        self._headers = headers or {"Content-Type": "text/event-stream"}
        self._chunks = list(chunks or [])
        self._stream_error = stream_error
        self.closed = False

    @property
    def status(self) -> int:
        return self._status

    @property
    def status_text(self) -> str:
        return self._status_text

    @property
    def headers(self) -> dict[str, str]:
        return self._headers

    async def iter_bytes(self, cancel_token=None, idle_timeout_ms: int = 120000):
        for chunk in self._chunks:
            yield chunk
        if self._stream_error is not None:
            raise self._stream_error

    async def read_all(self, cancel_token=None, timeout_ms: int = 30000) -> bytes:
        return b"".join(self._chunks)

    async def close(self) -> None:
        self.closed = True


class EndlessMockResponse(MockResponse):
    """Response that emits an initial frame and then pings forever."""

    def __init__(self, initial_chunks: Optional[list[bytes]] = None) -> None:
        super().__init__(chunks=initial_chunks)

    async def iter_bytes(self, cancel_token=None, idle_timeout_ms: int = 120000):
        for chunk in self._chunks:
            yield chunk
        while True:
            yield b": ping\n\n"
            await asyncio.sleep(0.01)


class MockTransport(AsyncHttpTransport):
    def __init__(self, responses: list[Any]) -> None:
        self.responses = list(responses)
        self.requests: list[dict[str, Any]] = []

    async def send_stream(
        self,
        method: str,
        url: str,
        headers,
        body: bytes,
        timeouts: TransportTimeouts,
        cancel_token=None,
    ) -> AsyncHttpResponse:
        self.requests.append(
            {"method": method, "url": url, "headers": dict(headers), "body": body}
        )
        item = self.responses.pop(0) if self.responses else MockResponse([])
        if isinstance(item, Exception):
            raise item
        return item


class RecordingInspector(HttpInspector):
    def __init__(self) -> None:
        self.requests: list[Any] = []
        self.response_headers: list[Any] = []
        self.raw_chunks: list[Any] = []
        self.completions: list[Any] = []
        self.raise_on_request = False

    def on_request(self, ctx) -> None:
        if self.raise_on_request:
            raise RuntimeError("inspector hook boom")
        self.requests.append(ctx)

    def on_response_headers(self, ctx) -> None:
        self.response_headers.append(ctx)

    def on_raw_stream_chunk(self, ctx) -> None:
        self.raw_chunks.append(ctx)

    def on_exchange_complete(self, ctx) -> None:
        self.completions.append(ctx)


class _ScriptedHttpServer:
    """Local real-socket HTTP server writing scripted raw byte responses."""

    def __init__(self, responses: list[bytes]) -> None:
        self.responses = list(responses)
        self.received: list[dict[str, Any]] = []
        self._server: Optional[asyncio.AbstractServer] = None
        self.base_url = ""

    async def start(self) -> "_ScriptedHttpServer":
        self._server = await asyncio.start_server(self._handle, "127.0.0.1", 0)
        port = self._server.sockets[0].getsockname()[1]
        self.base_url = f"http://127.0.0.1:{port}"
        return self

    async def stop(self) -> None:
        if self._server is not None:
            self._server.close()
            await self._server.wait_closed()

    async def _handle(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        try:
            head = await reader.readuntil(b"\r\n\r\n")
            content_length = 0
            for line in head.split(b"\r\n"):
                lower = line.lower()
                if lower.startswith(b"content-length:"):
                    content_length = int(line.split(b":", 1)[1].strip())
            body = await reader.readexactly(content_length) if content_length else b""
            self.received.append(
                {
                    "head": head,
                    "body": body,
                    "headers": dict(
                        line.split(b":", 1)
                        for line in head.split(b"\r\n")[1:]
                        if b":" in line
                    ),
                }
            )
            resp = self.responses.pop(0) if self.responses else b""
            if resp:
                writer.write(resp)
                await writer.drain()
        except Exception:
            pass
        finally:
            try:
                writer.close()
                await writer.wait_closed()
            except Exception:
                pass


def _sse_headers(extra: str = "Transfer-Encoding: chunked\r\n") -> bytes:
    return (
        b"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\n" + extra.encode() + b"\r\n"
    )


def _chunked(payload: bytes) -> bytes:
    out = b""
    for i in range(0, len(payload), 64):
        piece = payload[i : i + 64]
        out += f"{len(piece):x}".encode() + b"\r\n" + piece + b"\r\n"
    out += b"0\r\n\r\n"
    return out


def sse_frame(event: Optional[str], data: Any) -> bytes:
    lines = []
    if event:
        lines.append(f"event: {event}")
    lines.append(f"data: {json.dumps(data, ensure_ascii=False)}")
    return ("\n".join(lines) + "\n\n").encode("utf-8")


async def collect_events(agen, fail_on_error: bool = True):
    events = []
    try:
        async for ev in agen:
            events.append(ev)
    except Exception as exc:  # noqa: BLE001
        if fail_on_error:
            raise
        events.append(exc)
    return events


def types_of(events) -> list[str]:
    return [getattr(e, "type", type(e).__name__) for e in events]


# ============================================================================
# 1. SSE parser (NFR-3, P1 fix: CRLF split across chunks / BOM / event-only)
# ============================================================================


class TestSseParser(unittest.TestCase):
    def test_crlf_split_across_chunks(self):
        parser = ChunkSafeSseParser()
        _, frames1 = parser.feed_bytes(b"event: foo\r")
        self.assertEqual(frames1, [])
        _, frames2 = parser.feed_bytes(b"\ndata: X\r\n\r\n")
        self.assertEqual(len(frames2), 1)
        self.assertEqual(frames2[0].event, "foo")
        self.assertEqual(frames2[0].data, "X")

    def test_lone_cr_line_endings(self):
        parser = ChunkSafeSseParser()
        _, frames = parser.feed_bytes(b"event: foo\rdata: Y\r\r")
        _, final_frames = parser.feed_bytes(b"", final=True)
        frames += final_frames
        self.assertEqual(len(frames), 1)
        self.assertEqual(frames[0].event, "foo")
        self.assertEqual(frames[0].data, "Y")

    def test_multiline_data_joined(self):
        parser = ChunkSafeSseParser()
        _, frames = parser.feed_bytes(b"data: line1\ndata: line2\n\n")
        self.assertEqual(frames[0].data, "line1\nline2")

    def test_bom_stripped(self):
        parser = ChunkSafeSseParser()
        _, frames = parser.feed_bytes(b"\xef\xbb\xbfdata: hi\n\n")
        self.assertEqual(len(frames), 1)
        self.assertEqual(frames[0].data, "hi")

    def test_event_without_data_not_dispatched(self):
        parser = ChunkSafeSseParser()
        _, frames = parser.feed_bytes(b"event: only\n\n")
        self.assertEqual(frames, [])

    def test_utf8_multibyte_split_across_chunks(self):
        parser = ChunkSafeSseParser()
        raw = "data: 你好\n\n".encode("utf-8")
        mid = 8  # cut inside a multi-byte character
        _, f1 = parser.feed_bytes(raw[:mid])
        _, f2 = parser.feed_bytes(raw[mid:])
        frames = f1 + f2
        self.assertEqual(len(frames), 1)
        self.assertEqual(frames[0].data, "你好")

    def test_eof_without_trailing_blank_line_flushes(self):
        parser = ChunkSafeSseParser()
        _, frames = parser.feed_bytes(b"data: tail", final=True)
        self.assertEqual(len(frames), 1)
        self.assertEqual(frames[0].data, "tail")

    def test_comment_lines_ignored(self):
        parser = ChunkSafeSseParser()
        _, frames = parser.feed_bytes(b": ping\n\ndata: real\n\n")
        self.assertEqual(len(frames), 1)
        self.assertEqual(frames[0].data, "real")


# ============================================================================
# 2. Serialization & custom_body_json pipeline (Section 5.2)
# ============================================================================


class TestSerialization(unittest.TestCase):
    def test_mapping_none_values_preserved(self):
        result = to_serializable_dict({"a": None, "b": 0, "c": False, "d": [], "e": ""})
        self.assertEqual(result, {"a": None, "b": 0, "c": False, "d": [], "e": ""})

    def test_dataclass_none_fields_omitted(self):
        from dataclasses import dataclass

        @dataclass
        class Demo:
            x: int = 1
            y: Optional[int] = None

        self.assertEqual(to_serializable_dict(Demo()), {"x": 1})

    def _openai_client(self) -> OpenAIResponsesClient:
        return OpenAIResponsesClient(ClientConfig(api_key="sk-test"))

    def _openai_req(self, **kwargs) -> OpenAIResponsesRequest:
        return OpenAIResponsesRequest(model="gpt-5", input="hi", **kwargs)

    def test_include_injected_when_store_false_default(self):
        raw, root = self._openai_client().build_final_request_body(self._openai_req())
        self.assertEqual(root["include"], ["reasoning.encrypted_content"])
        self.assertIn('"include"', raw)

    def test_include_injected_even_without_reasoning_config(self):
        # Regression: previously the injection required an explicit reasoning param
        raw, root = self._openai_client().build_final_request_body(
            self._openai_req(store=False)
        )
        self.assertEqual(root["include"], ["reasoning.encrypted_content"])

    def test_include_absent_when_store_true(self):
        _, root = self._openai_client().build_final_request_body(
            self._openai_req(store=True)
        )
        self.assertNotIn("include", root)

    def test_user_include_not_duplicated(self):
        _, root = self._openai_client().build_final_request_body(
            self._openai_req(include=["reasoning.encrypted_content"])
        )
        self.assertEqual(root["include"], ["reasoning.encrypted_content"])

    def test_custom_body_json_shallow_override(self):
        custom = json.dumps({"store": True, "top_p": 0.5, "brand_new": [1, 2]})
        raw, root = self._openai_client().build_final_request_body(
            self._openai_req(top_p=0.9), custom
        )
        self.assertEqual(root["store"], True)  # whole-key replacement
        self.assertEqual(root["top_p"], 0.5)
        self.assertEqual(root["brand_new"], [1, 2])  # new key added
        self.assertEqual(json.loads(raw), root)

    def test_custom_body_json_invalid_raises_bad_request(self):
        from pythonsdk.errors import LLMClientError

        with self.assertRaises(LLMClientError) as ctx:
            self._openai_client().build_final_request_body(
                self._openai_req(), "{not json"
            )
        self.assertEqual(ctx.exception.kind, ErrorKind.BAD_REQUEST)
        self.assertEqual(ctx.exception.attempt, 0)

    def test_custom_body_json_non_object_root_raises(self):
        from pythonsdk.errors import LLMClientError

        with self.assertRaises(LLMClientError) as ctx:
            self._openai_client().build_final_request_body(self._openai_req(), "[1,2]")
        self.assertEqual(ctx.exception.kind, ErrorKind.BAD_REQUEST)

    def test_custom_body_json_blank_skipped(self):
        _, root = self._openai_client().build_final_request_body(
            self._openai_req(top_p=0.9), "   "
        )
        self.assertEqual(root["top_p"], 0.9)

    def test_client_level_default_custom_body_json(self):
        client = OpenAIResponsesClient(
            ClientConfig(api_key="k", default_custom_body_json='{"top_p": 0.1}')
        )
        _, root = client.build_final_request_body(self._openai_req())
        self.assertEqual(root["top_p"], 0.1)


# ============================================================================
# 3. Error classification & retry backoff parsing (FR-RETRY-02/03/04/05)
# ============================================================================


class TestErrorsAndRetry(unittest.TestCase):
    def test_parse_retry_after_compound_durations(self):
        self.assertEqual(parse_retry_after_ms("6m0s"), 360000)
        self.assertEqual(parse_retry_after_ms("1m30s"), 90000)
        self.assertEqual(parse_retry_after_ms("1s"), 1000)
        self.assertEqual(parse_retry_after_ms("500ms"), 500)
        self.assertEqual(parse_retry_after_ms("0.5s"), 500)
        self.assertEqual(parse_retry_after_ms("2"), 2000)
        self.assertIsNone(parse_retry_after_ms("garbage"))
        self.assertIsNone(parse_retry_after_ms(None))

    def test_retryable_status_matrix(self):
        cases = {
            408: True, 409: True, 429: True, 500: True, 502: True,
            503: True, 504: True, 529: True,
            400: False, 401: False, 403: False, 404: False, 413: False,
            422: False, 501: False, 505: False, 418: False,
        }
        for code, retryable in cases.items():
            err = classify_http_error(code, {}, "", attempt=1)
            self.assertEqual(err.is_retryable, retryable, f"status {code}")
            if code == 429:
                self.assertEqual(err.kind, ErrorKind.RATE_LIMIT)
            if code == 529:
                self.assertEqual(err.kind, ErrorKind.OVERLOADED)
            if code in (401, 403):
                self.assertEqual(err.kind, ErrorKind.AUTH_ERROR)
            if code in (501, 505):
                self.assertEqual(err.kind, ErrorKind.SERVER_ERROR)

    def test_x_ratelimit_reset_wildcard_headers(self):
        err = classify_http_error(
            429, {"x-ratelimit-reset-tokens": "6m0s"}, "", attempt=1
        )
        self.assertEqual(err.retry_after_header, "6m0s")
        self.assertEqual(parse_retry_after_ms(err.retry_after_header), 360000)

    def test_value_error_maps_to_protocol_error(self):
        err = classify_stream_or_network_error(ValueError("bad chunk size"), attempt=1)
        self.assertEqual(err.kind, ErrorKind.PROTOCOL_ERROR)
        self.assertFalse(err.is_retryable)

    def test_connection_error_maps_to_retryable_network_error(self):
        err = classify_stream_or_network_error(ConnectionResetError("boom"), attempt=1)
        self.assertEqual(err.kind, ErrorKind.NETWORK_ERROR)
        self.assertTrue(err.is_retryable)


# ============================================================================
# 4. Inspector helpers (FR-HOOK-04)
# ============================================================================


class TestInspectorHelpers(unittest.TestCase):
    def test_mask_bearer_keeps_first6_last4(self):
        masked = mask_sensitive_headers(
            {"Authorization": "Bearer sk-proj-abcdefghijklmnop"}
        )
        self.assertEqual(masked["Authorization"], "Bearer sk-pro***mnop")

    def test_mask_short_secret_fully_hidden(self):
        masked = mask_sensitive_headers({"x-api-key": "short"})
        self.assertEqual(masked["x-api-key"], "***")

    def test_mask_substring_keys(self):
        masked = mask_sensitive_headers(
            {"X-Goog-Api-Key": "0123456789ABCDEF", "X-Auth-Token": "0123456789ABCDEF"}
        )
        self.assertNotEqual(masked["X-Goog-Api-Key"], "0123456789ABCDEF")
        self.assertNotEqual(masked["X-Auth-Token"], "0123456789ABCDEF")

    def test_truncate_format_matches_requirement(self):
        out = truncate_large_strings({"img": "x" * 600}, max_length=512)
        self.assertIn("totalLength=600", out["img"])
        self.assertIn("preview='", out["img"])

    def test_truncate_keeps_short_strings(self):
        out = truncate_large_strings({"a": "short", "n": 5, "l": [1, 2]}, max_length=512)
        self.assertEqual(out, {"a": "short", "n": 5, "l": [1, 2]})


# ============================================================================
# 5. OpenAI state machine (Section 5.4.1 + P0/P1 fixes)
# ============================================================================


class TestOpenAIStateMachine(unittest.IsolatedAsyncioTestCase):
    def _client(self, transport: AsyncHttpTransport) -> OpenAIResponsesClient:
        return OpenAIResponsesClient(ClientConfig(api_key="k"), transport=transport)

    def _req(self) -> OpenAIResponsesRequest:
        return OpenAIResponsesRequest(model="gpt-5", input="hi")

    async def test_full_flow_events(self):
        frames = b"".join(
            [
                sse_frame(
                    "response.created",
                    {"type": "response.created", "response": {"id": "resp_1", "model": "gpt-5"}},
                ),
                sse_frame(
                    "response.output_item.added",
                    {
                        "type": "response.output_item.added",
                        "output_index": 0,
                        "item": {"type": "message", "id": "msg_1"},
                    },
                ),
                sse_frame(
                    "response.output_text.delta",
                    {"type": "response.output_text.delta", "output_index": 0, "delta": "Hel"},
                ),
                sse_frame(
                    "response.output_text.delta",
                    {"type": "response.output_text.delta", "output_index": 0, "delta": "lo"},
                ),
                sse_frame(
                    "response.output_item.done",
                    {
                        "type": "response.output_item.done",
                        "output_index": 0,
                        "item": {"type": "message", "id": "msg_1", "content": []},
                    },
                ),
                sse_frame(
                    "response.completed",
                    {
                        "type": "response.completed",
                        "response": {
                            "id": "resp_1",
                            "status": "completed",
                            "usage": {"input_tokens": 3, "output_tokens": 2},
                            "output": [{"type": "message", "id": "msg_1"}],
                        },
                    },
                ),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        self.assertEqual(
            types_of(events),
            [
                "request_start", "response_start", "text_start",
                "text_delta", "text_delta", "text_stop", "response_complete",
            ],
        )
        complete = events[-1]
        self.assertEqual(complete.usage.input_tokens, 3)
        self.assertEqual(complete.output, [{"type": "message", "id": "msg_1"}])

    async def test_tool_call_start_is_immediate(self):
        frames = b"".join(
            [
                sse_frame("response.created", {"type": "response.created", "response": {"id": "r", "model": "m"}}),
                sse_frame(
                    "response.output_item.added",
                    {
                        "type": "response.output_item.added",
                        "output_index": 0,
                        "item": {"type": "function_call", "id": "fc_1", "call_id": "call_1", "name": "get_weather"},
                    },
                ),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        agen = self._client(transport).stream(self._req())
        events = []
        async for ev in agen:
            events.append(ev)
            if ev.type == "tool_call_start":
                break
        await agen.aclose()
        self.assertEqual(events[-1].call_id, "call_1")
        self.assertEqual(events[-1].name, "get_weather")

    async def test_truncated_stream_raises_protocol_error(self):
        # Clean EOF (chunks exhausted) but no response.completed terminal event.
        frames = sse_frame(
            "response.created", {"type": "response.created", "response": {"id": "r", "model": "m"}}
        )
        transport = MockTransport([MockResponse([frames])])
        from pythonsdk.errors import LLMClientError

        with self.assertRaises(LLMClientError) as ctx:
            async for _ in self._client(transport).stream(self._req()):
                pass
        self.assertEqual(ctx.exception.kind, ErrorKind.PROTOCOL_ERROR)
        self.assertNotIn("response_complete", types_of([]))

    async def test_malformed_output_index_null_no_typeerror(self):
        frames = b"".join(
            [
                sse_frame(
                    "response.output_item.added",
                    {
                        "type": "response.output_item.added",
                        "output_index": None,  # malformed wire value
                        "item": {"type": "message", "id": "msg_1"},
                    },
                ),
                sse_frame(
                    "response.completed",
                    {"type": "response.completed", "response": {"id": "r", "status": "completed", "usage": {}, "output": []}},
                ),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(
            self._client(transport).stream(self._req()), fail_on_error=True
        )
        self.assertIn("text_start", types_of(events))

    async def test_tool_search_client_mode_event_pair_consistent(self):
        # execution:"client" tool_search_call is a client-executed call per
        # FR-STATE-06; the stop event must follow the added frame's mode even
        # when the done frame omits the `execution` field.
        frames = b"".join(
            [
                sse_frame("response.created", {"type": "response.created", "response": {"id": "r", "model": "m"}}),
                sse_frame(
                    "response.output_item.added",
                    {
                        "type": "response.output_item.added",
                        "output_index": 0,
                        "item": {
                            "type": "tool_search_call",
                            "id": "ts_1",
                            "call_id": "call_search_99",
                            "name": "tool_search",
                            "execution": "client",
                        },
                    },
                ),
                sse_frame(
                    "response.output_item.done",
                    {
                        "type": "response.output_item.done",
                        "output_index": 0,
                        "item": {
                            "type": "tool_search_call",
                            "id": "ts_1",
                            "call_id": "call_search_99",
                            "name": "tool_search",
                            "arguments": {"query": "db tools"},
                        },
                    },
                ),
                sse_frame(
                    "response.completed",
                    {"type": "response.completed", "response": {"id": "r", "status": "completed", "usage": {}, "output": []}},
                ),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        types = types_of(events)
        self.assertIn("tool_call_start", types)
        self.assertIn("tool_call_stop", types)
        self.assertNotIn("server_tool_start", types)
        self.assertNotIn("server_tool_stop", types)

    async def test_stream_error_event_classification(self):
        frames = sse_frame(
            "error",
            {"type": "error", "error": {"code": "rate_limit_exceeded", "message": "slow down"}},
        )
        transport = MockTransport([MockResponse([frames])])
        from pythonsdk.errors import LLMClientError

        with self.assertRaises(LLMClientError) as ctx:
            async for _ in self._client(transport).stream(
                self._req(),
                RequestOptions(retry_policy=RetryPolicy(max_attempts=1)),
            ):
                pass
        self.assertEqual(ctx.exception.kind, ErrorKind.RATE_LIMIT)
        self.assertTrue(ctx.exception.is_retryable)


# ============================================================================
# 5b. OpenAI Chat Completions state machine & serialization
#     (docs/OPENAI_CHAT_COMPLETIONS_API.md)
# ============================================================================


def cc_done_frame() -> bytes:
    return b"data: [DONE]\n\n"


class TestOpenAIChatCompletions(unittest.IsolatedAsyncioTestCase):
    def _client(self, transport: AsyncHttpTransport) -> OpenAIChatCompletionsClient:
        return OpenAIChatCompletionsClient(ClientConfig(api_key="k"), transport=transport)

    def _req(self, **overrides) -> OpenAIChatCompletionsRequest:
        base = {"model": "gpt-5.4", "messages": [{"role": "user", "content": "hi"}]}
        base.update(overrides)
        return OpenAIChatCompletionsRequest(**base)

    def _chunk(self, delta=None, finish_reason=None, index=0, **extra) -> bytes:
        choice: dict[str, Any] = {"index": index, "delta": delta or {}, "finish_reason": finish_reason}
        payload: dict[str, Any] = {
            "id": "chatcmpl-1",
            "object": "chat.completion.chunk",
            "created": 1741569952,
            "model": "gpt-5.4",
            "choices": [choice],
        }
        payload.update(extra)
        return sse_frame(None, payload)

    # ---------------------------------------------------------- serialization

    def test_serialization_injects_include_usage(self):
        client = OpenAIChatCompletionsClient(ClientConfig(api_key="k"))
        _, root = client.build_final_request_body(self._req())
        self.assertEqual(root["stream"], True)
        self.assertEqual(root["stream_options"], {"include_usage": True})

    def test_serialization_merges_user_stream_options(self):
        client = OpenAIChatCompletionsClient(ClientConfig(api_key="k"))
        _, root = client.build_final_request_body(
            self._req(stream_options={"include_obfuscation": True})
        )
        self.assertEqual(
            root["stream_options"], {"include_obfuscation": True, "include_usage": True}
        )

    def test_serialization_omits_unset_optionals(self):
        client = OpenAIChatCompletionsClient(ClientConfig(api_key="k"))
        _, root = client.build_final_request_body(self._req())
        for absent in ("temperature", "top_p", "tools", "tool_choice", "max_tokens"):
            self.assertNotIn(absent, root)

    def test_serialization_carries_optional_fields(self):
        client = OpenAIChatCompletionsClient(ClientConfig(api_key="k"))
        _, root = client.build_final_request_body(
            self._req(
                temperature=0.2,
                reasoning_effort="low",
                tools=[
                    {
                        "type": "function",
                        "function": {
                            "name": "f",
                            "parameters": {"type": "object", "properties": {}},
                        },
                    }
                ],
            )
        )
        self.assertEqual(root["temperature"], 0.2)
        self.assertEqual(root["reasoning_effort"], "low")
        self.assertEqual(root["tools"][0]["function"]["name"], "f")

    # ---------------------------------------------------------- state machine

    async def test_full_flow_events(self):
        frames = b"".join(
            [
                self._chunk(delta={"role": "assistant", "content": ""}),
                self._chunk(delta={"content": "Hel"}),
                self._chunk(delta={"content": "lo"}),
                self._chunk(delta={}, finish_reason="stop"),
                sse_frame(
                    None,
                    {
                        "id": "chatcmpl-1",
                        "object": "chat.completion.chunk",
                        "created": 1741569952,
                        "model": "gpt-5.4",
                        "choices": [],
                        "usage": {
                            "prompt_tokens": 5,
                            "completion_tokens": 2,
                            "total_tokens": 7,
                            "prompt_tokens_details": {"cached_tokens": 3},
                            "completion_tokens_details": {"reasoning_tokens": 1},
                        },
                    },
                ),
                cc_done_frame(),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        self.assertEqual(
            types_of(events),
            [
                "request_start", "response_start", "text_start",
                "text_delta", "text_delta", "text_stop", "response_complete",
            ],
        )
        complete = events[-1]
        self.assertEqual(complete.response_id, "chatcmpl-1")
        self.assertEqual(complete.stop_reason, "stop")
        self.assertEqual(complete.usage.input_tokens, 5)
        self.assertEqual(complete.usage.output_tokens, 2)
        self.assertEqual(complete.usage.reasoning_tokens, 1)
        self.assertEqual(complete.usage.cache_read_input_tokens, 3)
        # output is the replayable native assistant message (n=1 -> one entry)
        self.assertEqual(
            complete.output, [{"role": "assistant", "content": "Hello"}]
        )

    async def test_reasoning_content_thinking_lifecycle(self):
        frames = b"".join(
            [
                self._chunk(delta={"role": "assistant", "reasoning_content": "Let me "}),
                self._chunk(delta={"reasoning_content": "think."}),
                self._chunk(delta={"content": "Answer"}),
                self._chunk(delta={}, finish_reason="stop"),
                cc_done_frame(),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        self.assertEqual(
            types_of(events),
            [
                "request_start", "response_start",
                "thinking_start", "thinking_delta", "thinking_delta", "thinking_stop",
                "text_start", "text_delta", "text_stop", "response_complete",
            ],
        )
        thinking_stop = events[5]
        self.assertEqual(thinking_stop.text, "Let me think.")
        complete = events[-1]
        self.assertEqual(
            complete.output[0],
            {"role": "assistant", "reasoning_content": "Let me think.", "content": "Answer"},
        )

    async def test_reasoning_field_fallback_openrouter_style(self):
        frames = b"".join(
            [
                self._chunk(delta={"reasoning": "hmm"}),
                self._chunk(delta={"content": "ok"}),
                self._chunk(delta={}, finish_reason="stop"),
                cc_done_frame(),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        self.assertIn("thinking_delta", types_of(events))
        # the gateway's own field name is echoed back for replay
        self.assertEqual(
            events[-1].output[0],
            {"role": "assistant", "reasoning": "hmm", "content": "ok"},
        )

    async def test_tool_call_lifecycle_and_replay_shape(self):
        frames = b"".join(
            [
                self._chunk(
                    delta={
                        "role": "assistant",
                        "content": None,
                        "tool_calls": [
                            {
                                "index": 0,
                                "id": "call_1",
                                "type": "function",
                                "function": {"name": "get_weather", "arguments": ""},
                            }
                        ],
                    }
                ),
                self._chunk(
                    delta={"tool_calls": [{"index": 0, "function": {"arguments": "{\"ci"}}]}
                ),
                self._chunk(
                    delta={"tool_calls": [{"index": 0, "function": {"arguments": "ty\": \"Beijing\"}"}}]}
                ),
                self._chunk(delta={}, finish_reason="tool_calls"),
                cc_done_frame(),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        types = types_of(events)
        self.assertEqual(
            types,
            [
                "request_start", "response_start", "tool_call_start",
                "tool_call_delta", "tool_call_delta", "tool_call_stop",
                "response_complete",
            ],
        )
        stop = events[5]
        self.assertEqual(stop.call_id, "call_1")
        self.assertEqual(stop.name, "get_weather")
        self.assertEqual(stop.arguments_raw, '{"city": "Beijing"}')
        self.assertEqual(
            stop.raw_item,
            {
                "id": "call_1",
                "type": "function",
                "function": {"name": "get_weather", "arguments": '{"city": "Beijing"}'},
            },
        )
        complete = events[-1]
        self.assertEqual(complete.stop_reason, "tool_calls")
        self.assertEqual(
            complete.output[0],
            {
                "role": "assistant",
                "content": None,
                "tool_calls": [
                    {
                        "id": "call_1",
                        "type": "function",
                        "function": {"name": "get_weather", "arguments": '{"city": "Beijing"}'},
                    }
                ],
            },
        )

    async def test_custom_tool_call_lifecycle(self):
        frames = b"".join(
            [
                self._chunk(
                    delta={
                        "tool_calls": [
                            {
                                "index": 0,
                                "id": "call_c1",
                                "type": "custom",
                                "custom": {"name": "sql_executor", "input": ""},
                            }
                        ]
                    }
                ),
                self._chunk(
                    delta={"tool_calls": [{"index": 0, "custom": {"input": "SELECT 1"}}]}
                ),
                self._chunk(delta={}, finish_reason="tool_calls"),
                cc_done_frame(),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        types = types_of(events)
        self.assertIn("tool_call_start", types)
        start = next(e for e in events if e.type == "tool_call_start")
        self.assertEqual(start.tool_type, "custom")
        self.assertEqual(start.name, "sql_executor")
        stop = next(e for e in events if e.type == "tool_call_stop")
        self.assertEqual(stop.arguments_raw, "SELECT 1")
        self.assertEqual(
            stop.raw_item,
            {
                "id": "call_c1",
                "type": "custom",
                "custom": {"name": "sql_executor", "input": "SELECT 1"},
            },
        )

    async def test_parallel_tool_calls_two_buckets(self):
        frames = b"".join(
            [
                self._chunk(
                    delta={
                        "tool_calls": [
                            {"index": 0, "id": "call_a", "type": "function", "function": {"name": "fa", "arguments": "{}"}}
                        ]
                    }
                ),
                self._chunk(
                    delta={
                        "tool_calls": [
                            {"index": 1, "id": "call_b", "type": "function", "function": {"name": "fb", "arguments": "{}"}}
                        ]
                    }
                ),
                self._chunk(delta={}, finish_reason="tool_calls"),
                cc_done_frame(),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        complete = events[-1]
        self.assertEqual(len(complete.output[0]["tool_calls"]), 2)
        self.assertEqual(
            [tc["id"] for tc in complete.output[0]["tool_calls"]], ["call_a", "call_b"]
        )

    async def test_refusal_maps_to_text_lifecycle(self):
        frames = b"".join(
            [
                self._chunk(delta={"role": "assistant", "refusal": "Sorry, "}),
                self._chunk(delta={"refusal": "cannot."}),
                self._chunk(delta={}, finish_reason="stop"),
                cc_done_frame(),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        types = types_of(events)
        self.assertIn("text_start", types)
        self.assertIn("text_delta", types)
        self.assertIn("text_stop", types)
        complete = events[-1]
        self.assertEqual(complete.output[0]["refusal"], "Sorry, cannot.")

    async def test_truncated_stream_raises_protocol_error(self):
        # EOF without [DONE] and without any finish_reason.
        frames = self._chunk(delta={"content": "par"})
        transport = MockTransport([MockResponse([frames])])
        with self.assertRaises(LLMClientError) as ctx:
            async for _ in self._client(transport).stream(
                self._req(),
                RequestOptions(retry_policy=RetryPolicy(max_attempts=1)),
            ):
                pass
        self.assertEqual(ctx.exception.kind, ErrorKind.PROTOCOL_ERROR)

    async def test_eof_after_finish_reason_completes_tolerantly(self):
        # A proxy dropped the [DONE] sentinel but finish_reason already
        # arrived: complete instead of failing.
        frames = b"".join(
            [
                self._chunk(delta={"content": "ok"}),
                self._chunk(delta={}, finish_reason="stop"),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        self.assertEqual(types_of(events)[-1], "response_complete")
        self.assertEqual(events[-1].stop_reason, "stop")

    async def test_in_stream_error_frame_classification(self):
        frames = sse_frame(None, {"error": {"code": "rate_limit_exceeded", "message": "slow down"}})
        transport = MockTransport([MockResponse([frames])])
        with self.assertRaises(LLMClientError) as ctx:
            async for _ in self._client(transport).stream(
                self._req(),
                RequestOptions(retry_policy=RetryPolicy(max_attempts=1)),
            ):
                pass
        self.assertEqual(ctx.exception.kind, ErrorKind.RATE_LIMIT)
        self.assertTrue(ctx.exception.is_retryable)

    async def test_multiple_choices_assemble_per_choice(self):
        frames = b"".join(
            [
                self._chunk(index=0, delta={"role": "assistant", "content": "A"}),
                self._chunk(index=1, delta={"role": "assistant", "content": "B"}),
                self._chunk(index=0, delta={}, finish_reason="stop"),
                self._chunk(index=1, delta={}, finish_reason="stop"),
                cc_done_frame(),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req(n=2)))
        complete = events[-1]
        self.assertEqual(
            complete.output,
            [
                {"role": "assistant", "content": "A"},
                {"role": "assistant", "content": "B"},
            ],
        )

    async def test_audio_lifecycle_and_replay_reference(self):
        frames = b"".join(
            [
                self._chunk(delta={"audio": {"id": "audio_1", "data": "QUJD"}}),
                self._chunk(delta={"audio": {"data": "REVG", "transcript": "hello"}}),
                self._chunk(delta={}, finish_reason="stop"),
                cc_done_frame(),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        types = types_of(events)
        self.assertIn("audio_start", types)
        self.assertIn("audio_delta", types)
        self.assertIn("audio_stop", types)
        audio_stop = next(e for e in events if e.type == "audio_stop")
        self.assertEqual(audio_stop.total_base64_length, 8)
        complete = events[-1]
        # replay reference keeps only the id (docs Section 2.3.3)
        self.assertEqual(complete.output[0]["audio"], {"id": "audio_1"})
        self.assertIsNone(complete.output[0]["content"])

    async def test_annotations_accumulate_into_output(self):
        frames = b"".join(
            [
                self._chunk(delta={"role": "assistant", "content": "cite"}),
                self._chunk(
                    delta={
                        "annotations": [
                            {
                                "type": "url_citation",
                                "url_citation": {
                                    "start_index": 0,
                                    "end_index": 4,
                                    "title": "t",
                                    "url": "https://x",
                                },
                            }
                        ]
                    }
                ),
                self._chunk(delta={}, finish_reason="stop"),
                cc_done_frame(),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        complete = events[-1]
        self.assertEqual(complete.output[0]["annotations"][0]["type"], "url_citation")

    async def test_stateless_multi_turn_replay(self):
        """Round trip: output of turn 1 feeds turn 2's messages verbatim."""
        turn1 = b"".join(
            [
                self._chunk(delta={"content": "What is 2+2?"}),
                self._chunk(delta={}, finish_reason="stop"),
                cc_done_frame(),
            ]
        )
        transport = MockTransport([MockResponse([turn1])])
        events = await collect_events(self._client(transport).stream(self._req()))
        assistant_msg = events[-1].output[0]

        turn2 = b"".join(
            [
                self._chunk(delta={"content": "4"}),
                self._chunk(delta={}, finish_reason="stop"),
                cc_done_frame(),
            ]
        )
        transport2 = MockTransport([MockResponse([turn2])])
        events2 = await collect_events(
            self._client(transport2).stream(
                self._req(messages=[{"role": "user", "content": "q"}, assistant_msg])
            )
        )
        self.assertEqual(events2[-1].output[0]["content"], "4")


# ============================================================================
# 6. Claude state machine (Section 5.4.2 + P1 fixes)
# ============================================================================


class TestClaudeStateMachine(unittest.IsolatedAsyncioTestCase):
    def _client(
        self, transport: AsyncHttpTransport, version: str = "2023-06-01"
    ) -> ClaudeMessagesClient:
        return ClaudeMessagesClient(
            ClientConfig(api_key="k"), transport=transport, anthropic_version=version
        )

    def _req(self, **kwargs) -> ClaudeMessagesRequest:
        defaults = dict(model="claude-sonnet-4-6", max_tokens=100, messages=[{"role": "user", "content": "hi"}])
        defaults.update(kwargs)
        return ClaudeMessagesRequest(**defaults)

    async def test_full_flow_with_thinking_signature_and_tool_use(self):
        frames = b"".join(
            [
                sse_frame("message_start", {"type": "message_start", "message": {"id": "msg_1", "model": "claude-x", "usage": {"input_tokens": 10}}}),
                sse_frame("content_block_start", {"type": "content_block_start", "index": 0, "content_block": {"type": "thinking", "thinking": ""}}),
                sse_frame("content_block_delta", {"type": "content_block_delta", "index": 0, "delta": {"type": "thinking_delta", "thinking": "let me think"}}),
                sse_frame("content_block_delta", {"type": "content_block_delta", "index": 0, "delta": {"type": "signature_delta", "signature": "SIG123"}}),
                sse_frame("content_block_stop", {"type": "content_block_stop", "index": 0}),
                sse_frame("content_block_start", {"type": "content_block_start", "index": 1, "content_block": {"type": "tool_use", "id": "toolu_1", "name": "get_weather"}}),
                sse_frame("content_block_delta", {"type": "content_block_delta", "index": 1, "delta": {"type": "input_json_delta", "partial_json": '{"city"'}}),
                sse_frame("content_block_delta", {"type": "content_block_delta", "index": 1, "delta": {"type": "input_json_delta", "partial_json": ': "SF"}'}}),
                sse_frame("content_block_stop", {"type": "content_block_stop", "index": 1}),
                sse_frame("message_delta", {"type": "message_delta", "delta": {"stop_reason": "tool_use"}, "usage": {"output_tokens": 7}}),
                sse_frame("message_stop", {"type": "message_stop"}),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        self.assertEqual(
            types_of(events),
            [
                "request_start", "response_start",
                "thinking_start", "thinking_delta", "thinking_stop",
                "tool_call_start", "tool_call_delta", "tool_call_delta", "tool_call_stop",
                "response_complete",
            ],
        )
        thinking_stop = events[4]
        self.assertEqual(thinking_stop.signature, "SIG123")
        tool_stop = events[8]
        self.assertEqual(tool_stop.arguments_raw, '{"city": "SF"}')
        complete = events[-1]
        self.assertEqual(complete.stop_reason, "tool_use")
        self.assertEqual(complete.output[0]["signature"], "SIG123")
        self.assertEqual(complete.output[1]["input"], {"city": "SF"})

    async def test_invalid_tool_args_raises_protocol_error(self):
        frames = b"".join(
            [
                sse_frame("message_start", {"type": "message_start", "message": {"id": "m", "model": "c"}}),
                sse_frame("content_block_start", {"type": "content_block_start", "index": 0, "content_block": {"type": "tool_use", "id": "t", "name": "f"}}),
                sse_frame("content_block_delta", {"type": "content_block_delta", "index": 0, "delta": {"type": "input_json_delta", "partial_json": "{broken"}}),
                sse_frame("content_block_stop", {"type": "content_block_stop", "index": 0}),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        from pythonsdk.errors import LLMClientError

        with self.assertRaises(LLMClientError) as ctx:
            async for _ in self._client(transport).stream(self._req()):
                pass
        self.assertEqual(ctx.exception.kind, ErrorKind.PROTOCOL_ERROR)

    async def test_truncated_stream_without_message_stop_raises(self):
        frames = sse_frame("message_start", {"type": "message_start", "message": {"id": "m", "model": "c"}})
        transport = MockTransport([MockResponse([frames])])
        from pythonsdk.errors import LLMClientError

        with self.assertRaises(LLMClientError) as ctx:
            async for _ in self._client(transport).stream(self._req()):
                pass
        self.assertEqual(ctx.exception.kind, ErrorKind.PROTOCOL_ERROR)

    async def test_overloaded_error_event_retryable(self):
        frames = sse_frame("error", {"type": "error", "error": {"type": "overloaded_error", "message": "overloaded"}})
        transport = MockTransport([MockResponse([frames])])
        from pythonsdk.errors import LLMClientError

        with self.assertRaises(LLMClientError) as ctx:
            async for _ in self._client(transport).stream(
                self._req(), RequestOptions(retry_policy=RetryPolicy(max_attempts=1))
            ):
                pass
        self.assertEqual(ctx.exception.kind, ErrorKind.OVERLOADED)
        self.assertTrue(ctx.exception.is_retryable)

    def test_version_override_strips_sampling_params_consistently(self):
        # Client constructed on the old version, request-level header overrides
        # to 2026-10-21: the effective header AND the body transform must agree.
        transport = MockTransport([])
        client = self._client(transport, version="2023-06-01")
        req = self._req(temperature=0.7, top_p=0.9)
        options = RequestOptions(custom_headers={"anthropic-version": "2026-10-21"})
        url, headers = client._build_url_and_headers(req, options)
        self.assertEqual(headers["anthropic-version"], "2026-10-21")
        _, root = client.build_final_request_body(req, None, options=options)
        self.assertNotIn("temperature", root)
        self.assertNotIn("top_p", root)

        # Without the override the sampling params survive.
        url2, headers2 = client._build_url_and_headers(req, RequestOptions())
        self.assertEqual(headers2["anthropic-version"], "2023-06-01")
        _, root2 = client.build_final_request_body(req, None, options=RequestOptions())
        self.assertEqual(root2["temperature"], 0.7)


# ============================================================================
# 7. Gemini state machine (Section 5.4.3 + P1 signature-merge fix)
# ============================================================================


def gemini_frame(payload: dict) -> bytes:
    return sse_frame(None, payload)


class TestGeminiStateMachine(unittest.IsolatedAsyncioTestCase):
    def _client(self, transport: AsyncHttpTransport) -> GeminiStreamClient:
        return GeminiStreamClient(ClientConfig(api_key="k"), transport=transport)

    def _req(self) -> GeminiStreamRequest:
        return GeminiStreamRequest(model="gemini-2.5-flash", contents=[{"role": "user", "parts": [{"text": "hi"}]}])

    async def test_boundary_signature_merges_into_thought_part(self):
        frames = b"".join(
            [
                gemini_frame({"candidates": [{"content": {"parts": [{"thought": True, "text": "think "}]}}]}),
                gemini_frame({"candidates": [{"content": {"parts": [{"thought": True, "text": "more"}, {"text": "", "thoughtSignature": "SIG"}]}}]}),
                gemini_frame({"candidates": [{"content": {"parts": [{"text": "Hello"}]}, "finishReason": "STOP"}]}),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        self.assertEqual(
            types_of(events),
            [
                "request_start", "response_start",
                "thinking_start", "thinking_delta", "thinking_delta", "thinking_stop",
                "text_start", "text_delta", "text_stop", "response_complete",
            ],
        )
        thinking_stop = [e for e in events if e.type == "thinking_stop"][0]
        self.assertEqual(thinking_stop.signature, "SIG")
        complete = events[-1]
        parts = complete.output["parts"]
        self.assertEqual(len(parts), 2)  # no phantom empty-text part
        self.assertEqual(parts[0], {"thought": True, "text": "think more", "thoughtSignature": "SIG"})
        self.assertEqual(parts[1], {"text": "Hello"})

    async def test_function_call_triple_and_null_args(self):
        frames = b"".join(
            [
                gemini_frame({"candidates": [{"content": {"parts": [{"text": "ok"}]}}]}),
                gemini_frame(
                    {
                        "candidates": [
                            {
                                "content": {
                                    "parts": [
                                        {"functionCall": {"name": "f", "args": {"a": 1}}},
                                        {"functionCall": {"name": "g", "args": None}},
                                    ]
                                }
                            }
                        ]
                    }
                ),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        tool_stops = [e for e in events if e.type == "tool_call_stop"]
        self.assertEqual(len(tool_stops), 2)
        self.assertEqual(tool_stops[0].arguments_raw, '{"a": 1}')
        self.assertEqual(tool_stops[1].arguments_raw, "{}")  # null args -> {}
        complete = events[-1]
        fn_parts = [p for p in complete.output["parts"] if "functionCall" in p]
        self.assertEqual(len(fn_parts), 2)

    async def test_tts_audio_lifecycle_events(self):
        def audio_part(data: str) -> dict:
            return {"inlineData": {"mimeType": "audio/l16; rate=24000", "data": data}}

        frames = b"".join(
            [
                gemini_frame(
                    {"candidates": [{"content": {"parts": [audio_part("AAAA"), audio_part("BBBB")]}}]}
                ),
                gemini_frame(
                    {"candidates": [{"content": {"parts": [audio_part("CCCC"), {"text": ""}]}}]}
                ),
                gemini_frame({"candidates": [{"finishReason": "STOP"}]}),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        self.assertEqual(
            types_of(events),
            [
                "request_start", "response_start",
                "audio_start", "audio_delta", "audio_delta", "audio_delta",
                "audio_stop", "response_complete",
            ],
        )
        start = events[2]
        self.assertEqual(start.mime_type, "audio/l16; rate=24000")
        deltas = [e for e in events if e.type == "audio_delta"]
        self.assertEqual("".join(d.audio_delta for d in deltas), "AAAABBBBCCCC")
        stop = [e for e in events if e.type == "audio_stop"][0]
        self.assertEqual(stop.total_base64_length, 12)
        complete = events[-1]
        # Raw audio parts (and the empty terminator) stay verbatim for replay.
        self.assertEqual(
            len([p for p in complete.output["parts"] if "inlineData" in p]), 3
        )
        self.assertEqual(complete.output["parts"][-1], {"text": ""})

    async def test_tts_audio_stage_closed_at_eof(self):
        frames = gemini_frame(
            {
                "candidates": [
                    {
                        "content": {
                            "parts": [
                                {"inlineData": {"mimeType": "audio/l16", "data": "XX"}}
                            ]
                        }
                    }
                ]
            }
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        self.assertEqual(
            types_of(events),
            [
                "request_start", "response_start",
                "audio_start", "audio_delta", "audio_stop", "response_complete",
            ],
        )

    async def test_stop_reason_none_when_server_never_reports_it(self):
        # EOF without any finishReason: the SDK must not fabricate "STOP".
        frames = gemini_frame({"candidates": [{"content": {"parts": [{"text": "hi"}]}}]})
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        complete = events[-1]
        self.assertIsNone(complete.stop_reason)

    async def test_stop_reason_reported_verbatim_when_present(self):
        frames = gemini_frame(
            {"candidates": [{"content": {"parts": [{"text": "hi"}]}, "finishReason": "MAX_TOKENS"}]}
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        complete = events[-1]
        self.assertEqual(complete.stop_reason, "MAX_TOKENS")

    async def test_usage_extraction(self):
        frames = gemini_frame(
            {
                "candidates": [{"content": {"parts": [{"text": "hi"}]}, "finishReason": "STOP"}],
                "usageMetadata": {
                    "promptTokenCount": 10,
                    "candidatesTokenCount": 5,
                    "thoughtsTokenCount": 3,
                    "totalTokenCount": 18,
                },
            }
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        complete = events[-1]
        self.assertEqual(complete.usage.input_tokens, 10)
        self.assertEqual(complete.usage.output_tokens, 5)
        self.assertEqual(complete.usage.reasoning_tokens, 3)
        self.assertEqual(complete.usage.total_tokens, 18)

    async def test_audio_transcription_part_and_trailing_empty_text(self):
        # Real-world shape observed from gemini-*-transcribe models: the text
        # arrives in `audioTranscription` parts, followed by a trailing empty
        # text terminator part.
        frames = b"".join(
            [
                gemini_frame(
                    {"candidates": [{"content": {"parts": [{"audioTranscription": {"text": "你好，"}}]}}]}
                ),
                gemini_frame(
                    {"candidates": [{"content": {"parts": [{"audioTranscription": {"text": "世界。"}}]}}]}
                ),
                gemini_frame({"candidates": [{"content": {"parts": [{"text": ""}]}}]}),
                gemini_frame({"candidates": [{"finishReason": "STOP"}]}),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        events = await collect_events(self._client(transport).stream(self._req()))
        self.assertEqual(
            types_of(events),
            [
                "request_start", "response_start",
                "text_start", "text_delta", "text_delta", "text_stop",
                "response_complete",
            ],
        )
        text_stop = [e for e in events if e.type == "text_stop"][0]
        self.assertEqual(text_stop.text, "你好，世界。")
        complete = events[-1]
        # Raw parts are preserved verbatim for faithful replay — including
        # the audioTranscription carrier and the trailing empty terminator.
        self.assertEqual(
            complete.output["parts"],
            [
                {"audioTranscription": {"text": "你好，"}},
                {"audioTranscription": {"text": "世界。"}},
                {"text": ""},
            ],
        )


# ============================================================================
# 8. Base client lifecycle: retry, mid-stream, GeneratorExit, cancel (Section 5.5)
# ============================================================================


class TestBaseClientLifecycle(unittest.IsolatedAsyncioTestCase):
    def _openai(self, transport) -> OpenAIResponsesClient:
        return OpenAIResponsesClient(ClientConfig(api_key="k"), transport=transport)

    def _req(self) -> OpenAIResponsesRequest:
        return OpenAIResponsesRequest(model="gpt-5", input="hi")

    def _completed_frames(self) -> bytes:
        return b"".join(
            [
                sse_frame("response.created", {"type": "response.created", "response": {"id": "r", "model": "m"}}),
                sse_frame(
                    "response.completed",
                    {"type": "response.completed", "response": {"id": "r", "status": "completed", "usage": {}, "output": []}},
                ),
            ]
        )

    async def test_retry_flow_emits_lifecycle_events(self):
        transport = MockTransport(
            [
                MockResponse([b'{"error":{"message":"up"}}'], status=500),
                MockResponse([self._completed_frames()]),
            ]
        )
        inspector = RecordingInspector()
        client = self._openai(transport).use_inspector(inspector)
        events = await collect_events(
            client.stream(
                self._req(),
                RequestOptions(
                    retry_policy=RetryPolicy(max_attempts=2, base_delay_ms=1, max_delay_ms=5)
                ),
            )
        )
        starts = [e for e in events if e.type == "request_start"]
        retries = [e for e in events if e.type == "retrying"]
        self.assertEqual([s.attempt for s in starts], [1, 2])
        self.assertEqual(len(retries), 1)
        self.assertEqual(retries[0].max_attempts, 2)
        self.assertGreaterEqual(retries[0].delay_ms, 0)
        self.assertEqual(retries[0].error.status_code, 500)
        self.assertEqual(types_of(events)[-1], "response_complete")
        self.assertEqual(
            [c.outcome for c in inspector.completions], ["http_error", "completed"]
        )

    async def test_mid_stream_error_no_retry_by_default(self):
        frames_head = b"".join(
            [
                sse_frame("response.created", {"type": "response.created", "response": {"id": "r", "model": "m"}}),
                sse_frame(
                    "response.output_item.added",
                    {"type": "response.output_item.added", "output_index": 0, "item": {"type": "message", "id": "m1"}},
                ),
                sse_frame(
                    "response.output_text.delta",
                    {"type": "response.output_text.delta", "output_index": 0, "delta": "partial"},
                ),
            ]
        )
        transport = MockTransport(
            [
                MockResponse(
                    [frames_head],
                    stream_error=ConnectionResetError("mid-stream break"),
                ),
                MockResponse([self._completed_frames()]),
            ]
        )
        client = self._openai(transport)
        from pythonsdk.errors import LLMClientError

        raised = None
        seen = []
        try:
            async for ev in client.stream(
                self._req(),
                RequestOptions(retry_policy=RetryPolicy(max_attempts=3, base_delay_ms=1)),
            ):
                seen.append(ev)
        except LLMClientError as exc:
            raised = exc
        # Content was already emitted -> no automatic retry allowed by default.
        self.assertIsNotNone(raised)
        self.assertEqual(raised.kind, ErrorKind.NETWORK_ERROR)
        self.assertEqual(len(transport.requests), 1)
        self.assertNotIn("retrying", types_of(seen))

    async def test_mid_stream_error_retries_when_enabled(self):
        frames_head = b"".join(
            [
                sse_frame("response.created", {"type": "response.created", "response": {"id": "r", "model": "m"}}),
                sse_frame(
                    "response.output_text.delta",
                    {"type": "response.output_text.delta", "output_index": 0, "delta": "partial"},
                ),
            ]
        )
        transport = MockTransport(
            [
                MockResponse([frames_head], stream_error=ConnectionResetError("break")),
                MockResponse([self._completed_frames()]),
            ]
        )
        client = self._openai(transport)
        events = await collect_events(
            client.stream(
                self._req(),
                RequestOptions(
                    retry_policy=RetryPolicy(
                        max_attempts=2, base_delay_ms=1, retry_on_mid_stream_error=True
                    )
                ),
            ),
        )
        self.assertIn("retrying", types_of(events))
        self.assertEqual(len(transport.requests), 2)

    async def test_generator_exit_closes_cleanly(self):
        initial = sse_frame(
            "response.created",
            {"type": "response.created", "response": {"id": "r", "model": "m"}},
        )
        transport = MockTransport([EndlessMockResponse([initial])])
        inspector = RecordingInspector()
        client = self._openai(transport).use_inspector(inspector)
        agen = client.stream(self._req())
        first = await asyncio.wait_for(agen.__anext__(), 5)
        self.assertEqual(first.type, "request_start")
        second = await asyncio.wait_for(agen.__anext__(), 5)
        self.assertEqual(second.type, "response_start")
        # The generator is now suspended at a yield INSIDE the try block while
        # the underlying stream is still open; closing must neither raise
        # RuntimeError("ignored GeneratorExit") nor fabricate an LLMClientError.
        await asyncio.wait_for(agen.aclose(), 5)
        outcomes = [c.outcome for c in inspector.completions]
        self.assertIn("aborted", outcomes)

    async def test_cancel_during_backoff_wakes_immediately(self):
        transport = MockTransport(
            [MockResponse([b'{"error":{"message":"rate"}}'], status=429)]
        )
        token = CancellationToken()
        client = self._openai(transport)
        from pythonsdk.errors import LLMClientError

        started = time.monotonic()
        raised = None
        try:
            async for ev in client.stream(
                self._req(),
                RequestOptions(
                    cancel_token=token,
                    retry_policy=RetryPolicy(
                        max_attempts=2, base_delay_ms=60000, max_delay_ms=60000
                    ),
                ),
            ):
                if getattr(ev, "type", "") == "retrying":
                    token.cancel()
        except LLMClientError as exc:
            raised = exc
        elapsed = time.monotonic() - started
        self.assertIsNotNone(raised)
        self.assertEqual(raised.kind, ErrorKind.ABORTED)
        self.assertLess(elapsed, 5.0)  # did not wait out the 30-60s backoff

    async def test_in_stream_error_with_status_code_still_gets_outcome(self):
        # Gemini in-band error frames carry an HTTP status code; the exchange
        # must still be reported with outcome="stream_error".
        frames = b"".join(
            [
                gemini_frame({"candidates": [{"content": {"parts": [{"text": "hi"}]}}]}),
                gemini_frame({"error": {"code": 429, "status": "RESOURCE_EXHAUSTED", "message": "quota"}}),
            ]
        )
        transport = MockTransport([MockResponse([frames])])
        inspector = RecordingInspector()
        client = GeminiStreamClient(ClientConfig(api_key="k"), transport=transport).use_inspector(inspector)
        from pythonsdk.errors import LLMClientError

        with self.assertRaises(LLMClientError) as ctx:
            async for _ in client.stream(
                GeminiStreamRequest(
                    model="gemini-2.5-flash",
                    contents=[{"role": "user", "parts": [{"text": "hi"}]}],
                ),
                RequestOptions(retry_policy=RetryPolicy(max_attempts=1)),
            ):
                pass
        self.assertEqual(ctx.exception.kind, ErrorKind.RATE_LIMIT)
        self.assertEqual([c.outcome for c in inspector.completions], ["stream_error"])

    async def test_inspector_hook_exception_isolated(self):
        transport = MockTransport([MockResponse([self._completed_frames()])])
        inspector = RecordingInspector()
        inspector.raise_on_request = True
        client = self._openai(transport).use_inspector(inspector)
        events = await collect_events(client.stream(self._req()))
        self.assertEqual(types_of(events)[-1], "response_complete")

    async def test_eof_tail_reaches_on_raw_stream_chunk(self):
        # SSE data without a trailing blank line: the EOF flush must be
        # observable through onRawStreamChunk (100% raw fidelity).
        frames = b"".join(
            [
                sse_frame("response.created", {"type": "response.created", "response": {"id": "r", "model": "m"}}),
                sse_frame("data-with-no-final-blank", None),  # placeholder replaced below
            ]
        )
        # Build a real tail: complete frame + unterminated tail bytes
        body = (
            sse_frame("response.created", {"type": "response.created", "response": {"id": "r", "model": "m"}})
            + sse_frame(
                "response.completed",
                {"type": "response.completed", "response": {"id": "r", "status": "completed", "usage": {}, "output": []}},
            )[:-1]  # chop the final newline -> tail flushed at EOF
        )
        _ = frames
        transport = MockTransport([MockResponse([body])])
        inspector = RecordingInspector()
        client = self._openai(transport).use_inspector(inspector)
        events = await collect_events(client.stream(self._req()))
        self.assertEqual(types_of(events)[-1], "response_complete")
        rejoined = "".join(c.raw_chunk for c in inspector.raw_chunks)
        self.assertEqual(rejoined, body.decode("utf-8"))


# ============================================================================
# 9.1 DeepSeek Tools (non-streaming JSON APIs): template-method client
# ============================================================================


class TestDeepSeekToolsClient(unittest.IsolatedAsyncioTestCase):
    def _client(self, transport) -> DeepSeekToolsClient:
        return DeepSeekToolsClient(ClientConfig(api_key="sk-tools"), transport=transport)

    async def test_search_success_parses_results(self):
        payload = json.dumps(
            {
                "results": [
                    {
                        "title": "DeepSeek V4",
                        "url": "https://example.com/v4",
                        "snippet": "short",
                        "summary": "long",
                        "content": "",
                        "rerank_score": 2.0,
                        "authority": 3,
                    }
                ]
            }
        ).encode()
        transport = MockTransport([MockResponse([payload])])
        response = await self._client(transport).search("DeepSeek", count=5)
        self.assertEqual(len(response["results"]), 1)
        self.assertEqual(response["results"][0]["title"], "DeepSeek V4")
        sent = json.loads(transport.requests[0]["body"])
        self.assertEqual(sent["query"], "DeepSeek")
        self.assertEqual(sent["count"], 5)

    async def test_search_empty_results(self):
        transport = MockTransport([MockResponse([b'{"results": []}'])])
        response = await self._client(transport).search("no match query")
        self.assertEqual(response["results"], [])

    async def test_search_missing_results_array_is_protocol_error(self):
        transport = MockTransport([MockResponse([b'{"unexpected": 1}'])])
        with self.assertRaises(LLMClientError) as ctx:
            await self._client(transport).search("q")
        self.assertEqual(ctx.exception.kind, ErrorKind.PROTOCOL_ERROR)

    async def test_fetch_success(self):
        payload = json.dumps({"title": "Example article", "content": "# Example\n\ntext"}).encode()
        transport = MockTransport([MockResponse([payload])])
        page = await self._client(transport).fetch("https://example.com/article")
        self.assertEqual(page["title"], "Example article")
        self.assertEqual(page["content"], "# Example\n\ntext")
        sent = json.loads(transport.requests[0]["body"])
        self.assertEqual(sent, {"url": "https://example.com/article"})

    async def test_http_error_body_preserved_no_retry(self):
        error_body = json.dumps(
            {"error": {"message": "'count' must be between 1 and 50",
                       "type": "invalid_request_error", "param": None,
                       "code": "invalid_request_error"}}
        ).encode()
        transport = MockTransport([MockResponse([error_body], status=400)])
        with self.assertRaises(LLMClientError) as ctx:
            await self._client(transport).post_json("/v1/tools/search", {"query": "x", "count": 99})
        self.assertEqual(ctx.exception.kind, ErrorKind.BAD_REQUEST)
        self.assertFalse(ctx.exception.is_retryable)
        self.assertIn("count", ctx.exception.raw_body or "")
        self.assertEqual(len(transport.requests), 1)  # 4xx must not retry

    async def test_retry_on_429_then_success(self):
        transport = MockTransport(
            [
                MockResponse([b'{"error":{"message":"rate"}}'], status=429),
                MockResponse([b'{"results": []}']),
            ]
        )
        inspector = RecordingInspector()
        client = self._client(transport).use_inspector(inspector)
        response = await client.search(
            "q", options=RequestOptions(retry_policy=RetryPolicy(max_attempts=2, base_delay_ms=1))
        )
        self.assertEqual(response["results"], [])
        self.assertEqual(len(transport.requests), 2)
        self.assertEqual([c.outcome for c in inspector.completions], ["http_error", "completed"])

    async def test_local_validation_sends_nothing(self):
        transport = MockTransport([])
        client = self._client(transport)
        for coro in (
            client.search("   "),          # blank query
            client.search("q", count=99),  # count out of range
            client.fetch("ftp://x/y"),     # wrong scheme
            client.fetch("https://u:p@h/"),# credentials in URL
        ):
            with self.assertRaises(LLMClientError) as ctx:
                await coro
            self.assertEqual(ctx.exception.kind, ErrorKind.BAD_REQUEST)
            self.assertEqual(ctx.exception.attempt, 0)
        self.assertEqual(transport.requests, [])  # no network round-trip

    async def test_json_parse_failure_is_protocol_error(self):
        transport = MockTransport([MockResponse([b"not json"])])
        with self.assertRaises(LLMClientError) as ctx:
            await self._client(transport).search("q")
        self.assertEqual(ctx.exception.kind, ErrorKind.PROTOCOL_ERROR)

    async def test_cancelled_token_aborts_before_request(self):
        transport = MockTransport([])
        token = CancellationToken()
        token.cancel()
        with self.assertRaises(LLMClientError) as ctx:
            await self._client(transport).search("q", options=RequestOptions(cancel_token=token))
        self.assertEqual(ctx.exception.kind, ErrorKind.ABORTED)
        self.assertEqual(transport.requests, [])


# ============================================================================
# 9.2 Gemini Embedding (non-streaming JSON APIs): template-method client
# ============================================================================


class TestGeminiEmbeddingClient(unittest.IsolatedAsyncioTestCase):
    def _client(self, transport, model: str = "gemini-embedding-2") -> GeminiEmbeddingClient:
        return GeminiEmbeddingClient(
            ClientConfig(api_key="AIzaSy-test"), model=model, transport=transport
        )

    async def test_embed_content_success(self):
        payload = json.dumps(
            {
                "embedding": {"values": [0.1, 0.2, -0.3]},
                "usageMetadata": {
                    "promptTokenCount": 21,
                    "promptTokenDetails": [{"modality": "TEXT", "tokenCount": 21}],
                },
            }
        ).encode()
        transport = MockTransport([MockResponse([payload])])
        response = await self._client(transport).embed_content(
            "需要向量的文本",
            task_type="RETRIEVAL_DOCUMENT",
            title="文档标题",
            output_dimensionality=768,
        )
        self.assertEqual(response["embedding"]["values"], [0.1, 0.2, -0.3])
        self.assertEqual(response["usageMetadata"]["promptTokenCount"], 21)
        sent = json.loads(transport.requests[0]["body"])
        self.assertEqual(sent["content"], {"parts": [{"text": "需要向量的文本"}]})
        self.assertEqual(sent["taskType"], "RETRIEVAL_DOCUMENT")
        self.assertEqual(sent["title"], "文档标题")
        self.assertEqual(sent["outputDimensionality"], 768)

    async def test_embed_content_accepts_content_object(self):
        payload = json.dumps({"embedding": {"values": [0.5]}}).encode()
        transport = MockTransport([MockResponse([payload])])
        await self._client(transport).embed_content(
            {"parts": [{"text": "a"}, {"inlineData": {"mimeType": "image/png", "data": "x"}}]}
        )
        sent = json.loads(transport.requests[0]["body"])
        self.assertEqual(len(sent["content"]["parts"]), 2)
        self.assertNotIn("taskType", sent)  # optional fields omitted

    async def test_batch_preserves_order_and_injects_model(self):
        payload = json.dumps(
            {"embeddings": [{"values": [1.0]}, {"values": [2.0]}],
             "usageMetadata": {"promptTokenCount": 8}}
        ).encode()
        transport = MockTransport([MockResponse([payload])])
        response = await self._client(transport).batch_embed_contents(
            ["第一条", {"content": {"parts": [{"text": "第二条"}]}, "taskType": "RETRIEVAL_QUERY"}]
        )
        self.assertEqual(
            [e["values"] for e in response["embeddings"]], [[1.0], [2.0]]
        )
        sent = json.loads(transport.requests[0]["body"])
        self.assertEqual(len(sent["requests"]), 2)
        for sub in sent["requests"]:
            self.assertEqual(sub["model"], "models/gemini-embedding-2")
        self.assertEqual(sent["requests"][0]["content"]["parts"], [{"text": "第一条"}])
        self.assertEqual(sent["requests"][1]["taskType"], "RETRIEVAL_QUERY")
        self.assertTrue(transport.requests[0]["url"].endswith(
            "/v1beta/models/gemini-embedding-2:batchEmbedContents"))

    async def test_batch_length_mismatch_is_protocol_error(self):
        payload = json.dumps({"embeddings": [{"values": [1.0]}]}).encode()
        transport = MockTransport([MockResponse([payload])])
        with self.assertRaises(LLMClientError) as ctx:
            await self._client(transport).batch_embed_contents(["a", "b"])
        self.assertEqual(ctx.exception.kind, ErrorKind.PROTOCOL_ERROR)

    async def test_missing_embedding_is_protocol_error(self):
        transport = MockTransport([MockResponse([b'{"usageMetadata": {}}'])])
        with self.assertRaises(LLMClientError) as ctx:
            await self._client(transport).embed_content("text")
        self.assertEqual(ctx.exception.kind, ErrorKind.PROTOCOL_ERROR)

    async def test_local_validations_send_nothing(self):
        transport = MockTransport([])
        client = self._client(transport)
        cases = [
            lambda: client.embed_content("text", title="t"),                        # title w/o RETRIEVAL_DOCUMENT
            lambda: client.embed_content("text", task_type="RETRIEVAL_QUERY", title="t"),
            lambda: client.embed_content("text", task_type="NOT_A_TYPE"),           # bad enum
            lambda: client.embed_content("text", output_dimensionality=0),          # dim low
            lambda: client.embed_content("text", output_dimensionality=3073),       # dim high
            lambda: client.embed_content(""),                                     # empty string text
            lambda: client.embed_content({"parts": []}),                            # empty parts
            lambda: client.embed_content({"parts": [{"text": ""}]}),                # empty text part
            lambda: client.batch_embed_contents([]),                                # empty batch
            lambda: client.batch_embed_contents(["x"] * 101),                       # >100
        ]
        for case in cases:
            with self.assertRaises(LLMClientError) as ctx:
                await case()
            self.assertEqual(ctx.exception.kind, ErrorKind.BAD_REQUEST, str(ctx.exception))
            self.assertEqual(ctx.exception.attempt, 0)
        self.assertEqual(transport.requests, [])

    async def test_http_400_google_error_preserved(self):
        payload = json.dumps(
            {"error": {"code": 400, "message": "title is only supported for RETRIEVAL_DOCUMENT",
                       "status": "INVALID_ARGUMENT"}}
        ).encode()
        transport = MockTransport([MockResponse([payload], status=400)])
        with self.assertRaises(LLMClientError) as ctx:
            await self._client(transport).embed_content("text")
        self.assertEqual(ctx.exception.kind, ErrorKind.BAD_REQUEST)
        self.assertIn("RETRIEVAL_DOCUMENT", ctx.exception.raw_body or "")
        self.assertEqual(len(transport.requests), 1)

    async def test_retry_on_503_then_success(self):
        unavailable = json.dumps(
            {"error": {"code": 503, "message": "The model is overloaded",
                       "status": "UNAVAILABLE"}}
        ).encode()
        transport = MockTransport(
            [
                MockResponse([unavailable], status=503),
                MockResponse([json.dumps({"embedding": {"values": [0.1]}}).encode()]),
            ]
        )
        inspector = RecordingInspector()
        client = self._client(transport).use_inspector(inspector)
        response = await client.embed_content(
            "text", options=RequestOptions(retry_policy=RetryPolicy(max_attempts=2, base_delay_ms=1))
        )
        self.assertEqual(response["embedding"]["values"], [0.1])
        self.assertEqual([c.outcome for c in inspector.completions], ["http_error", "completed"])

    def test_vector_utils(self):
        self.assertEqual(l2_normalize([3.0, 4.0]), [0.6, 0.8])
        self.assertEqual(l2_normalize([0.0, 0.0]), [0.0, 0.0])  # zero vector guarded
        self.assertAlmostEqual(cosine_similarity([1.0, 0.0], [1.0, 0.0]), 1.0)
        self.assertAlmostEqual(cosine_similarity([1.0, 0.0], [0.0, 1.0]), 0.0)
        with self.assertRaises(ValueError):
            cosine_similarity([1.0], [1.0, 2.0])


# ============================================================================
# 10. Real-socket transport tests (P0 fix: mid-stream EOF detection)
# ============================================================================


class TestRealSocketTransport(unittest.IsolatedAsyncioTestCase):
    async def _with_server(self, raw_responses: list[bytes]):
        server = await _ScriptedHttpServer(raw_responses).start()
        self.addAsyncCleanup(server.stop)
        return server

    def _client(self, base_url: str) -> OpenAIResponsesClient:
        return OpenAIResponsesClient(
            ClientConfig(api_key="sk-live-test", base_url=base_url)
        )

    def _req(self) -> OpenAIResponsesRequest:
        return OpenAIResponsesRequest(model="gpt-5", input="hi")

    async def test_chunked_truncation_raises_stream_error(self):
        # Graceful FIN after a data chunk but WITHOUT the 0-length terminator.
        raw = _sse_headers() + b"5\r\ndata:\r\n"
        server = await self._with_server([raw])
        from pythonsdk.errors import LLMClientError

        with self.assertRaises(LLMClientError) as ctx:
            async for _ in self._client(server.base_url).stream(
                self._req(),
                RequestOptions(retry_policy=RetryPolicy(max_attempts=1)),
            ):
                pass
        self.assertEqual(ctx.exception.kind, ErrorKind.NETWORK_ERROR)
        self.assertTrue(ctx.exception.is_retryable)

    async def test_content_length_truncation_raises_stream_error(self):
        raw = (
            b"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\n"
            b"Content-Length: 100\r\n\r\ndata: short"
        )
        server = await self._with_server([raw])
        from pythonsdk.errors import LLMClientError

        with self.assertRaises(LLMClientError) as ctx:
            async for _ in self._client(server.base_url).stream(
                self._req(),
                RequestOptions(retry_policy=RetryPolicy(max_attempts=1)),
            ):
                pass
        self.assertEqual(ctx.exception.kind, ErrorKind.NETWORK_ERROR)

    async def test_openai_end_to_end_over_real_socket(self):
        sse = b"".join(
            [
                sse_frame("response.created", {"type": "response.created", "response": {"id": "resp_9", "model": "gpt-5"}}),
                sse_frame(
                    "response.completed",
                    {
                        "type": "response.completed",
                        "response": {
                            "id": "resp_9",
                            "status": "completed",
                            "usage": {"input_tokens": 4, "output_tokens": 6, "total_tokens": 10},
                            "output": [{"type": "message", "id": "m1"}],
                        },
                    },
                ),
            ]
        )
        server = await self._with_server([_sse_headers() + _chunked(sse)])
        events = await collect_events(self._client(server.base_url).stream(self._req()))
        self.assertEqual(
            types_of(events), ["request_start", "response_start", "response_complete"]
        )
        # P0-3 regression: include must be auto-injected (store defaults to False).
        sent = json.loads(server.received[0]["body"])
        self.assertEqual(sent["include"], ["reasoning.encrypted_content"])
        head = server.received[0]["head"].decode("utf-8", errors="replace")
        self.assertIn("Authorization: Bearer sk-live-test", head)

    async def test_non_2xx_error_body_preserved(self):
        body = b'{"error":{"type":"invalid_request_error"}}'
        raw = (
            b"HTTP/1.1 400 Bad Request\r\nContent-Type: application/json\r\n"
            + f"Content-Length: {len(body)}\r\n\r\n".encode()
            + body
        )
        server = await self._with_server([raw])
        from pythonsdk.errors import LLMClientError

        with self.assertRaises(LLMClientError) as ctx:
            async for _ in self._client(server.base_url).stream(
                self._req(),
                RequestOptions(retry_policy=RetryPolicy(max_attempts=1)),
            ):
                pass
        self.assertEqual(ctx.exception.kind, ErrorKind.BAD_REQUEST)
        self.assertFalse(ctx.exception.is_retryable)
        self.assertIn("invalid_request_error", ctx.exception.raw_body or "")


if __name__ == "__main__":
    unittest.main()
