"""
Reusable live-endpoint integration tests for Zhipu's /responses dialect.

Target under test by default: https://open.bigmodel.cn/api/v1 (Response API,
model glm-5.3-flash). Zhipu implements a mostly-complete Responses dialect;
confirmed behavior encoded here (2026-10 live probes):

  SUPPORTED    standard OpenAI-shaped SSE events with NO trailing
               `data: [DONE]` (stream ends at response.completed);
               reasoning output with `encrypted_content` (include honored);
               reasoning.effort low/high/max; stateless multi-turn replay AND
               stateful store=true + previous_response_id (7-day validity);
               function calling full loop; server-executed web_search;
               image input (URL and base64 data URL); PDF file input whose
               content genuinely reaches the model; text.format json_object
               AND json_schema (the latter works even though the doc only
               lists text/json_object); include parameter accepted.
  QUIRKS       tool_choice is effectively auto-only: "none" is silently NOT
               enforced (the model still emits function_call) and
               "required"/forced-function are silently accepted behaving as
               auto (doc claims only none/auto); out-of-range temperature
               (1.5) is silently accepted (doc claims [0.0, 1.0]);
               glm-5.3-flash ALWAYS reasons — reasoning.effort none/minimal
               is rejected with 400 "该模型始终思考"; no cached_tokens hit on
               repeated identical prefixes; no cancel endpoint.
  NOT TESTED   video input: the Response API defines no input_video type and
               no local video resource was available.

Configuration (all optional):
    ZHIPU_LIVE_BASE_URL     default https://open.bigmodel.cn/api/v1
    ZHIPU_LIVE_API_KEY      required to run (no default; suite skips)
    ZHIPU_LIVE_MODEL        default glm-5.3-flash

Run (from the repository root that contains `pythonsdk/`):

    ZHIPU_LIVE_API_KEY=xxx python -m unittest pythonsdk.tests.test_zhipu_responses_live -v
"""

from __future__ import annotations

import base64
import json
import os
import socket
import sys
import unittest
import urllib.parse
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from pythonsdk import (
    ClientConfig,
    OpenAIResponsesClient,
    OpenAIResponsesRequest,
    RequestOptions,
    RetryPolicy,
)
from pythonsdk.errors import LLMClientError

LIVE_BASE_URL = os.environ.get("ZHIPU_LIVE_BASE_URL", "https://open.bigmodel.cn/api/v1")
LIVE_API_KEY = os.environ.get("ZHIPU_LIVE_API_KEY", "")
LIVE_MODEL = os.environ.get("ZHIPU_LIVE_MODEL", "glm-5.3-flash")
RESOURCE_DIR = Path(
    os.environ.get(
        "ZHIPU_LIVE_RESOURCE_DIR",
        str(Path(__file__).resolve().parents[2] / "testresouce"),
    )
)


def _endpoint_available() -> bool:
    if not LIVE_API_KEY:
        return False
    try:
        parsed = urllib.parse.urlsplit(LIVE_BASE_URL)
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        with socket.create_connection((parsed.hostname, port), timeout=3):
            return True
    except OSError:
        return False


def make_client() -> OpenAIResponsesClient:
    return OpenAIResponsesClient(ClientConfig(api_key=LIVE_API_KEY, base_url=LIVE_BASE_URL))


def one_shot() -> RequestOptions:
    # 4xx fails immediately regardless; retries only cover transient network
    # failures on this long-RTT route.
    return RequestOptions(retry_policy=RetryPolicy(max_attempts=3))


async def collect(request: OpenAIResponsesRequest) -> list[Any]:
    events: list[Any] = []
    async for ev in make_client().stream(request, one_shot()):
        events.append(ev)
    return events


def complete_of(events: list[Any]) -> Any:
    matches = [e for e in events if e.type == "response_complete"]
    assert matches, f"no response_complete event; types={[e.type for e in events]}"
    return matches[0]


def message_text(complete: Any) -> str:
    return "".join(
        part.get("text", "")
        for item in complete.output
        if item.get("type") == "message"
        for part in item.get("content", [])
    )


def b64_resource(name: str) -> str | None:
    path = RESOURCE_DIR / name
    if not path.is_file():
        return None
    return base64.b64encode(path.read_bytes()).decode("ascii")


@unittest.skipUnless(_endpoint_available(), "live endpoint unreachable or ZHIPU_LIVE_API_KEY not set")
class ZhipuResponsesLiveTests(unittest.IsolatedAsyncioTestCase):
    async def test_01_basic_streaming_with_encrypted_reasoning(self):
        events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, input="用一句话回答：长城是什么？", max_output_tokens=2000
            )
        )
        types = [e.type for e in events]
        self.assertIn("response_start", types)
        self.assertIn("thinking_delta", types)  # flash always reasons
        self.assertIn("text_delta", types)
        self.assertEqual(types[-1], "response_complete")
        complete = complete_of(events)
        self.assertGreater(complete.usage.total_tokens, 0)
        item_types = [i.get("type") for i in complete.output]
        self.assertIn("reasoning", item_types)
        self.assertIn("message", item_types)
        reasoning = next(i for i in complete.output if i.get("type") == "reasoning")
        self.assertIn("encrypted_content", reasoning)  # include honored

    async def test_02_stateless_multi_turn_replay(self):
        first = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, input="记住暗号：蓝色的山雀。只回复'好的'。", max_output_tokens=2000
            )
        )
        history = (
            [{"role": "user", "content": "记住暗号：蓝色的山雀。只回复'好的'。"}]
            + list(complete_of(first).output)
            + [{"role": "user", "content": "暗号是什么？只回答暗号本身。"}]
        )
        second = await collect(
            OpenAIResponsesRequest(model=LIVE_MODEL, input=history, max_output_tokens=2000)
        )
        text = message_text(complete_of(second))
        self.assertIn("蓝", text)
        self.assertIn("山雀", text)

    async def test_03_stateful_multi_turn_store_and_previous_response_id(self):
        first = complete_of(
            await collect(
                OpenAIResponsesRequest(
                    model=LIVE_MODEL, input="记住暗号：紫色的骆驼。只回复'好的'。",
                    max_output_tokens=2000, store=True,
                )
            )
        )
        self.assertTrue(first.response_id)
        second = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, input="暗号是什么？只回答暗号本身。",
                max_output_tokens=2000, store=True, previous_response_id=first.response_id,
            )
        )
        text = message_text(complete_of(second))
        self.assertIn("紫", text)
        self.assertIn("骆驼", text)

    async def test_04_function_calling_full_loop(self):
        tools = [
            {
                "type": "function", "name": "get_weather", "description": "查询指定城市的实时天气",
                "parameters": {
                    "type": "object",
                    "properties": {"city": {"type": "string"}},
                    "required": ["city"],
                },
            }
        ]
        first = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, input="北京今天天气怎么样？请调用工具查询。",
                tools=tools, max_output_tokens=2000,
            )
        )
        stops = [e for e in first if e.type == "tool_call_stop"]
        self.assertTrue(stops, "expected tool_call_stop")
        self.assertEqual(json.loads(stops[0].arguments_raw).get("city"), "北京")
        call = next(i for i in complete_of(first).output if i.get("type") == "function_call")
        second = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL,
                input=[
                    {"role": "user", "content": "北京今天天气怎么样？请调用工具查询。"},
                    call,
                    {
                        "type": "function_call_output", "call_id": call["call_id"],
                        "output": json.dumps({"temp_c": 21, "cond": "晴"}, ensure_ascii=False),
                    },
                ],
                tools=tools, max_output_tokens=2500,
            )
        )
        text = message_text(complete_of(second))
        self.assertTrue("晴" in text or "21" in text, f"reply should cite tool result: {text!r}")

    async def test_05_web_search_server_tool_executes(self):
        events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL,
                input="智谱 GLM 最新发布了什么模型？请联网搜索后回答。",
                tools=[{"type": "web_search"}], max_output_tokens=4000,
            )
        )
        self.assertTrue(
            [e for e in events if e.type in ("server_tool_start", "server_tool_stop")],
            "web_search should surface server_tool lifecycle events",
        )
        complete = complete_of(events)
        self.assertTrue(
            [i for i in complete.output if i.get("type") == "web_search_call"],
            "web_search_call items should appear in output",
        )
        self.assertGreater(len(message_text(complete).strip()), 10)

    async def test_06_image_understanding_base64(self):
        data = b64_resource("林间小憩_小鸟油画.png")
        if data is None:
            self.skipTest("image resource not found")
        events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, max_output_tokens=3000,
                input=[{"type": "message", "role": "user", "content": [
                    {"type": "input_text", "text": "这张图里有什么？两句话。"},
                    {"type": "input_image", "image_url": f"data:image/png;base64,{data}"},
                ]}],
            )
        )
        self.assertGreater(len(message_text(complete_of(events)).strip()), 10)

    async def test_07_pdf_file_content_reaches_model(self):
        pdf_name = next(
            (n for n in os.listdir(RESOURCE_DIR) if n.lower().endswith(".pdf"))
            if RESOURCE_DIR.is_dir() else None, None,
        )
        if pdf_name is None:
            self.skipTest("no .pdf resource available")
        data = b64_resource(pdf_name)
        assert data is not None
        events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, max_output_tokens=3000,
                input=[{"type": "message", "role": "user", "content": [
                    {"type": "input_text", "text": "这份文档的主题是什么？一句话。"},
                    {"type": "input_file", "file_data": f"data:application/pdf;base64,{data}"},
                ]}],
            )
        )
        text = message_text(complete_of(events))
        # The PDF genuinely reaches the model (unlike dialects that substitute
        # a placeholder): the answer cites domain-specific vocabulary.
        self.assertTrue(
            any(k in text for k in ("栽培", "农业", "施药", "试验", "田间")),
            f"answer should reference actual PDF content: {text!r}",
        )

    async def test_08_text_formats_json_object_and_schema(self):
        object_events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, max_output_tokens=1500, input="张三，28岁，输出JSON",
                text={"format": {"type": "json_object"}},
            )
        )
        parsed = json.loads(message_text(complete_of(object_events)))
        self.assertEqual(parsed.get("name"), "张三")

        # Doc lists only text/json_object, but json_schema+strict works too.
        schema_events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, max_output_tokens=1500, input="张三，28岁",
                text={"format": {
                    "type": "json_schema", "name": "person", "strict": True,
                    "schema": {
                        "type": "object",
                        "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
                        "required": ["name", "age"], "additionalProperties": False,
                    },
                }},
            )
        )
        parsed = json.loads(message_text(complete_of(schema_events)))
        self.assertEqual(parsed.get("name"), "张三")
        self.assertEqual(parsed.get("age"), 28)

    async def test_09_tool_choice_none_not_enforced(self):
        # Confirmed quirk: tool_choice="none" is accepted but NOT enforced —
        # the model still emits a function_call for a tool-seeking prompt.
        tools = [
            {
                "type": "function", "name": "get_weather", "description": "查询天气",
                "parameters": {"type": "object", "properties": {"city": {"type": "string"}}, "required": ["city"]},
            }
        ]
        events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, input="北京今天天气怎么样？请调用工具查询。",
                tools=tools, tool_choice="none", max_output_tokens=2000,
            )
        )
        self.assertTrue(
            [e for e in events if e.type == "tool_call_start"],
            "pinning confirmed behavior: 'none' does not suppress tool calls",
        )

    async def test_10_reasoning_effort_edges(self):
        # flash always reasons: none/minimal rejected — notably as an
        # IN-BAND SSE error event (HTTP 200 stream, no status_code) with
        # provider code "invalid_request", not as an HTTP 400 response.
        with self.assertRaises(LLMClientError) as ctx:
            await collect(
                OpenAIResponsesRequest(
                    model=LIVE_MODEL, input="1+1=?", max_output_tokens=500,
                    reasoning={"effort": "minimal"},
                )
            )
        self.assertFalse(ctx.exception.is_retryable)
        self.assertIsNone(ctx.exception.status_code)  # in-band, not HTTP-level
        self.assertIn("思考", str(ctx.exception))
        # low works.
        events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, input="1+1=? 只回答数字", max_output_tokens=1000,
                reasoning={"effort": "low"},
            )
        )
        self.assertIn("2", message_text(complete_of(events)))


if __name__ == "__main__":
    unittest.main()
