"""
Reusable live-endpoint integration tests for the Gemini Embedding client
(:embedContent / :batchEmbedContents, see GEMINI_EMBED_CONTENT_API.md).

Configuration (all optional):
    GEMINI_EMBED_LIVE_BASE_URL   default http://127.0.0.1:18317 (local gateway)
    GEMINI_EMBED_LIVE_API_KEY    default local-no-auth (gateway is key-less)
    GEMINI_EMBED_LIVE_MODEL      default gemini-embedding-2

Endpoint reality (re-probed 2026-10-25 after the gateway fix):
  - Both :embedContent (single) and :batchEmbedContents work; the single
    method returns 3072-dim values + usageMetadata (verified: HTTP 200).
  - gemini-embedding-2 / -2-preview return usageMetadata;
    gemini-embedding-001 serves 3072 dims (usage presence not asserted,
    matching the doc's model table).
  - An earlier probe (pre-fix) observed 404 on :embedContent and a missing
    usageMetadata on -001; test_05 keeps its graceful 404-skip branch purely
    for reusability against other gateways that serve batch only.

Run (from the repository root that contains `pythonsdk/`):

    python -m unittest pythonsdk.tests.test_gemini_embedding_live -v
"""

from __future__ import annotations

import asyncio
import math
import os
import socket
import sys
import unittest
import urllib.parse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from pythonsdk import (
    ClientConfig,
    GeminiEmbeddingClient,
    RequestOptions,
    RetryPolicy,
    cosine_similarity,
    l2_normalize,
)
from pythonsdk.errors import ErrorKind, LLMClientError

BASE_URL = os.environ.get("GEMINI_EMBED_LIVE_BASE_URL", "http://127.0.0.1:18317")
API_KEY = os.environ.get("GEMINI_EMBED_LIVE_API_KEY", "local-no-auth")
MODEL = os.environ.get("GEMINI_EMBED_LIVE_MODEL", "gemini-embedding-2")


def make_client() -> GeminiEmbeddingClient:
    return GeminiEmbeddingClient(
        ClientConfig(api_key=API_KEY, base_url=BASE_URL), model=MODEL
    )


def one_shot() -> RequestOptions:
    # Default retry policy: transient network-path failures (e.g. intermittent
    # TLS record corruption observed on this route, ~1 in 5 large responses)
    # are classified retryable NETWORK_ERROR and rescued by the backoff retry;
    # 4xx still fails immediately since those are non-retryable.
    return RequestOptions(retry_policy=RetryPolicy(max_attempts=3))


async def embed_one(
    text: str,
    *,
    task_type: str | None = None,
    title: str | None = None,
    dim: int | None = None,
) -> list[float]:
    """Embeds a single text via batch-of-1 (the method the local gateway serves)."""
    sub: dict = {"content": {"parts": [{"text": text}]}}
    if task_type:
        sub["taskType"] = task_type
    if title:
        sub["title"] = title
    if dim:
        sub["outputDimensionality"] = dim
    response = await make_client().batch_embed_contents([sub], options=one_shot())
    return response["embeddings"][0]["values"]


def _tcp_reachable() -> bool:
    try:
        parsed = urllib.parse.urlsplit(BASE_URL)
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        with socket.create_connection((parsed.hostname, port), timeout=3):
            return True
    except OSError:
        return False


def _endpoint_works() -> bool:
    if not _tcp_reachable():
        return False
    try:
        asyncio.run(
            make_client().batch_embed_contents(["probe"], options=one_shot())
        )
        return True
    except LLMClientError:
        return False


@unittest.skipUnless(_endpoint_works(), "embedding endpoint unavailable (no worker / no auth)")
class GeminiEmbeddingLiveTests(unittest.IsolatedAsyncioTestCase):
    async def test_01_default_dimensions_and_usage(self):
        response = await make_client().batch_embed_contents(
            ["如何排查 403 权限错误？", "另一段文本"], options=one_shot()
        )
        values = response["embeddings"][0]["values"]
        self.assertEqual(len(values), 3072)  # doc: default full dimension
        self.assertEqual(len(response["embeddings"][1]["values"]), 3072)
        usage = response.get("usageMetadata")
        if usage is not None:  # gemini-embedding-2/-preview return it; -001 does not
            self.assertGreater(usage.get("promptTokenCount", 0), 0)

    async def test_02_mrl_truncation_and_l2_normalization(self):
        values = await embed_one("裁剪维度测试", dim=768)
        self.assertEqual(len(values), 768)
        # Truncated MRL sub-vectors are NOT unit-length; normalize before
        # inner-product retrieval engines (doc Section 2.4).
        raw_norm = math.sqrt(sum(v * v for v in values))
        normalized = l2_normalize(values)
        self.assertAlmostEqual(
            math.sqrt(sum(v * v for v in normalized)), 1.0, places=5
        )
        self.assertNotEqual(raw_norm, 1.0, "truncated vector should not be unit-length")

    async def test_03_asymmetric_retrieval_pair_semantics(self):
        query = await embed_one("怎么给向量做归一化", task_type="RETRIEVAL_QUERY", dim=768)
        doc_hit = await embed_one(
            "L2 归一化将向量除以其模长使模长为 1；MRL 裁剪维度后的向量必须重新归一化才能入内积检索引擎",
            task_type="RETRIEVAL_DOCUMENT", title="向量归一化", dim=768,
        )
        doc_miss = await embed_one(
            "今天午市特价：三文鱼刺身买一送一",
            task_type="RETRIEVAL_DOCUMENT", title="餐厅促销", dim=768,
        )
        sim_hit = cosine_similarity(query, doc_hit)
        sim_miss = cosine_similarity(query, doc_miss)
        self.assertGreater(sim_hit, sim_miss, f"hit {sim_hit:.3f} should beat miss {sim_miss:.3f}")

    async def test_04_batch_preserves_order(self):
        response = await make_client().batch_embed_contents(
            ["第一条待检索文本", "第二条待检索文本", "第三条待检索文本"],
            options=one_shot(),
        )
        self.assertEqual(len(response["embeddings"]), 3)
        for item in response["embeddings"]:
            self.assertEqual(len(item["values"]), 3072)

    async def test_05_single_embed_content_method(self):
        # Official endpoint serves :embedContent; the local gateway currently
        # returns 404 for it (batch only). Verify the client path when served,
        # skip with the reason when not.
        try:
            response = await make_client().embed_content("hello", options=one_shot())
            self.assertGreater(len(response["embedding"]["values"]), 0)
        except LLMClientError as exc:
            if exc.status_code == 404:
                self.skipTest(
                    "single :embedContent not served by this endpoint "
                    "(local gateway serves :batchEmbedContents only)"
                )
            raise


if __name__ == "__main__":
    unittest.main()
