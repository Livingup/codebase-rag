"""
Reusable live-endpoint integration tests for DeepSeek's web Search & Fetch
tool APIs (https://api.deepseek.com/v1/tools/*, see DEEPSEEK_TOOLS_API.md).

Configuration (all optional):
    DEEPSEEK_LIVE_API_KEY       required to run (no default; suite skips)
    DEEPSEEK_TOOLS_BASE_URL     default https://api.deepseek.com

Run (from the repository root that contains `pythonsdk/`):

    DEEPSEEK_LIVE_API_KEY=sk-xxx python -m unittest pythonsdk.tests.test_deepseek_tools_live -v

NOTE: Search/Fetch are billed per successful request (5 CNY / 1000 calls).
This suite issues ~4 billable requests per run.
"""

from __future__ import annotations

import os
import socket
import sys
import unittest
import urllib.parse
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from pythonsdk import ClientConfig, DeepSeekToolsClient, RetryPolicy, RequestOptions
from pythonsdk.errors import ErrorKind, LLMClientError

API_KEY = os.environ.get("DEEPSEEK_LIVE_API_KEY", "")
BASE_URL = os.environ.get("DEEPSEEK_TOOLS_BASE_URL", "https://api.deepseek.com")


def _endpoint_available() -> bool:
    if not API_KEY:
        return False
    try:
        parsed = urllib.parse.urlsplit(BASE_URL)
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        with socket.create_connection((parsed.hostname, port), timeout=3):
            return True
    except OSError:
        return False


def make_client() -> DeepSeekToolsClient:
    return DeepSeekToolsClient(ClientConfig(api_key=API_KEY, base_url=BASE_URL))


def one_shot() -> RequestOptions:
    return RequestOptions(retry_policy=RetryPolicy(max_attempts=1))


@unittest.skipUnless(_endpoint_available(), "live endpoint unreachable or DEEPSEEK_LIVE_API_KEY not set")
class DeepSeekToolsLiveTests(unittest.IsolatedAsyncioTestCase):
    async def test_01_search_returns_structured_results(self):
        response = await make_client().search(
            "DeepSeek API", count=3, ori_question="DeepSeek 提供哪些 API", options=one_shot()
        )
        self.assertGreaterEqual(len(response["results"]), 1)
        for item in response["results"]:
            self.assertTrue(item.get("title"))
            self.assertTrue(str(item.get("url", "")).startswith("http"))
            self.assertIn("snippet", item)
            self.assertIn("summary", item)

    async def test_02_search_site_operator_scopes_results(self):
        response = await make_client().search(
            "DeepSeek site:github.com", count=5, options=one_shot()
        )
        self.assertGreaterEqual(len(response["results"]), 1)
        for item in response["results"]:
            self.assertIn("github.com", item.get("url", ""))

    async def test_03_fetch_renders_markdown(self):
        page = await make_client().fetch("https://example.com", options=one_shot())
        self.assertEqual(page["title"], "Example Domain")
        self.assertGreater(len(page["content"]), 50)

    async def test_04_server_side_validation_error_400(self):
        # Bypass local validation via post_json to exercise the server's
        # error contract (OpenAI-compatible error body preserved verbatim).
        client = make_client()
        with self.assertRaises(LLMClientError) as ctx:
            await client.post_json(
                "/v1/tools/search", {"query": "x", "count": 99}, options=one_shot()
            )
        self.assertEqual(ctx.exception.kind, ErrorKind.BAD_REQUEST)
        self.assertEqual(ctx.exception.status_code, 400)
        self.assertIn("count", ctx.exception.raw_body or "")


if __name__ == "__main__":
    unittest.main()
