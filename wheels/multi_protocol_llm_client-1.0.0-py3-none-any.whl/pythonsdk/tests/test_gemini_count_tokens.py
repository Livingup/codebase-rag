"""Offline unit tests for GeminiEmbeddingClient.count_tokens (no network)."""

from __future__ import annotations

import asyncio
import json
import os
import sys
import unittest
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from pythonsdk import (
    ClaudeCountTokensClient,
    ClientConfig,
    ErrorKind,
    GeminiEmbeddingClient,
    LLMClientError,
)
from pythonsdk.transport import AsyncHttpResponse, AsyncHttpTransport, TransportTimeouts


class MockResponse(AsyncHttpResponse):
    def __init__(self, payload: dict[str, Any], status: int = 200) -> None:
        self._payload = payload
        self._status = status

    @property
    def status(self) -> int:
        return self._status

    @property
    def status_text(self) -> str:
        return "OK" if self._status < 400 else "Error"

    @property
    def headers(self) -> dict[str, str]:
        return {"Content-Type": "application/json"}

    async def iter_bytes(self, cancel_token=None, idle_timeout_ms: int = 120000):
        yield json.dumps(self._payload).encode("utf-8")

    async def read_all(self, cancel_token=None, timeout_ms: int = 30000) -> bytes:
        return json.dumps(self._payload).encode("utf-8")

    async def close(self) -> None:  # pragma: no cover - nothing to release
        return None


class MockTransport(AsyncHttpTransport):
    def __init__(self, responses: list[MockResponse]) -> None:
        self.responses = list(responses)
        self.requests: list[dict[str, Any]] = []

    async def send_stream(
        self,
        method: str,
        url: str,
        headers,
        body: bytes,
        timeouts: TransportTimeouts,
        cancel_token=None,
    ) -> AsyncHttpResponse:
        self.requests.append({"url": url, "headers": dict(headers), "body": body})
        return self.responses.pop(0)


def make_client(transport: MockTransport) -> GeminiEmbeddingClient:
    return GeminiEmbeddingClient(
        ClientConfig(api_key="g-test"),
        model="gemini-embedding-001",
        transport=transport,
    )


class GeminiCountTokensTest(unittest.TestCase):
    def test_returns_total_tokens(self) -> None:
        transport = MockTransport([MockResponse({"totalTokens": 7})])
        client = make_client(transport)

        total = asyncio.run(client.count_tokens("hello"))

        self.assertEqual(total, 7)
        request = transport.requests[0]
        self.assertTrue(request["url"].endswith("models/gemini-embedding-001:countTokens"))
        self.assertEqual(request["headers"]["x-goog-api-key"], "g-test")
        body = json.loads(request["body"])
        self.assertEqual(body, {"contents": [{"parts": [{"text": "hello"}]}]})

    def test_missing_total_tokens_raises_protocol_error(self) -> None:
        transport = MockTransport([MockResponse({})])
        client = make_client(transport)

        with self.assertRaises(LLMClientError) as ctx:
            asyncio.run(client.count_tokens("hello"))
        self.assertEqual(ctx.exception.kind, ErrorKind.PROTOCOL_ERROR)

    def test_empty_text_is_rejected_locally(self) -> None:
        client = make_client(MockTransport([]))

        with self.assertRaises(LLMClientError) as ctx:
            asyncio.run(client.count_tokens(""))
        self.assertEqual(ctx.exception.kind, ErrorKind.BAD_REQUEST)


def make_claude_client(transport: MockTransport) -> ClaudeCountTokensClient:
    return ClaudeCountTokensClient(
        ClientConfig(api_key="c-test"),
        anthropic_version="2023-06-01",
        anthropic_beta=["token-counting-2024-11-01"],
        transport=transport,
    )


class ClaudeCountTokensTest(unittest.TestCase):
    def test_returns_input_tokens_and_sends_headers(self) -> None:
        transport = MockTransport([MockResponse({"input_tokens": 42})])
        client = make_claude_client(transport)

        total = asyncio.run(
            client.count_tokens(
                {
                    "model": "claude-sonnet-4-5",
                    "messages": [{"role": "user", "content": "hello claude"}],
                    "system": "be concise",
                }
            )
        )

        self.assertEqual(total, 42)
        request = transport.requests[0]
        self.assertTrue(request["url"].endswith("/v1/messages/count_tokens"))
        self.assertEqual(request["headers"]["x-api-key"], "c-test")
        self.assertEqual(request["headers"]["anthropic-version"], "2023-06-01")
        self.assertEqual(request["headers"]["anthropic-beta"], "token-counting-2024-11-01")
        body = json.loads(request["body"])
        self.assertEqual(body["model"], "claude-sonnet-4-5")
        self.assertEqual(body["system"], "be concise")

    def test_missing_input_tokens_raises_protocol_error(self) -> None:
        transport = MockTransport([MockResponse({})])
        client = make_claude_client(transport)

        with self.assertRaises(LLMClientError) as ctx:
            asyncio.run(client.count_tokens({"model": "claude-sonnet-4-5", "messages": [{"role": "user", "content": "hi"}]}))
        self.assertEqual(ctx.exception.kind, ErrorKind.PROTOCOL_ERROR)

    def test_empty_model_or_messages_rejected_locally(self) -> None:
        transport = MockTransport([])
        client = make_claude_client(transport)
        for bad_req in (
            {"model": "", "messages": [{"role": "user", "content": "hi"}]},
            {"model": "claude-sonnet-4-5", "messages": []},
        ):
            with self.assertRaises(LLMClientError) as ctx:
                asyncio.run(client.count_tokens(bad_req))  # type: ignore[arg-type]
            self.assertEqual(ctx.exception.kind, ErrorKind.BAD_REQUEST)
        self.assertEqual(transport.requests, [])


@unittest.skipUnless(os.environ.get("GEMINI_API_KEY"), "GEMINI_API_KEY not set")
class GeminiCountTokensLiveTest(unittest.TestCase):
    def test_live_count_tokens(self) -> None:
        base_url = os.environ.get("GEMINI_BASE_URL") or None
        model = os.environ.get("GEMINI_EMBEDDING_MODEL", "gemini-embedding-001")
        client = GeminiEmbeddingClient(
            ClientConfig(api_key=os.environ["GEMINI_API_KEY"], base_url=base_url),
            model=model,
        )
        total = asyncio.run(client.count_tokens("hello world"))
        self.assertGreater(total, 0)


if __name__ == "__main__":
    unittest.main()
