"""
Live-endpoint integration tests for the OpenAI Chat Completions client
against DeepSeek's /chat/completions dialect (https://api.deepseek.com,
model deepseek-flash).

The suite pins DeepSeek's confirmed chat-completions dialect behavior
(2026-10 live probes, 40+ feature probes over two rounds):

  FULLY SUPPORTED
              streaming chat.completion.chunk frames terminated by the
              literal `data: [DONE]` sentinel; thinking extension
              `delta.reasoning_content` streamed before `delta.content`;
              function tools with index-bucketed argument fragments and
              parallel tool calls (multiple tool_calls in one turn);
              tool_choice required / named function (ONLY with thinking
              disabled — the default thinking mode rejects them with 400);
              response_format json_object (output is valid JSON); logprobs
              + top_logprobs (full token/bytes/top_logprobs structure);
              image_url input with real visual understanding (base64 data
              URL probed); assistant/tool content-block array replay;
              sampling params (temperature/top_p/stop/penalties/seed/
              logit_bias); usage attached to the final choice frame with
              completion_tokens_details.reasoning_tokens; automatic prefix
              context caching (prompt_cache_hit_tokens, no parameter
              needed); stateless multi-turn replay of the assembled
              assistant message — including `reasoning_content` replay.

  DIALECT TRAPS (differ from the official OpenAI wire contract)
              `max_completion_tokens` is silently IGNORED — only the
              deprecated `max_tokens` enforces the output limit; refusal
              text arrives in `content`, `refusal` stays null.

  DEEPSEEK-SPECIFIC PARAMS (accepted, outside the OpenAI contract)
              `thinking: {"type": "disabled"}` turns thinking off (usage
              then omits completion_tokens_details); `effort` low/high/max
              (per /models metadata; max visibly deepens thinking);
              `reasoning_effort` low/high is also honored.

  SILENTLY IGNORED (HTTP 200, no effect)
              web_search_options (no live search, no annotations),
              prediction (no accepted_prediction_tokens), modalities+audio
              (no audio output; /models declares output text-only),
              verbosity, prompt_cache_key, prompt_cache_retention,
              max_completion_tokens.

  NOT SUPPORTED (hard 400/422)
              `developer` role (422; roles: system/user/assistant/tool/
              latest_reminder), `input_audio` content part (422), `file`
              content part (400 on file_data data-URL, raw base64 and
              file_id alike — PDF input unusable), n > 1 (400), response_
              format json_schema (400 "unavailable"), `custom` tools (422),
              tool_choice allowed_tools (422), tool_choice required/named
              under the default thinking mode (400).

Note: the case matrix above would fail against a full official OpenAI
endpoint (e.g. official rejects `max_tokens` on reasoning models while
DeepSeek requires it); for generic client tests point DEEPSEEK_LIVE_BASE_URL
at a full endpoint and treat tests 10/11/12 accordingly.

Configuration (all optional):
    DEEPSEEK_LIVE_BASE_URL     default https://api.deepseek.com
    DEEPSEEK_LIVE_API_KEY      required to run (no default; suite skips)
    DEEPSEEK_LIVE_MODEL        default deepseek-flash
    DEEPSEEK_LIVE_RESOURCE_DIR default <repo parent>/testresouce

Run (from the repository root that contains `pythonsdk/`):

    DEEPSEEK_LIVE_API_KEY=sk-xxx python -m unittest pythonsdk.tests.test_openai_chat_completions_live -v
"""

from __future__ import annotations

import asyncio
import base64
import json
import os
import socket
import sys
import unittest
import urllib.parse
from pathlib import Path
from typing import Any, Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from pythonsdk import (
    ClientConfig,
    OpenAIChatCompletionsClient,
    OpenAIChatCompletionsRequest,
    RequestOptions,
    RetryPolicy,
)
from pythonsdk.errors import ErrorKind, LLMClientError

LIVE_BASE_URL = os.environ.get("DEEPSEEK_LIVE_BASE_URL", "https://api.deepseek.com")
LIVE_API_KEY = os.environ.get("DEEPSEEK_LIVE_API_KEY", "")
LIVE_MODEL = os.environ.get("DEEPSEEK_LIVE_MODEL", "deepseek-flash")
RESOURCE_DIR = Path(
    os.environ.get(
        "DEEPSEEK_LIVE_RESOURCE_DIR",
        str(Path(__file__).resolve().parents[2] / "testresouce"),
    )
)


def _endpoint_available() -> bool:
    if not LIVE_API_KEY:
        return False
    try:
        parsed = urllib.parse.urlsplit(LIVE_BASE_URL)
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        with socket.create_connection((parsed.hostname, port), timeout=3):
            return True
    except OSError:
        return False


def make_client() -> OpenAIChatCompletionsClient:
    return OpenAIChatCompletionsClient(
        ClientConfig(api_key=LIVE_API_KEY, base_url=LIVE_BASE_URL)
    )


def one_shot_policy() -> RequestOptions:
    return RequestOptions(retry_policy=RetryPolicy(max_attempts=1))


async def collect(
    request: OpenAIChatCompletionsRequest,
    options: Optional[RequestOptions] = None,
) -> list[Any]:
    events: list[Any] = []
    async for ev in make_client().stream(request, options or one_shot_policy()):
        events.append(ev)
    return events


def types_of(events: list[Any]) -> list[str]:
    return [e.type for e in events]


@unittest.skipUnless(
    _endpoint_available(), "DeepSeek live endpoint unreachable or API key unset"
)
class TestOpenAIChatCompletionsLive(unittest.IsolatedAsyncioTestCase):
    """End-to-end tests against the real DeepSeek /chat/completions endpoint."""

    async def test_01_basic_text_stream_lifecycle(self):
        events = await collect(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[{"role": "user", "content": "1+1=?只回答阿拉伯数字"}],
            )
        )
        types = types_of(events)
        self.assertEqual(types[0], "request_start")
        self.assertIn("response_start", types)
        self.assertIn("text_delta", types)
        self.assertEqual(types[-1], "response_complete")

        complete = events[-1]
        self.assertTrue(complete.response_id)
        self.assertEqual(complete.stop_reason, "stop")
        self.assertGreater(complete.usage.input_tokens, 0)
        self.assertGreater(complete.usage.output_tokens, 0)
        self.assertEqual(
            complete.usage.total_tokens,
            complete.usage.input_tokens + complete.usage.output_tokens,
        )
        # n=1 -> exactly one replayable native assistant message
        self.assertEqual(len(complete.output), 1)
        msg = complete.output[0]
        self.assertEqual(msg["role"], "assistant")
        self.assertTrue(msg["content"].strip())

    async def test_02_thinking_lifecycle_reasoning_content(self):
        events = await collect(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[{"role": "user", "content": "9.11和9.9哪个大？一句话回答"}],
            )
        )
        types = types_of(events)
        # DeepSeek streams reasoning_content before content (2026-10 probe).
        self.assertIn("thinking_start", types)
        self.assertIn("thinking_delta", types)
        self.assertIn("thinking_stop", types)
        self.assertIn("text_stop", types)
        # lifecycle order: thinking closes before text opens
        self.assertLess(types.index("thinking_stop"), types.index("text_start"))

        complete = events[-1]
        msg = complete.output[0]
        self.assertIn("reasoning_content", msg)
        self.assertTrue(msg["reasoning_content"])
        # DeepSeek reports reasoning tokens in the usage detail
        self.assertGreaterEqual(complete.usage.reasoning_tokens, 0)

    async def test_03_stateless_multi_turn_replay(self):
        turn1 = await collect(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[
                    {
                        "role": "user",
                        "content": "我叫小明，我养了一只橘猫叫大橘。请记住。",
                    }
                ],
            )
        )
        assistant_msg = turn1[-1].output[0]

        turn2 = await collect(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[
                    {"role": "user", "content": "我叫小明，我养了一只橘猫叫大橘。请记住。"},
                    assistant_msg,
                    {"role": "user", "content": "我的猫叫什么名字？只回答名字"},
                ],
            )
        )
        complete = turn2[-1]
        self.assertEqual(complete.stop_reason, "stop")
        self.assertIn("大橘", complete.output[0]["content"])

    async def test_04_function_tool_call_round_trip(self):
        weather_tool = {
            "type": "function",
            "function": {
                "name": "get_weather",
                "description": "查询指定城市的实时天气",
                "parameters": {
                    "type": "object",
                    "properties": {
                        "city": {"type": "string", "description": "城市名称"}
                    },
                    "required": ["city"],
                },
            },
        }
        events = await collect(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[{"role": "user", "content": "帮我查一下北京的天气"}],
                tools=[weather_tool],
                tool_choice="auto",
            )
        )
        types = types_of(events)
        self.assertIn("tool_call_start", types)
        self.assertIn("tool_call_stop", types)

        complete = events[-1]
        self.assertEqual(complete.stop_reason, "tool_calls")
        msg = complete.output[0]
        # The model may emit a short text preamble before calling the tool
        # (text -> tool_calls is a legal mixed sequence); content then stays
        # a string instead of null.
        self.assertTrue(msg["content"] is None or isinstance(msg["content"], str))
        self.assertEqual(len(msg["tool_calls"]), 1)
        tc = msg["tool_calls"][0]
        self.assertEqual(tc["type"], "function")
        self.assertEqual(tc["function"]["name"], "get_weather")
        args = json.loads(tc["function"]["arguments"])
        self.assertIn("北京", args["city"])

        # Replay: assistant tool_call message + tool result -> final answer
        events2 = await collect(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[
                    {"role": "user", "content": "帮我查一下北京的天气"},
                    msg,
                    {
                        "role": "tool",
                        "tool_call_id": tc["id"],
                        "content": json.dumps(
                            {"city": "北京", "weather": "晴", "temp_c": 22},
                            ensure_ascii=False,
                        ),
                    },
                ],
            )
        )
        complete2 = events2[-1]
        self.assertEqual(complete2.stop_reason, "stop")
        self.assertIn("晴", complete2.output[0]["content"])

    async def test_05_custom_body_json_override(self):
        # Shallow root override must reach the wire (verified by behavior:
        # temperature is accepted; a bogus key would 400).
        events = await collect(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[{"role": "user", "content": "回复OK两个字母即可"}],
            ),
            RequestOptions(
                retry_policy=RetryPolicy(max_attempts=1),
                custom_body_json=json.dumps({"temperature": 0.0}),
            ),
        )
        self.assertEqual(types_of(events)[-1], "response_complete")
        self.assertTrue(events[-1].output[0]["content"].strip())

    async def test_06_bad_api_key_maps_to_auth_error(self):
        client = OpenAIChatCompletionsClient(
            ClientConfig(api_key="sk-invalid-key", base_url=LIVE_BASE_URL)
        )
        with self.assertRaises(LLMClientError) as ctx:
            async for _ in client.stream(
                OpenAIChatCompletionsRequest(
                    model=LIVE_MODEL,
                    messages=[{"role": "user", "content": "hi"}],
                ),
                one_shot_policy(),
            ):
                pass
        self.assertEqual(ctx.exception.kind, ErrorKind.AUTH_ERROR)
        self.assertFalse(ctx.exception.is_retryable)
        self.assertEqual(ctx.exception.status_code, 401)

    async def test_07_parallel_tool_calls(self):
        events = await collect(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[{"role": "user", "content": "同时查北京和上海两个城市的天气，两个都要查"}],
                tools=[weather_tool()],
                tool_choice="auto",
                parallel_tool_calls=True,
            )
        )
        complete = events[-1]
        self.assertEqual(complete.stop_reason, "tool_calls")
        tool_calls = complete.output[0]["tool_calls"]
        self.assertEqual(len(tool_calls), 2)
        cities = [json.loads(tc["function"]["arguments"])["city"] for tc in tool_calls]
        self.assertIn("北京", cities)
        self.assertIn("上海", cities)

    async def test_08_image_input_data_url(self):
        png = next(RESOURCE_DIR.glob("*.png"), None)
        if png is None:
            self.skipTest("no .png resource in testresouce")
        data_url = "data:image/png;base64," + base64.b64encode(png.read_bytes()).decode()
        events = await collect(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": "这张图里有什么动物？只答动物名"},
                            {"type": "image_url", "image_url": {"url": data_url, "detail": "low"}},
                        ],
                    }
                ],
            )
        )
        complete = events[-1]
        self.assertEqual(complete.stop_reason, "stop")
        self.assertIn("鸟", complete.output[0]["content"])

    async def test_09_response_format_json_object(self):
        events = await collect(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[{"role": "user", "content": "返回JSON对象，键name值为test，键score值为99"}],
                response_format={"type": "json_object"},
            )
        )
        content = events[-1].output[0]["content"]
        parsed = json.loads(content)
        self.assertEqual(parsed["name"], "test")
        self.assertEqual(parsed["score"], 99)

    async def test_10_token_limit_dialect_trap(self):
        # Dialect trap: DeepSeek IGNORES max_completion_tokens — only the
        # deprecated max_tokens enforces the output limit.
        events = await collect(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[{"role": "user", "content": "回复OK两个字母即可"}],
                max_tokens=5,
            )
        )
        self.assertEqual(events[-1].stop_reason, "length")

        events2 = await collect(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[{"role": "user", "content": "回复OK两个字母即可"}],
                max_completion_tokens=5,
            )
        )
        self.assertEqual(events2[-1].stop_reason, "stop")

    async def test_11_tool_choice_required_with_thinking_disabled(self):
        # tool_choice required/named is rejected under the default thinking
        # mode; with DeepSeek's own `thinking: {"type": "disabled"}` it works.
        events = await collect(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[{"role": "user", "content": "北京天气如何？"}],
                tools=[weather_tool()],
                tool_choice="required",
                extra_fields={"thinking": {"type": "disabled"}},
            )
        )
        complete = events[-1]
        self.assertEqual(complete.stop_reason, "tool_calls")
        self.assertEqual(complete.output[0]["tool_calls"][0]["function"]["name"], "get_weather")

    async def test_12_dialect_rejection_matrix(self):
        """Stable hard-rejection facts (BAD_REQUEST, never retried)."""

        async def expect_bad_request(request: OpenAIChatCompletionsRequest) -> None:
            with self.assertRaises(LLMClientError) as ctx:
                async for _ in make_client().stream(request, one_shot_policy()):
                    pass
            self.assertEqual(ctx.exception.kind, ErrorKind.BAD_REQUEST)
            self.assertFalse(ctx.exception.is_retryable)
            self.assertIn(ctx.exception.status_code, (400, 422))

        await expect_bad_request(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[{"role": "developer", "content": "x"}, {"role": "user", "content": "hi"}],
            )
        )
        await expect_bad_request(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": "listen"},
                            {"type": "input_audio", "input_audio": {"data": "QUJD", "format": "mp3"}},
                        ],
                    }
                ],
            )
        )
        await expect_bad_request(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[{"role": "user", "content": "hi"}],
                tools=[{"type": "custom", "custom": {"name": "sql", "format": {"type": "text"}}}],
            )
        )
        await expect_bad_request(
            OpenAIChatCompletionsRequest(
                model=LIVE_MODEL,
                messages=[{"role": "user", "content": "hi"}],
                n=2,
            )
        )


def weather_tool() -> dict[str, Any]:
    return {
        "type": "function",
        "function": {
            "name": "get_weather",
            "description": "查询指定城市的实时天气",
            "parameters": {
                "type": "object",
                "properties": {"city": {"type": "string", "description": "城市名称"}},
                "required": ["city"],
            },
        },
    }


if __name__ == "__main__":
    unittest.main()
