"""
Reusable live-endpoint integration tests for the Gemini client.

These cases are versioned with the SDK and re-runnable against any
Gemini-compatible gateway. They exercise the wire stack end to end
(transport -> SSE framing -> state machine) and are automatically
skipped when the endpoint or test resources are unavailable.

Configuration (all optional):
    GEMINI_LIVE_BASE_URL     default http://127.0.0.1:18317/v1beta
    GEMINI_LIVE_RESOURCE_DIR default <repo parent>/testresouce
    GEMINI_LIVE_FLASH        default gemini-3.8-flash
    GEMINI_LIVE_TRANSCRIBE   default gemini-3.5-transcribe
    GEMINI_LIVE_TTS          default gemini-3.8-flash-tts

Run (from the repository root that contains `pythonsdk/`):

    python -m unittest pythonsdk.tests.test_gemini_live -v
"""

from __future__ import annotations

import asyncio
import base64
import json
import os
import socket
import sys
import unittest
import urllib.parse
from pathlib import Path
from typing import Any, Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from pythonsdk import (
    ClientConfig,
    GeminiStreamClient,
    GeminiStreamRequest,
    HttpInspector,
    RequestOptions,
)

LIVE_BASE_URL = os.environ.get("GEMINI_LIVE_BASE_URL", "http://127.0.0.1:18317/v1beta")
RESOURCE_DIR = Path(
    os.environ.get(
        "GEMINI_LIVE_RESOURCE_DIR",
        str(Path(__file__).resolve().parents[2] / "testresouce"),
    )
)
MODEL_FLASH = os.environ.get("GEMINI_LIVE_FLASH", "gemini-3.8-flash")
MODEL_TRANSCRIBE = os.environ.get("GEMINI_LIVE_TRANSCRIBE", "gemini-3.5-transcribe")
MODEL_TTS = os.environ.get("GEMINI_LIVE_TTS", "gemini-3.8-flash-tts")


def _endpoint_available() -> bool:
    try:
        parsed = urllib.parse.urlsplit(LIVE_BASE_URL)
        with socket.create_connection((parsed.hostname, parsed.port), timeout=2):
            return True
    except OSError:
        return False


def make_client() -> GeminiStreamClient:
    return GeminiStreamClient(
        ClientConfig(api_key="local-no-auth", base_url=LIVE_BASE_URL)
    )


def b64_resource(name: str) -> Optional[str]:
    path = RESOURCE_DIR / name
    if not path.is_file():
        return None
    return base64.b64encode(path.read_bytes()).decode("ascii")


async def collect(client: GeminiStreamClient, request: GeminiStreamRequest) -> list[Any]:
    events: list[Any] = []
    async for ev in client.stream(request):
        events.append(ev)
    return events


def complete_of(events: list[Any]) -> Any:
    matches = [e for e in events if e.type == "response_complete"]
    assert matches, f"no response_complete event; types={[e.type for e in events]}"
    return matches[0]


def output_text(events: list[Any]) -> str:
    """Concatenates textual content from output parts, covering both plain
    `text` parts and the `audioTranscription` carrier used by transcription
    models."""
    chunks: list[str] = []
    for part in complete_of(events).output.get("parts", []):
        if part.get("thought"):
            continue
        if "text" in part:
            chunks.append(str(part["text"]))
        elif "audioTranscription" in part and isinstance(part["audioTranscription"], dict):
            chunks.append(str(part["audioTranscription"].get("text", "")))
    return "".join(chunks)


def types_of(events: list[Any]) -> list[str]:
    return [getattr(e, "type", type(e).__name__) for e in events]


@unittest.skipUnless(_endpoint_available(), f"live endpoint {LIVE_BASE_URL} unreachable")
class GeminiLiveTests(unittest.IsolatedAsyncioTestCase):
    """End-to-end cases against a real Gemini-compatible gateway."""

    def _resource_or_skip(self, name: str, mime: str) -> dict[str, Any]:
        data = b64_resource(name)
        if data is None:
            self.skipTest(f"resource not found: {RESOURCE_DIR / name}")
        return {"inlineData": {"mimeType": mime, "data": data}}

    async def test_01_basic_streaming_text_and_usage(self):
        events = await collect(
            make_client(),
            GeminiStreamRequest(
                model=MODEL_FLASH,
                contents=[{"role": "user", "parts": [{"text": "用一句话回答：长城是什么？"}]}],
            ),
        )
        self.assertIn("response_start", types_of(events))
        self.assertEqual(types_of(events)[-1], "response_complete")
        complete = complete_of(events)
        self.assertGreater(complete.usage.total_tokens, 0)
        self.assertTrue(
            any(p.get("text") or p.get("thought") for p in complete.output["parts"])
        )
        # Stateless replay fidelity: signatures (if any) survive on the parts.
        for part in complete.output["parts"]:
            if "functionCall" in part:
                self.assertIn("thoughtSignature", part)

    async def test_02_stateless_multi_turn_replay(self):
        client = make_client()
        contents: list[dict] = [
            {"role": "user", "parts": [{"text": "请记住这个暗号：蓝色的山雀。只回复'好的'。"}]}
        ]
        first = await collect(
            client, GeminiStreamRequest(model=MODEL_FLASH, contents=contents)
        )
        contents.append(complete_of(first).output)
        contents.append({"role": "user", "parts": [{"text": "暗号是什么？只回答暗号本身。"}]})
        second = await collect(
            client, GeminiStreamRequest(model=MODEL_FLASH, contents=contents)
        )
        text = output_text(second)
        self.assertIn("蓝", text)
        self.assertIn("山雀", text)

    async def test_03_function_calling_and_tool_result_replay(self):
        client = make_client()
        weather_tool = {
            "functionDeclarations": [
                {
                    "name": "get_weather",
                    "description": "查询指定城市的实时天气",
                    # NOTE: Gemini Schema types are UPPERCASE proto enum names.
                    "parameters": {
                        "type": "OBJECT",
                        "properties": {"city": {"type": "STRING", "description": "城市名"}},
                        "required": ["city"],
                    },
                }
            ]
        }
        contents: list[dict] = [
            {"role": "user", "parts": [{"text": "北京今天天气怎么样？请调用工具查询。"}]}
        ]
        first = await collect(
            client,
            GeminiStreamRequest(model=MODEL_FLASH, contents=contents, tools=[weather_tool]),
        )
        stops = [e for e in first if e.type == "tool_call_stop"]
        self.assertTrue(stops, "expected tool_call_stop event")
        args = json.loads(stops[0].arguments_raw)
        self.assertEqual(args.get("city"), "北京")

        model_output = complete_of(first).output
        call_parts = [p for p in model_output["parts"] if "functionCall" in p]
        self.assertTrue(call_parts)
        self.assertTrue(all(p.get("thoughtSignature") for p in call_parts))

        contents.append(model_output)
        function_response: dict[str, Any] = {
            "name": call_parts[0]["functionCall"]["name"],
            "response": {"temperature_c": 21, "condition": "晴", "wind": "北风3级"},
        }
        if call_parts[0]["functionCall"].get("id"):
            function_response["id"] = call_parts[0]["functionCall"]["id"]
        contents.append(
            {"role": "user", "parts": [{"functionResponse": function_response}]}
        )
        second = await collect(
            client,
            GeminiStreamRequest(model=MODEL_FLASH, contents=contents, tools=[weather_tool]),
        )
        text = output_text(second)
        self.assertTrue("晴" in text or "21" in text, f"reply should cite tool result: {text!r}")

    async def test_04_image_understanding(self):
        request = GeminiStreamRequest(
            model=MODEL_FLASH,
            contents=[
                {
                    "role": "user",
                    "parts": [
                        self._resource_or_skip(
                            "林间小憩_小鸟油画.png", "image/png"
                        ),
                        {"text": "用一句话描述这幅画。"},
                    ],
                }
            ],
        )
        events = await collect(make_client(), request)
        self.assertGreater(len(output_text(events).strip()), 5)

    async def test_05_pdf_understanding(self):
        pdf_name = next(
            (n for n in os.listdir(RESOURCE_DIR) if n.lower().endswith(".pdf"))
            if RESOURCE_DIR.is_dir()
            else None,
            None,
        )
        if pdf_name is None:
            self.skipTest("no .pdf resource available")
        request = GeminiStreamRequest(
            model=MODEL_FLASH,
            contents=[
                {
                    "role": "user",
                    "parts": [
                        self._resource_or_skip(pdf_name, "application/pdf"),
                        {"text": "这份 PDF 的主题是什么？一句话概括。"},
                    ],
                }
            ],
        )
        events = await collect(make_client(), request)
        self.assertGreater(len(output_text(events).strip()), 5)

    async def test_06_audio_transcription_streams_text_events(self):
        audio_name = next(
            (
                n
                for n in os.listdir(RESOURCE_DIR)
                if n.lower().endswith((".m4a", ".mp3", ".wav"))
            )
            if RESOURCE_DIR.is_dir()
            else None,
            None,
        )
        if audio_name is None:
            self.skipTest("no audio resource available")
        request = GeminiStreamRequest(
            model=MODEL_TRANSCRIBE,
            contents=[
                {
                    "role": "user",
                    "parts": [
                        self._resource_or_skip(audio_name, "audio/mp4"),
                        {"text": "请把这段音频的内容逐字转写为文字。"},
                    ],
                }
            ],
        )
        events = await collect(make_client(), request)
        # The transcription text must surface through streaming deltas, not
        # only inside response_complete.output.
        deltas = "".join(e.delta for e in events if e.type == "text_delta")
        self.assertTrue(deltas.strip(), "transcription text should stream via text_delta")
        self.assertEqual(deltas.strip(), output_text(events).strip())
        # Raw parts stay verbatim (audioTranscription carrier preserved).
        complete = complete_of(events)
        self.assertTrue(
            any("audioTranscription" in p for p in complete.output["parts"])
        )

    async def test_07_text_to_speech_returns_audio_parts(self):
        request = GeminiStreamRequest(
            model=MODEL_TTS,
            contents=[{"role": "user", "parts": [{"text": "用平静的语气说：今天天气不错。"}]}],
            generationConfig={
                "responseModalities": ["AUDIO"],
                "speechConfig": {
                    "voiceConfig": {"prebuiltVoiceConfig": {"voiceName": "Kore"}}
                },
            },
        )
        events = await collect(make_client(), request)
        complete = complete_of(events)
        audio_parts = [p for p in complete.output["parts"] if "inlineData" in p]
        self.assertTrue(audio_parts, "TTS response should contain inlineData audio parts")
        for part in audio_parts:
            self.assertTrue(part["inlineData"].get("data"))
            self.assertTrue(str(part["inlineData"].get("mimeType", "")).startswith("audio/"))
        # FR-STATE-09: audio must also stream through lifecycle events so the
        # upstream can play it incrementally instead of waiting for completion.
        audio_deltas = [e for e in events if e.type == "audio_delta"]
        self.assertTrue(audio_deltas, "audio should stream via audio_delta events")
        self.assertEqual(
            "".join(d.audio_delta for d in audio_deltas),
            "".join(str(p["inlineData"].get("data", "")) for p in audio_parts),
        )
        self.assertTrue(any(e.type == "audio_start" for e in events))
        self.assertTrue(any(e.type == "audio_stop" for e in events))

    async def test_08_inspector_four_hooks_fire(self):
        class Probe(HttpInspector):
            def __init__(self) -> None:
                self.seen: list[str] = []

            def on_request(self, ctx) -> None:
                self.seen.append("request")

            def on_response_headers(self, ctx) -> None:
                self.seen.append("response_headers")

            def on_raw_stream_chunk(self, ctx) -> None:
                self.seen.append("raw_chunk")

            def on_exchange_complete(self, ctx) -> None:
                self.seen.append(f"complete:{ctx.outcome}")

        probe = Probe()
        client = make_client().use_inspector(probe)
        events = await collect(
            client,
            GeminiStreamRequest(
                model=MODEL_FLASH,
                contents=[{"role": "user", "parts": [{"text": "回复 ok 即可"}]}],
            ),
        )
        self.assertEqual(types_of(events)[-1], "response_complete")
        self.assertIn("request", probe.seen)
        self.assertIn("response_headers", probe.seen)
        self.assertIn("raw_chunk", probe.seen)
        self.assertIn("complete:completed", probe.seen)
        self.assertEqual(probe.seen[-1], "complete:completed")


if __name__ == "__main__":
    unittest.main()
