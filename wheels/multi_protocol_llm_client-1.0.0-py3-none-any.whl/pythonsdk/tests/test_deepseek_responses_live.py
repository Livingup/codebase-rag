"""
Reusable live-endpoint integration tests for DeepSeek's /responses dialect.

These cases exercise the OpenAI Responses *client* against DeepSeek's partial
implementation of the protocol (https://api.deepseek.com/responses, model
deepseek-flash). DeepSeek emits standard-shaped Responses events — including
the documented message `phase` field — so the client runs unmodified; the
suite pins DeepSeek's confirmed dialect behavior (2026-10 live probes):

  SUPPORTED   text in/out, reasoning (reasoning_text.delta) with
              encrypted_content on the reasoning item, stateless multi-turn
              replay, `function` tools + function_call_output replay,
              input_image (base64 data URL), store:true/false, and the
              include=["reasoning.encrypted_content"] parameter.
  NOT SUPPORTED (silently accepted at the protocol level, semantics not
              implemented): additional_tools input items, tool_search tool
              definitions, previous_response_id stateful mode.
  NOT SUPPORTED (protocol-accepted but content replaced): input_file PDF
              parts arrive at the model as "[Unsupported Document]".

Note tests 05/06 encode DeepSeek-specific behavior and would fail against a
full OpenAI endpoint (which rejects unknown previous_response_id with 404);
for generic client tests against a full endpoint, point DEEPSEEK_LIVE_BASE_URL
at it and treat 05/06 accordingly.

Configuration (all optional):
    DEEPSEEK_LIVE_BASE_URL     default https://api.deepseek.com
    DEEPSEEK_LIVE_API_KEY      required to run (no default; suite skips)
    DEEPSEEK_LIVE_MODEL        default deepseek-flash
    DEEPSEEK_LIVE_RESOURCE_DIR default <repo parent>/testresouce

Run (from the repository root that contains `pythonsdk/`):

    DEEPSEEK_LIVE_API_KEY=sk-xxx python -m unittest pythonsdk.tests.test_deepseek_responses_live -v
"""

from __future__ import annotations

import asyncio
import base64
import json
import os
import socket
import sys
import unittest
import urllib.parse
import uuid
from pathlib import Path
from typing import Any, Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from pythonsdk import (
    ClientConfig,
    OpenAIResponsesClient,
    OpenAIResponsesRequest,
    RequestOptions,
    RetryPolicy,
)
from pythonsdk.errors import LLMClientError

LIVE_BASE_URL = os.environ.get("DEEPSEEK_LIVE_BASE_URL", "https://api.deepseek.com")
LIVE_API_KEY = os.environ.get("DEEPSEEK_LIVE_API_KEY", "")
LIVE_MODEL = os.environ.get("DEEPSEEK_LIVE_MODEL", "deepseek-flash")
RESOURCE_DIR = Path(
    os.environ.get(
        "DEEPSEEK_LIVE_RESOURCE_DIR",
        str(Path(__file__).resolve().parents[2] / "testresouce"),
    )
)


def _endpoint_available() -> bool:
    if not LIVE_API_KEY:
        return False
    try:
        parsed = urllib.parse.urlsplit(LIVE_BASE_URL)
        port = parsed.port or (443 if parsed.scheme == "https" else 80)
        with socket.create_connection((parsed.hostname, port), timeout=3):
            return True
    except OSError:
        return False


def make_client() -> OpenAIResponsesClient:
    # The SDK defaults to store=False and auto-injects
    # include=["reasoning.encrypted_content"]; the probes confirmed DeepSeek
    # accepts both and actually returns encrypted_content on reasoning items.
    return OpenAIResponsesClient(
        ClientConfig(api_key=LIVE_API_KEY, base_url=LIVE_BASE_URL)
    )


def one_shot_policy() -> RequestOptions:
    return RequestOptions(retry_policy=RetryPolicy(max_attempts=1))


async def collect(request: OpenAIResponsesRequest) -> list[Any]:
    events: list[Any] = []
    async for ev in make_client().stream(request, one_shot_policy()):
        events.append(ev)
    return events


def complete_of(events: list[Any]) -> Any:
    matches = [e for e in events if e.type == "response_complete"]
    assert matches, f"no response_complete event; types={[e.type for e in events]}"
    return matches[0]


def message_text(complete: Any) -> str:
    return "".join(
        part.get("text", "")
        for item in complete.output
        if item.get("type") == "message"
        for part in item.get("content", [])
    )


def b64_resource(name: str) -> Optional[str]:
    path = RESOURCE_DIR / name
    if not path.is_file():
        return None
    return base64.b64encode(path.read_bytes()).decode("ascii")


@unittest.skipUnless(
    _endpoint_available(),
    "live endpoint unreachable or DEEPSEEK_LIVE_API_KEY not set",
)
class DeepSeekResponsesLiveTests(unittest.IsolatedAsyncioTestCase):
    async def test_01_basic_streaming_text_with_usage(self):
        events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL,
                input="用一句话回答：长城是什么？",
                max_output_tokens=500,
            )
        )
        types = [e.type for e in events]
        self.assertEqual(types[0], "request_start")
        self.assertIn("response_start", types)
        self.assertIn("text_start", types)
        self.assertIn("text_delta", types)
        self.assertEqual(types[-1], "response_complete")
        complete = complete_of(events)
        self.assertGreater(complete.usage.total_tokens, 0)
        self.assertIn("message", [i.get("type") for i in complete.output])
        self.assertGreater(len(message_text(complete).strip()), 5)

    async def test_02_stateless_multi_turn_replay(self):
        first = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL,
                input="记住暗号：蓝色的山雀。只回复'好的'。",
                max_output_tokens=500,
            )
        )
        complete = complete_of(first)
        reasoning_items = [i for i in complete.output if i.get("type") == "reasoning"]
        # When the model reasons, the auto-injected include makes the item
        # carry encrypted_content — required for replaying it statelessly.
        for item in reasoning_items:
            self.assertIn("encrypted_content", item)

        history = (
            [{"role": "user", "content": "记住暗号：蓝色的山雀。只回复'好的'。"}]
            + list(complete.output)
            + [{"role": "user", "content": "暗号是什么？只回答暗号本身。"}]
        )
        second = await collect(
            OpenAIResponsesRequest(model=LIVE_MODEL, input=history, max_output_tokens=800)
        )
        text = message_text(complete_of(second))
        self.assertIn("蓝", text)
        self.assertIn("山雀", text)

    async def test_03_function_calling_full_loop(self):
        tools = [
            {
                "type": "function",
                "name": "get_weather",
                "description": "查询指定城市的实时天气",
                "parameters": {
                    "type": "object",
                    "properties": {"city": {"type": "string"}},
                    "required": ["city"],
                },
            }
        ]
        first = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL,
                input="北京今天天气怎么样？请调用工具查询。",
                tools=tools,
                max_output_tokens=800,
            )
        )
        starts = [e for e in first if e.type == "tool_call_start"]
        stops = [e for e in first if e.type == "tool_call_stop"]
        self.assertTrue(starts, "expected immediate tool_call_start")
        self.assertTrue(stops, "expected tool_call_stop")
        args = json.loads(stops[0].arguments_raw)
        self.assertEqual(args.get("city"), "北京")
        call = next(i for i in complete_of(first).output if i.get("type") == "function_call")
        self.assertEqual(call["name"], "get_weather")

        history = [
            {"role": "user", "content": "北京今天天气怎么样？请调用工具查询。"},
            call,
            {
                "type": "function_call_output",
                "call_id": call["call_id"],
                "output": json.dumps({"temp_c": 21, "cond": "晴"}, ensure_ascii=False),
            },
        ]
        second = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, input=history, tools=tools, max_output_tokens=1500
            )
        )
        text = message_text(complete_of(second))
        self.assertTrue(
            "晴" in text or "21" in text, f"reply should cite tool result: {text!r}"
        )

    async def test_04_image_understanding(self):
        data = b64_resource("林间小憩_小鸟油画.png")
        if data is None:
            self.skipTest(f"resource not found: {RESOURCE_DIR / '林间小憩_小鸟油画.png'}")
        events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL,
                max_output_tokens=2000,  # reasoning consumes budget before text
                input=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "input_image", "image_url": f"data:image/png;base64,{data}"},
                            {"type": "input_text", "text": "这张图里有什么？两句话。"},
                        ],
                    }
                ],
            )
        )
        text = message_text(complete_of(events))
        self.assertGreater(len(text.strip()), 10)

    async def test_05_pdf_input_accepted_but_content_dropped(self):
        # Confirmed limitation: DeepSeek accepts input_file parts at the
        # protocol level (no HTTP error, stream completes normally) but the
        # model never sees the content — the backend substitutes
        # "[Unsupported Document]". This test pins the protocol-level
        # acceptance so a future upgrade to real PDF support is detectable.
        pdf_name = next(
            (n for n in os.listdir(RESOURCE_DIR) if n.lower().endswith(".pdf"))
            if RESOURCE_DIR.is_dir()
            else None,
            None,
        )
        if pdf_name is None:
            self.skipTest("no .pdf resource available")
        data = b64_resource(pdf_name)
        assert data is not None
        events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL,
                max_output_tokens=2000,
                input=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "input_file",
                                "filename": "doc.pdf",
                                "file_data": f"data:application/pdf;base64,{data}",
                            },
                            {"type": "input_text", "text": "文档第一行标题是什么？"},
                        ],
                    }
                ],
            )
        )
        complete = complete_of(events)  # protocol-accepted, completes normally
        self.assertIn("message", [i.get("type") for i in complete.output])

    async def test_06_unsupported_features_silently_accepted(self):
        # Confirmed limitation: additional_tools items, tool_search tool
        # definitions, and previous_response_id stateful mode are NOT
        # implemented by deepseek-flash — but unlike a full OpenAI endpoint
        # they do not error either; the request completes normally with the
        # unsupported parts ignored. This test pins that protocol-level
        # behavior (no fabricated errors, no crashes in our client).
        cases: list[tuple[str, OpenAIResponsesRequest]] = [
            (
                "additional_tools input item",
                OpenAIResponsesRequest(
                    model=LIVE_MODEL,
                    max_output_tokens=300,
                    input=[
                        {"role": "user", "content": "hi"},
                        {
                            "type": "additional_tools",
                            "tools": [
                                {
                                    "type": "function",
                                    "name": "t1",
                                    "parameters": {"type": "object"},
                                }
                            ],
                        },
                    ],
                ),
            ),
            (
                "tool_search tool definition",
                OpenAIResponsesRequest(
                    model=LIVE_MODEL,
                    max_output_tokens=300,
                    input="hi",
                    tools=[{"type": "tool_search", "execution": "server"}],
                ),
            ),
            (
                "previous_response_id stateful mode",
                OpenAIResponsesRequest(
                    model=LIVE_MODEL,
                    max_output_tokens=300,
                    store=True,
                    previous_response_id="resp_fake_nonexistent",
                    input="回复 ok",
                ),
            ),
        ]
        for name, request in cases:
            with self.subTest(case=name):
                events = await collect(request)
                self.assertEqual(
                    [e.type for e in events][-1], "response_complete",
                    f"{name}: expected silent acceptance",
                )

    async def test_07_system_instructions_channels(self):
        # instructions / system role / developer role all take effect.
        for channel, request in [
            (
                "instructions",
                OpenAIResponsesRequest(
                    model=LIVE_MODEL, max_output_tokens=200,
                    instructions="无论用户说什么，只回复数字123，不许有其他任何字。",
                    input="你好",
                ),
            ),
            (
                "system role",
                OpenAIResponsesRequest(
                    model=LIVE_MODEL, max_output_tokens=200,
                    input=[{"role": "system", "content": "只回复数字123。"}, {"role": "user", "content": "你好"}],
                ),
            ),
            (
                "developer role",
                OpenAIResponsesRequest(
                    model=LIVE_MODEL, max_output_tokens=200,
                    input=[{"role": "developer", "content": "只回复数字123。"}, {"role": "user", "content": "你好"}],
                ),
            ),
        ]:
            with self.subTest(channel=channel):
                text = message_text(complete_of(await collect(request)))
                self.assertIn("123", text, f"{channel} directive not followed: {text!r}")

    async def test_08_structured_output_json_schema(self):
        events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, max_output_tokens=400,
                input="张三，28岁",
                text={
                    "format": {
                        "type": "json_schema",
                        "name": "person",
                        "schema": {
                            "type": "object",
                            "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
                            "required": ["name", "age"],
                            "additionalProperties": False,
                        },
                        "strict": True,
                    }
                },
            )
        )
        parsed = json.loads(message_text(complete_of(events)))
        self.assertEqual(parsed.get("name"), "张三")
        self.assertEqual(parsed.get("age"), 28)

    async def test_09_tool_choice_variants(self):
        tools = [
            {
                "type": "function",
                "name": "get_weather",
                "description": "查询城市实时天气",
                "parameters": {"type": "object", "properties": {"city": {"type": "string"}}, "required": ["city"]},
            }
        ]
        # tool_choice="none" forbids calls.
        events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, max_output_tokens=300, tools=tools, tool_choice="none",
                input="北京天气如何？请调用工具查询。",
            )
        )
        self.assertFalse([e for e in events if e.type == "tool_call_start"])

        # Explicit "auto" keeps model-decided calling.
        events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, max_output_tokens=400, tools=tools, tool_choice="auto",
                input="北京天气如何？请调用工具查询。",
            )
        )
        self.assertTrue([e for e in events if e.type == "tool_call_start"])

        # "required" is hard-rejected by thinking mode with 400.
        with self.assertRaises(LLMClientError) as ctx:
            await collect(
                OpenAIResponsesRequest(
                    model=LIVE_MODEL, max_output_tokens=300, tools=tools,
                    tool_choice="required", input="你好",
                )
            )
        self.assertEqual(ctx.exception.status_code, 400)

        # Forcing a specific function is likewise rejected (thinking mode).
        with self.assertRaises(LLMClientError) as ctx:
            await collect(
                OpenAIResponsesRequest(
                    model=LIVE_MODEL, max_output_tokens=300, tools=tools,
                    tool_choice={"type": "function", "name": "get_weather"},
                    input="你好",
                )
            )
        self.assertEqual(ctx.exception.status_code, 400)
        self.assertIn("tool_choice", ctx.exception.raw_body or "")

        # allowed_tools is not in DeepSeek's enum at all: 422 unknown variant.
        # The deserializer error lists the accepted variants:
        # function / web_search / web_search_2025_08_26 / custom.
        with self.assertRaises(LLMClientError) as ctx:
            await collect(
                OpenAIResponsesRequest(
                    model=LIVE_MODEL, max_output_tokens=300, tools=tools,
                    tool_choice={"type": "allowed_tools", "mode": "auto", "tools": []},
                    input="你好",
                )
            )
        self.assertEqual(ctx.exception.status_code, 422)
        self.assertIn("unknown variant", ctx.exception.raw_body or "")

    async def test_10_hard_rejected_variants(self):
        # Custom tools other than apply_patch are rejected with 400.
        with self.assertRaises(LLMClientError) as ctx:
            await collect(
                OpenAIResponsesRequest(
                    model=LIVE_MODEL, max_output_tokens=400,
                    tools=[{"type": "custom", "name": "draw", "description": "画图", "format": {"type": "text"}}],
                    input="请调用draw工具画一只猫",
                )
            )
        self.assertEqual(ctx.exception.status_code, 400)
        self.assertIn("apply_patch", ctx.exception.raw_body or "")

        # input_audio parts are rejected at deserialization with 422.
        data = b64_resource("20261025_221529.m4a")
        if data is None:
            self.skipTest("no audio resource available")
        with self.assertRaises(LLMClientError) as ctx:
            await collect(
                OpenAIResponsesRequest(
                    model=LIVE_MODEL, max_output_tokens=400,
                    input=[{"role": "user", "content": [
                        {"type": "input_audio", "input_audio": {"data": data, "format": "mp4"}},
                        {"type": "input_text", "text": "音频里说了什么？"},
                    ]}],
                )
            )
        self.assertEqual(ctx.exception.status_code, 422)

    async def test_11_truncation_reports_max_output_tokens(self):
        # Tiny budget hits response.incomplete; the SDK surfaces the server's
        # incomplete_details.reason as stop_reason.
        events = await collect(
            OpenAIResponsesRequest(
                model=LIVE_MODEL, max_output_tokens=30, input="写一篇500字的关于长城的作文"
            )
        )
        complete = complete_of(events)
        self.assertEqual(complete.stop_reason, "max_output_tokens")
        self.assertEqual(complete.usage.output_tokens, 30)

    async def test_12_automatic_context_caching(self):
        # DeepSeek's automatic context cache: repeating the same long prefix
        # reports cached_tokens > 0 on the second request. The prefix embeds a
        # per-run UUID so a previous test run can't leave it pre-cached.
        long_prefix = (
            f"这是一段用于测试上下文缓存的稳定前缀（运行标识 {uuid.uuid4().hex}）。请记住以下资料："
            + "缓存测试内容ABC123。" * 120
            + " 资料结束。"
        )
        request = OpenAIResponsesRequest(model=LIVE_MODEL, max_output_tokens=50, input=long_prefix + "\n回复ok")
        first = complete_of(await collect(request))
        second = complete_of(await collect(request))
        self.assertEqual(first.usage.cache_read_input_tokens, 0)
        self.assertGreater(second.usage.cache_read_input_tokens, 0)

    async def test_13_prompt_cache_key_ignored_prefix_cache_only(self):
        # DeepSeek caches by content prefix automatically; prompt_cache_key is
        # silently ignored — the same prefix hits the cache across DIFFERENT
        # keys. Cache-related request fields are protocol-accepted.
        tag = uuid.uuid4().hex
        prefix = f"路由判别前缀{tag}。" + "缓存路由测试XYZ789。" * 120

        async def shot(key: str):
            return complete_of(
                await collect(
                    OpenAIResponsesRequest(
                        model=LIVE_MODEL, max_output_tokens=50,
                        prompt_cache_key=key, input=prefix + "\n回复ok",
                    )
                )
            )

        first = await shot("key-A")  # warm (unique per-run prefix)
        other_key = await shot("key-B")  # same prefix, different cache key
        self.assertEqual(first.usage.cache_read_input_tokens, 0)
        self.assertGreater(other_key.usage.cache_read_input_tokens, 0,
                           "same prefix with a different prompt_cache_key still hits: key is ignored")

        # Cache-control fields are accepted at the protocol level.
        for name, request in [
            ("prompt_cache_options", OpenAIResponsesRequest(
                model=LIVE_MODEL, max_output_tokens=50,
                prompt_cache_options={"mode": "explicit", "ttl": "12h"}, input="回复ok")),
            ("prompt_cache_retention", OpenAIResponsesRequest(
                model=LIVE_MODEL, max_output_tokens=50,
                prompt_cache_retention="24h", input="回复ok")),
            ("prompt_cache_breakpoint", OpenAIResponsesRequest(
                model=LIVE_MODEL, max_output_tokens=50,
                prompt_cache_options={"mode": "explicit"},
                input=[{"role": "user", "content": [
                    {"type": "input_text", "text": "回复ok",
                     "prompt_cache_breakpoint": {"mode": "explicit", "ttl": "12h"}}]}])),
        ]:
            with self.subTest(field=name):
                complete_of(await collect(request))  # accepted, no error


if __name__ == "__main__":
    unittest.main()
