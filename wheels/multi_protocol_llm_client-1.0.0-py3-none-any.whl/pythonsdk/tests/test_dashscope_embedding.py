"""Unit tests for DashScopeSparseEmbeddingClient (no network)."""

from __future__ import annotations

import asyncio
import json
import os
import sys
import unittest
from pathlib import Path
from typing import Any, Optional

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from pythonsdk import (
    ClientConfig,
    DashScopeSparseEmbeddingClient,
    ErrorKind,
    LLMClientError,
)
from pythonsdk.transport import AsyncHttpResponse, AsyncHttpTransport, TransportTimeouts


class MockResponse(AsyncHttpResponse):
    def __init__(self, chunks: list[bytes], status: int = 200) -> None:
        self._chunks = chunks
        self._status = status
        self.closed = False

    @property
    def status(self) -> int:
        return self._status

    @property
    def status_text(self) -> str:
        return "OK" if self._status < 400 else "Error"

    @property
    def headers(self) -> dict[str, str]:
        return {"Content-Type": "application/json"}

    async def iter_bytes(self, cancel_token=None, idle_timeout_ms: int = 120000):
        for chunk in self._chunks:
            yield chunk

    async def read_all(self, cancel_token=None, timeout_ms: int = 30000) -> bytes:
        return b"".join(self._chunks)

    async def close(self) -> None:
        self.closed = True


class MockTransport(AsyncHttpTransport):
    def __init__(self, responses: list[Any]) -> None:
        self.responses = list(responses)
        self.requests: list[dict[str, Any]] = []

    async def send_stream(
        self,
        method: str,
        url: str,
        headers,
        body: bytes,
        timeouts: TransportTimeouts,
        cancel_token=None,
    ) -> AsyncHttpResponse:
        self.requests.append(
            {"method": method, "url": url, "headers": dict(headers), "body": body}
        )
        item = self.responses.pop(0)
        if isinstance(item, Exception):
            raise item
        return item


def json_response(payload: dict[str, Any], status: int = 200) -> MockResponse:
    return MockResponse([json.dumps(payload).encode("utf-8")], status=status)


def sparse_payload(vectors: list[list[tuple[int, float]]], *, reverse: bool = False) -> dict:
    embeddings = [
        {
            "text_index": idx,
            "sparse_embedding": [
                {"index": i, "value": v, "token": f"t{i}"} for i, v in entries
            ],
        }
        for idx, entries in enumerate(vectors)
    ]
    if reverse:
        embeddings.reverse()
    return {
        "output": {"embeddings": embeddings},
        "usage": {"total_tokens": 12},
        "request_id": "req-1",
    }


def make_client(transport: MockTransport, base_url: Optional[str] = None) -> DashScopeSparseEmbeddingClient:
    return DashScopeSparseEmbeddingClient(
        ClientConfig(api_key="sk-test", base_url=base_url),
        model="text-embedding-v4",
        transport=transport,
    )


class DashScopeSparseEmbeddingClientTest(unittest.TestCase):
    def test_request_shape_and_vector_output(self) -> None:
        transport = MockTransport([json_response(sparse_payload([[(7149, 0.829)], [(11, 0.5)]]))])
        client = make_client(transport)

        vectors = asyncio.run(client.embed_texts(["alpha", "beta"]))

        self.assertEqual(
            vectors,
            [
                {"indices": [7149], "values": [0.829]},
                {"indices": [11], "values": [0.5]},
            ],
        )
        request = transport.requests[0]
        self.assertEqual(request["method"], "POST")
        self.assertTrue(request["url"].endswith("/text-embedding/text-embedding"))
        self.assertEqual(request["headers"]["Authorization"], "Bearer sk-test")
        body = json.loads(request["body"])
        self.assertEqual(body["model"], "text-embedding-v4")
        self.assertEqual(body["input"], {"texts": ["alpha", "beta"]})
        self.assertEqual(
            body["parameters"],
            {"text_type": "document", "dimension": 2048, "output_type": "sparse"},
        )

    def test_full_endpoint_base_url_is_not_duplicated(self) -> None:
        transport = MockTransport([json_response(sparse_payload([[(1, 0.1)]]))])
        full = (
            "https://dashscope.aliyuncs.com/api/v1/services/embeddings/"
            "text-embedding/text-embedding"
        )
        client = make_client(transport, base_url=full)

        asyncio.run(client.embed_texts(["x"]))

        self.assertEqual(transport.requests[0]["url"], full)

    def test_reorders_by_text_index(self) -> None:
        transport = MockTransport(
            [json_response(sparse_payload([[(1, 0.1)], [(2, 0.2)]], reverse=True))]
        )
        client = make_client(transport)

        vectors = asyncio.run(client.embed_texts(["first", "second"]))

        self.assertEqual([v["indices"] for v in vectors], [[1], [2]])

    def test_query_text_type(self) -> None:
        transport = MockTransport([json_response(sparse_payload([[(3, 0.3)]]))])
        client = make_client(transport)

        asyncio.run(client.embed_query(["q"]))

        body = json.loads(transport.requests[0]["body"])
        self.assertEqual(body["parameters"]["text_type"], "query")

    def test_api_level_code_raises_bad_request(self) -> None:
        transport = MockTransport(
            [json_response({"code": "InvalidParameter", "message": "bad model"})]
        )
        client = make_client(transport)

        with self.assertRaises(LLMClientError) as ctx:
            asyncio.run(client.embed_texts(["x"]))
        self.assertEqual(ctx.exception.kind, ErrorKind.BAD_REQUEST)
        self.assertFalse(ctx.exception.is_retryable)
        self.assertEqual(ctx.exception.provider_error_code, "InvalidParameter")

    def test_embedding_count_mismatch_raises_protocol_error(self) -> None:
        transport = MockTransport([json_response(sparse_payload([[(1, 0.1)]]))])
        client = make_client(transport)

        with self.assertRaises(LLMClientError) as ctx:
            asyncio.run(client.embed_texts(["a", "b"]))
        self.assertEqual(ctx.exception.kind, ErrorKind.PROTOCOL_ERROR)

    def test_missing_sparse_embedding_raises_protocol_error(self) -> None:
        transport = MockTransport(
            [json_response({"output": {"embeddings": [{"text_index": 0, "embedding": [0.1]}]}})]
        )
        client = make_client(transport)

        with self.assertRaises(LLMClientError) as ctx:
            asyncio.run(client.embed_texts(["x"]))
        self.assertEqual(ctx.exception.kind, ErrorKind.PROTOCOL_ERROR)

    def test_local_validation(self) -> None:
        client = make_client(MockTransport([]))

        cases = [
            ([], "empty"),
            (["x"] * 11, "batch"),
            (["x", ""], "empty string"),
            (["x"], "bad dimension"),
        ]
        with self.assertRaises(LLMClientError):
            asyncio.run(client.embed_texts([]))
        with self.assertRaises(LLMClientError):
            asyncio.run(client.embed_texts(["x"] * 11))
        with self.assertRaises(LLMClientError):
            asyncio.run(client.embed_texts(["x", ""]))
        with self.assertRaises(LLMClientError):
            asyncio.run(client.embed_texts(["x"], dimension=0))
        with self.assertRaises(LLMClientError):
            asyncio.run(client.embed_texts(["x"], text_type="doc"))  # type: ignore[arg-type]
        self.assertEqual(len(cases), 4)
        self.assertEqual(client.max_batch_size, 10)


@unittest.skipUnless(os.environ.get("DASHSCOPE_API_KEY"), "DASHSCOPE_API_KEY not set")
class DashScopeSparseEmbeddingLiveTest(unittest.TestCase):
    def test_live_sparse_embedding(self) -> None:
        client = DashScopeSparseEmbeddingClient(
            ClientConfig(api_key=os.environ["DASHSCOPE_API_KEY"])
        )
        vectors = asyncio.run(client.embed_texts(["稀疏向量测试文本"]))
        self.assertEqual(len(vectors), 1)
        self.assertGreater(len(vectors[0]["indices"]), 0)
        self.assertEqual(len(vectors[0]["values"]), len(vectors[0]["indices"]))


if __name__ == "__main__":
    unittest.main()
