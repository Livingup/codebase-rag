from __future__ import annotations

import json
from dataclasses import dataclass
from enum import Enum
from typing import Any, Mapping, Optional


class ErrorKind(str, Enum):
    """Standardized error classification across all LLM protocol clients."""

    ABORTED = "ABORTED"
    RATE_LIMIT = "RATE_LIMIT"
    OVERLOADED = "OVERLOADED"
    SERVER_ERROR = "SERVER_ERROR"
    NETWORK_ERROR = "NETWORK_ERROR"
    AUTH_ERROR = "AUTH_ERROR"
    BAD_REQUEST = "BAD_REQUEST"
    PROTOCOL_ERROR = "PROTOCOL_ERROR"


RETRYABLE_HTTP_STATUS_CODES: frozenset[int] = frozenset(
    {408, 409, 429, 500, 502, 503, 504, 529}
)


@dataclass(frozen=True)
class LLMClientError(Exception):
    """
    Structured, immutable exception raised by all protocol clients on terminal failure
    or active cancellation.
    """

    kind: ErrorKind
    message: str
    is_retryable: bool
    attempt: int
    status_code: Optional[int] = None
    provider_error_code: Optional[str] = None
    raw_body: Optional[str] = None
    retry_after_header: Optional[str] = None
    cause: Optional[BaseException] = None

    def __str__(self) -> str:
        status_part = f" status={self.status_code}" if self.status_code is not None else ""
        code_part = (
            f" provider_code={self.provider_error_code}"
            if self.provider_error_code
            else ""
        )
        return (
            f"[{self.kind.value}]{status_part}{code_part} "
            f"(attempt={self.attempt}, retryable={self.is_retryable}): {self.message}"
        )


def classify_http_error(
    status_code: int,
    headers: Mapping[str, str],
    raw_body: str,
    attempt: int,
) -> LLMClientError:
    """
    Classifies a non-2xx HTTP response into a structured LLMClientError.
    Preserves the exact raw_body returned by the LLM server.
    """
    lower_headers = {k.lower(): v for k, v in headers.items()}
    retry_after_ms_hdr = lower_headers.get("retry-after-ms")
    if retry_after_ms_hdr is not None:
        raw_ms = retry_after_ms_hdr.strip()
        retry_after: Optional[str] = (
            raw_ms if raw_ms.lower().endswith("ms") else f"{raw_ms}ms"
        )
    else:
        retry_after = lower_headers.get("retry-after")
        if retry_after is None:
            # FR-RETRY-04: any `x-ratelimit-reset-*` header (e.g. OpenAI's
            # -requests / -tokens variants) may advertise the reset time.
            for hk, hv in lower_headers.items():
                if hk.startswith("x-ratelimit-reset-"):
                    retry_after = hv
                    break

    provider_code: Optional[str] = None
    extracted_msg: Optional[str] = None

    if raw_body:
        try:
            parsed: Any = json.loads(raw_body)
            if isinstance(parsed, dict):
                err_obj = parsed.get("error")
                if isinstance(err_obj, dict):
                    provider_code = (
                        err_obj.get("type")
                        or err_obj.get("code")
                        or err_obj.get("status")
                    )
                    extracted_msg = err_obj.get("message")
                elif isinstance(err_obj, str):
                    extracted_msg = err_obj
        except Exception:
            pass

    message = extracted_msg or f"HTTP {status_code} error from LLM endpoint"

    if status_code == 429:
        kind = ErrorKind.RATE_LIMIT
        is_retryable = True
    elif status_code == 529:
        kind = ErrorKind.OVERLOADED
        is_retryable = True
    elif status_code in (401, 403):
        kind = ErrorKind.AUTH_ERROR
        is_retryable = False
    elif status_code in (400, 404, 413, 422):
        kind = ErrorKind.BAD_REQUEST
        is_retryable = False
    elif status_code in RETRYABLE_HTTP_STATUS_CODES:
        kind = ErrorKind.SERVER_ERROR
        is_retryable = True
    elif 500 <= status_code < 600:
        # FR-RETRY-02: only the listed transient 5xx codes (500/502/503/504)
        # are retryable; other 5xx (501, 505, ...) are server errors but must
        # not trigger automatic retries.
        kind = ErrorKind.SERVER_ERROR
        is_retryable = False
    else:
        kind = ErrorKind.BAD_REQUEST
        is_retryable = False

    return LLMClientError(
        kind=kind,
        message=message,
        is_retryable=is_retryable,
        attempt=attempt,
        status_code=status_code,
        provider_error_code=str(provider_code) if provider_code is not None else None,
        raw_body=raw_body,
        retry_after_header=retry_after,
    )


def classify_stream_or_network_error(
    exc: BaseException,
    attempt: int,
    is_cancelled: bool = False,
) -> LLMClientError:
    """Normalizes any runtime, transport, or cancellation exception into LLMClientError."""
    if is_cancelled:
        return LLMClientError(
            kind=ErrorKind.ABORTED,
            message="Request was actively cancelled by upstream caller",
            is_retryable=False,
            attempt=attempt,
            cause=exc,
        )

    if isinstance(exc, LLMClientError):
        return exc

    # Malformed wire data (e.g. an invalid chunked size line, a non-numeric
    # Content-Length) is a protocol violation, not a transient network fault:
    # retrying would just burn the retry budget on the same broken response.
    if isinstance(exc, (ValueError, UnicodeError)):
        return LLMClientError(
            kind=ErrorKind.PROTOCOL_ERROR,
            message=f"Malformed HTTP/SSE data from server: {exc}",
            is_retryable=False,
            attempt=attempt,
            cause=exc,
        )

    return LLMClientError(
        kind=ErrorKind.NETWORK_ERROR,
        message=f"Network or stream transport error: {exc}",
        is_retryable=True,
        attempt=attempt,
        cause=exc,
    )
