from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field
from typing import Any, Literal, Mapping, Optional, Sequence, TypedDict, Union
from urllib.parse import quote

from .base_client import (
    BaseProtocolClient,
    ClientConfig,
    ProtocolStreamStateMachine,
    RequestOptions,
    to_serializable_dict,
)
from .errors import ErrorKind, LLMClientError
from .events import (
    LLMStreamEvent,
    AudioStartEvent,
    AudioDeltaEvent,
    AudioStopEvent,
    ResponseCompleteEvent,
    ResponseStartEvent,
    ServerToolDeltaEvent,
    ServerToolStartEvent,
    ServerToolStopEvent,
    TextDeltaEvent,
    TextStartEvent,
    TextStopEvent,
    ThinkingDeltaEvent,
    ThinkingStartEvent,
    ThinkingStopEvent,
    TokenUsage,
    ToolCallDeltaEvent,
    ToolCallStartEvent,
    ToolCallStopEvent,
)
from .inspector import ProviderName
from .retry import BackoffStrategy
from .sse import SseEventFrame
from .transport import AsyncHttpTransport

DEFAULT_GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta"

# ============================================================================
# 1. Google Gemini Native camelCase Type Definitions (docs/GEMINI_STREAM_GENERATE_CONTENT_API.md Section 5)
# ============================================================================

GeminiRole = Literal["user", "model"]

GeminiSchemaType = Literal[
    "TYPE_UNSPECIFIED",
    "STRING",
    "NUMBER",
    "INTEGER",
    "BOOLEAN",
    "ARRAY",
    "OBJECT",
    "NULL",
]

GeminiMediaResolutionLevel = Literal[
    "MEDIA_RESOLUTION_UNSPECIFIED",
    "MEDIA_RESOLUTION_LOW",
    "MEDIA_RESOLUTION_MEDIUM",
    "MEDIA_RESOLUTION_HIGH",
    "MEDIA_RESOLUTION_ULTRA_HIGH",
]


class GeminiSchema(TypedDict, total=False):
    type: GeminiSchemaType
    format: str
    title: str
    description: str
    nullable: bool
    enum: list[str]
    maxItems: int
    minItems: int
    properties: dict[str, Any]
    required: list[str]
    propertyOrdering: list[str]
    items: dict[str, Any]
    anyOf: list[dict[str, Any]]


class GeminiInlineData(TypedDict):
    mimeType: str
    data: str


class GeminiFileData(TypedDict, total=False):
    mimeType: str
    fileUri: str


class GeminiFunctionCall(TypedDict, total=False):
    id: str
    name: str
    args: dict[str, Any]


class GeminiMediaResolution(TypedDict):
    level: GeminiMediaResolutionLevel


class GeminiFunctionResponsePart(TypedDict, total=False):
    inlineData: GeminiInlineData
    fileData: GeminiFileData
    mediaResolution: GeminiMediaResolution


class GeminiFunctionResponse(TypedDict, total=False):
    id: str
    name: str
    response: dict[str, Any]
    parts: list[GeminiFunctionResponsePart]
    willContinue: bool
    scheduling: Literal[
        "SCHEDULING_UNSPECIFIED", "SILENT", "WHEN_IDLE", "INTERRUPT"
    ]


class GeminiExecutableCode(TypedDict):
    language: Literal["PYTHON", "LANGUAGE_UNSPECIFIED"]
    code: str


class GeminiCodeExecutionResult(TypedDict, total=False):
    outcome: Literal[
        "OUTCOME_OK", "OUTCOME_FAILED", "OUTCOME_DEADLINE_EXCEEDED"
    ]
    output: str


class GeminiVideoMetadata(TypedDict, total=False):
    startOffset: str
    endOffset: str
    fps: float


class GeminiSpeechMetadata(TypedDict, total=False):
    speaker: str
    style: str


class GeminiAudioTranscription(TypedDict, total=False):
    """Carrier for transcription model output (`gemini-*-transcribe`).
    Observed on the live endpoint (2026-10) but absent from the original spec
    doc; documented in GEMINI_STREAM_GENERATE_CONTENT_API.md Section 2.2."""

    text: str


class GeminiPart(TypedDict, total=False):
    text: str
    inlineData: GeminiInlineData
    fileData: GeminiFileData
    functionCall: GeminiFunctionCall
    functionResponse: GeminiFunctionResponse
    executableCode: GeminiExecutableCode
    codeExecutionResult: GeminiCodeExecutionResult
    thought: bool
    thoughtSignature: str
    mediaResolution: GeminiMediaResolution
    videoMetadata: GeminiVideoMetadata
    speechMetadata: GeminiSpeechMetadata
    audioTranscription: GeminiAudioTranscription


class GeminiContent(TypedDict, total=False):
    role: GeminiRole
    parts: list[GeminiPart]


class GeminiFunctionDeclaration(TypedDict, total=False):
    name: str
    description: str
    parameters: Union[GeminiSchema, dict[str, Any]]
    parametersJsonSchema: dict[str, Any]
    response: Union[GeminiSchema, dict[str, Any]]
    responseJsonSchema: dict[str, Any]
    behavior: Literal["UNSPECIFIED", "BLOCKING", "NON_BLOCKING"]


class GeminiGoogleSearchTimeRangeFilter(TypedDict, total=False):
    startTime: str
    endTime: str


class GeminiGoogleSearchConfig(TypedDict, total=False):
    searchTypes: dict[str, dict[str, Any]]
    timeRangeFilter: GeminiGoogleSearchTimeRangeFilter


class GeminiGoogleMapsConfig(TypedDict, total=False):
    enableWidget: bool


class GeminiTool(TypedDict, total=False):
    functionDeclarations: list[Union[GeminiFunctionDeclaration, dict[str, Any]]]
    googleSearch: Union[GeminiGoogleSearchConfig, dict[str, Any]]
    googleMaps: Union[GeminiGoogleMapsConfig, dict[str, Any]]
    urlContext: dict[str, Any]
    codeExecution: dict[str, Any]


class GeminiFunctionCallingConfig(TypedDict, total=False):
    mode: Literal["AUTO", "ANY", "NONE", "VALIDATED"]
    allowedFunctionNames: list[str]


class GeminiRetrievalConfig(TypedDict, total=False):
    latLng: dict[str, float]
    languageCode: str


class GeminiToolConfig(TypedDict, total=False):
    functionCallingConfig: GeminiFunctionCallingConfig
    includeServerSideToolInvocations: bool
    retrievalConfig: GeminiRetrievalConfig


class GeminiThinkingConfig(TypedDict, total=False):
    includeThoughts: bool
    thinkingLevel: Literal["MINIMAL", "LOW", "MEDIUM", "HIGH"]
    thinkingBudget: int


class GeminiImageConfig(TypedDict, total=False):
    aspectRatio: Literal[
        "1:1", "3:4", "4:3", "9:16", "16:9", "1:4", "1:8", "4:1", "8:1"
    ]
    imageSize: Literal["1K", "2K", "4K"]


class GeminiSpeechConfig(TypedDict, total=False):
    voiceConfig: dict[str, Any]
    multiSpeakerVoiceConfig: dict[str, Any]


class GeminiGenerationConfig(TypedDict, total=False):
    stopSequences: list[str]
    responseMimeType: Union[
        Literal["text/plain", "application/json", "text/x.enum"], str
    ]
    responseSchema: Union[GeminiSchema, dict[str, Any]]
    responseJsonSchema: dict[str, Any]
    responseModalities: list[Literal["TEXT", "IMAGE", "AUDIO"]]
    candidateCount: int
    maxOutputTokens: int
    temperature: float
    topP: float
    topK: int
    seed: int
    presencePenalty: float
    frequencyPenalty: float
    responseLogprobs: bool
    logprobs: int
    thinkingConfig: GeminiThinkingConfig
    imageConfig: GeminiImageConfig
    speechConfig: GeminiSpeechConfig
    mediaResolution: GeminiMediaResolutionLevel


class GeminiSafetySetting(TypedDict):
    category: Literal[
        "HARM_CATEGORY_HARASSMENT",
        "HARM_CATEGORY_HATE_SPEECH",
        "HARM_CATEGORY_SEXUALLY_EXPLICIT",
        "HARM_CATEGORY_DANGEROUS_CONTENT",
        "HARM_CATEGORY_CIVIC_INTEGRITY",
    ]
    threshold: Literal[
        "BLOCK_NONE",
        "BLOCK_ONLY_HIGH",
        "BLOCK_MEDIUM_AND_ABOVE",
        "BLOCK_LOW_AND_ABOVE",
        "OFF",
    ]


@dataclass
class GeminiStreamRequest:
    """
    Complete, non-simplified native camelCase request payload for Google Gemini
    `POST /v1beta/models/{model}:streamGenerateContent?alt=sse` (FR-PROTO-03 & docs/GEMINI_STREAM_GENERATE_CONTENT_API.md).
    """

    model: str
    contents: Sequence[Union[GeminiContent, dict[str, Any]]]
    systemInstruction: Optional[Union[GeminiContent, dict[str, Any]]] = None
    tools: Optional[Sequence[Union[GeminiTool, dict[str, Any]]]] = None
    toolConfig: Optional[Union[GeminiToolConfig, dict[str, Any]]] = None
    safetySettings: Optional[Sequence[Union[GeminiSafetySetting, dict[str, Any]]]] = None
    generationConfig: Optional[Union[GeminiGenerationConfig, dict[str, Any]]] = None
    cachedContent: Optional[str] = None
    labels: Optional[Mapping[str, str]] = None
    extra_fields: Mapping[str, Any] = field(default_factory=dict)


# ============================================================================
# 2. Google Gemini Response & SSE Chunk Types (docs/GEMINI_STREAM_GENERATE_CONTENT_API.md Section 5)
# ============================================================================

GeminiFinishReason = Literal[
    "FINISH_REASON_UNSPECIFIED",
    "STOP",
    "MAX_TOKENS",
    "SAFETY",
    "RECITATION",
    "OTHER",
    "BLOCKLIST",
    "PROHIBITED_CONTENT",
    "SPII",
    "MALFORMED_FUNCTION_CALL",
    "IMAGE_SAFETY",
]


class GeminiSafetyRating(TypedDict, total=False):
    category: str
    probability: str
    blocked: bool
    severity: str


class GeminiGroundingMetadata(TypedDict, total=False):
    webSearchQueries: list[str]
    searchEntryPoint: dict[str, str]
    groundingChunks: list[dict[str, Any]]
    groundingSupports: list[dict[str, Any]]


class GeminiUrlContextMetadata(TypedDict, total=False):
    urlMetadata: list[dict[str, str]]


class GeminiCandidate(TypedDict, total=False):
    content: GeminiContent
    finishReason: Union[GeminiFinishReason, str]
    index: int
    safetyRatings: list[GeminiSafetyRating]
    groundingMetadata: GeminiGroundingMetadata
    urlContextMetadata: GeminiUrlContextMetadata
    citationMetadata: dict[str, Any]
    avgLogprobs: float
    logprobsResult: dict[str, Any]


class GeminiModalityTokenCount(TypedDict):
    modality: str
    tokenCount: int


class GeminiUsageMetadata(TypedDict, total=False):
    promptTokenCount: int
    cachedContentTokenCount: int
    candidatesTokenCount: int
    thoughtsTokenCount: int
    toolUsePromptTokenCount: int
    totalTokenCount: int
    promptTokensDetails: list[GeminiModalityTokenCount]
    candidatesTokensDetails: list[GeminiModalityTokenCount]
    cacheTokensDetails: list[GeminiModalityTokenCount]
    toolUsePromptTokensDetails: list[GeminiModalityTokenCount]


class GeminiPromptFeedback(TypedDict, total=False):
    blockReason: str
    safetyRatings: list[GeminiSafetyRating]


class GeminiGenerateContentResponse(TypedDict, total=False):
    candidates: list[GeminiCandidate]
    promptFeedback: GeminiPromptFeedback
    usageMetadata: GeminiUsageMetadata
    modelVersion: str
    responseId: str


class GeminiStreamStateMachine(
    ProtocolStreamStateMachine[GeminiPart, GeminiContent]
):
    """
    State Pattern implementation with boundary synthesis for Google Gemini SSE streams
    (Section 5.4.3).
    Tracks `current_open_stage` ("NONE" | "THINKING" | "TEXT") and synthesizes
    `thinking_start/delta/stop` and `text_start/delta/stop` events while strictly preserving
    `thoughtSignature`, `groundingMetadata`, `urlContextMetadata`, `safetyRatings`, and `promptFeedback`.
    """

    def __init__(self, requested_model: str) -> None:
        self._requested_model = requested_model
        self._response_id: str = ""
        self._model_version: str = requested_model
        self._emitted_response_start: bool = False
        self._emitted_complete: bool = False

        self._current_open_stage: Literal["NONE", "THINKING", "TEXT"] = "NONE"
        self._block_index: int = 0
        self._thinking_buffer: list[str] = []
        self._thinking_signature: Optional[str] = None
        self._text_buffer: list[str] = []
        self._text_signature: Optional[str] = None

        # TTS audio stage (FR-STATE-09): Gemini TTS models stream dozens of
        # `inlineData` audio parts with no explicit start/stop markers.
        self._audio_open: bool = False
        self._audio_mimeType: Optional[str] = None
        self._audio_base64_parts: list[str] = []
        self._audio_block_index: int = 0

        self._raw_parts: list[GeminiPart] = []
        # Server-reported finish reason. None until the server actually sends
        # one — the SDK never fabricates a reason it was not told (FR-STATE-08).
        self._finish_reason: Optional[str] = None
        self._grounding_metadata: Optional[dict[str, Any]] = None
        self._url_context_metadata: Optional[dict[str, Any]] = None
        self._safety_ratings: Optional[list[dict[str, Any]]] = None
        self._citation_metadata: Optional[dict[str, Any]] = None
        self._logprobs_result: Optional[dict[str, Any]] = None
        self._prompt_feedback: Optional[dict[str, Any]] = None
        self._usage_meta_dict: dict[str, Any] = {}

    def process_frame(
        self,
        frame: SseEventFrame,
        trace_id: str,
        attempt: int,
    ) -> list[LLMStreamEvent[GeminiPart, GeminiContent]]:
        raw_data = frame.data.strip()
        if not raw_data or raw_data == "[DONE]":
            return []

        try:
            payload: dict[str, Any] = json.loads(raw_data)
        except Exception as exc:
            raise LLMClientError(
                kind=ErrorKind.PROTOCOL_ERROR,
                message=f"Failed to parse Gemini SSE JSON frame: {exc}",
                is_retryable=False,
                attempt=attempt,
                raw_body=raw_data,
                cause=exc,
            ) from exc

        if "error" in payload and isinstance(payload["error"], Mapping):
            err_obj = payload["error"]
            status_str = str(err_obj.get("status", "UNKNOWN"))
            code_num = err_obj.get("code")
            msg = str(err_obj.get("message", "Gemini SSE error"))
            is_retryable = status_str in (
                "RESOURCE_EXHAUSTED",
                "UNAVAILABLE",
                "INTERNAL",
            )
            kind = (
                ErrorKind.RATE_LIMIT
                if status_str == "RESOURCE_EXHAUSTED"
                else ErrorKind.SERVER_ERROR
                if is_retryable
                else ErrorKind.BAD_REQUEST
            )
            raise LLMClientError(
                kind=kind,
                message=msg,
                is_retryable=is_retryable,
                attempt=attempt,
                status_code=int(code_num) if isinstance(code_num, int) else None,
                provider_error_code=status_str,
                raw_body=raw_data,
            )

        events: list[LLMStreamEvent[GeminiPart, GeminiContent]] = []

        if payload.get("responseId"):
            self._response_id = str(payload["responseId"])
        if payload.get("modelVersion"):
            self._model_version = str(payload["modelVersion"])

        if not self._emitted_response_start:
            self._emitted_response_start = True
            events.append(
                ResponseStartEvent(
                    trace_id=trace_id,
                    attempt=attempt,
                    response_id=self._response_id or f"gemini_{trace_id[:8]}",
                    model=self._model_version,
                )
            )

        if isinstance(payload.get("promptFeedback"), Mapping):
            self._prompt_feedback = dict(payload["promptFeedback"])
            block_reason = self._prompt_feedback.get("blockReason")
            if block_reason and block_reason != "BLOCK_REASON_UNSPECIFIED":
                self._finish_reason = str(block_reason)

        if isinstance(payload.get("usageMetadata"), Mapping):
            self._usage_meta_dict.update(payload["usageMetadata"])

        candidates = payload.get("candidates")
        if not isinstance(candidates, list) or not candidates:
            return events

        cand0 = candidates[0]
        if not isinstance(cand0, Mapping):
            return events

        if cand0.get("finishReason"):
            self._finish_reason = str(cand0["finishReason"])
        if isinstance(cand0.get("groundingMetadata"), Mapping):
            self._grounding_metadata = dict(cand0["groundingMetadata"])
        if isinstance(cand0.get("urlContextMetadata"), Mapping):
            self._url_context_metadata = dict(cand0["urlContextMetadata"])
        if isinstance(cand0.get("safetyRatings"), list):
            self._safety_ratings = list(cand0["safetyRatings"])
        if isinstance(cand0.get("citationMetadata"), Mapping):
            self._citation_metadata = dict(cand0["citationMetadata"])
        if isinstance(cand0.get("logprobsResult"), Mapping):
            self._logprobs_result = dict(cand0["logprobsResult"])

        content_obj = cand0.get("content")
        if isinstance(content_obj, Mapping):
            parts = content_obj.get("parts")
            if isinstance(parts, list):
                for part in parts:
                    if isinstance(part, Mapping):
                        events.extend(self._handle_part(dict(part)))  # type: ignore[arg-type]

        return events

    def finish_stream(
        self,
        trace_id: str,
        attempt: int,
    ) -> list[LLMStreamEvent[GeminiPart, GeminiContent]]:
        if self._emitted_complete:
            return []
        self._emitted_complete = True

        events: list[LLMStreamEvent[GeminiPart, GeminiContent]] = []
        events.extend(self._close_current_open_stage())
        events.extend(self._close_audio_stage())

        model_content: GeminiContent = {
            "role": "model",
            "parts": list(self._raw_parts),
        }
        events.append(
            ResponseCompleteEvent(
                response_id=self._response_id or f"gemini_{trace_id[:8]}",
                stop_reason=self._finish_reason,
                usage=self._build_token_usage(),
                output=model_content,
            )
        )
        return events

    def _handle_part(
        self, part: GeminiPart
    ) -> list[LLMStreamEvent[GeminiPart, GeminiContent]]:
        events: list[LLMStreamEvent[GeminiPart, GeminiContent]] = []
        is_thought = bool(part.get("thought") is True)
        sig = part.get("thoughtSignature")

        # FR-STATE-09: streamed audio parts (TTS voice synthesis) carry
        # `inlineData` with an audio/* mimeType.
        inline_obj = part.get("inlineData")
        is_audio_part = (
            isinstance(inline_obj, Mapping)
            and str(inline_obj.get("mimeType", "")).startswith("audio/")
            and isinstance(inline_obj.get("data"), str)
        )
        # Boundary rule: any non-audio content closes an open audio stage.
        if self._audio_open and not is_audio_part:
            events.extend(self._close_audio_stage())

        # Case 1: Thinking part (`thought: True`)
        if is_thought:
            if self._current_open_stage == "TEXT":
                events.extend(self._close_current_open_stage())
            if self._current_open_stage == "NONE":
                self._current_open_stage = "THINKING"
                self._thinking_buffer = []
                self._thinking_signature = None
                events.append(ThinkingStartEvent(block_index=self._block_index))

            text_val = str(part.get("text", ""))
            if text_val:
                self._thinking_buffer.append(text_val)
                events.append(
                    ThinkingDeltaEvent(block_index=self._block_index, delta=text_val)
                )
            if isinstance(sig, str) and sig:
                self._thinking_signature = sig

            self._append_or_merge_raw_part(part)
            return events

        # Case 2: Client Function Call part (`functionCall`)
        if "functionCall" in part and isinstance(part["functionCall"], Mapping):
            events.extend(self._close_current_open_stage())
            fc = part["functionCall"]
            fn_name = str(fc.get("name", ""))
            call_id = str(fc.get("id") or f"gemini_call_{self._block_index}_{fn_name}")
            args_obj = fc.get("args")
            if not isinstance(args_obj, Mapping):
                # Missing args or an explicit null must serialize as `{}`,
                # never as the JSON literal string "null".
                args_obj = {}
            args_json = json.dumps(args_obj, ensure_ascii=False)

            events.append(
                ToolCallStartEvent(
                    block_index=self._block_index,
                    call_id=call_id,
                    name=fn_name,
                    tool_type="function",
                )
            )
            events.append(
                ToolCallDeltaEvent(
                    block_index=self._block_index,
                    call_id=call_id,
                    arguments_delta=args_json,
                )
            )
            raw_copy = copy.deepcopy(part)
            events.append(
                ToolCallStopEvent(
                    block_index=self._block_index,
                    call_id=call_id,
                    name=fn_name,
                    arguments_raw=args_json,
                    raw_item=raw_copy,
                )
            )
            self._block_index += 1
            self._raw_parts.append(raw_copy)
            return events

        # Case 3: Server-Side Code Execution (`executableCode` or `codeExecutionResult`)
        if "executableCode" in part or "codeExecutionResult" in part:
            events.extend(self._close_current_open_stage())
            tool_name = (
                "executableCode"
                if "executableCode" in part
                else "codeExecutionResult"
            )
            item_id = f"gemini_srv_{self._block_index}"
            raw_copy = copy.deepcopy(part)
            events.append(
                ServerToolStartEvent(
                    block_index=self._block_index,
                    item_id=item_id,
                    tool_name=tool_name,
                )
            )
            events.append(
                ServerToolDeltaEvent(
                    block_index=self._block_index,
                    item_id=item_id,
                    delta_type=tool_name,
                    delta_payload=raw_copy.get(tool_name),
                )
            )
            events.append(
                ServerToolStopEvent(
                    block_index=self._block_index,
                    item_id=item_id,
                    tool_name=tool_name,
                    raw_item=raw_copy,
                )
            )
            self._block_index += 1
            self._raw_parts.append(raw_copy)
            return events

        # Case 3.5: Audio transcription part. Transcription models
        # (gemini-*-transcribe) return `audioTranscription: {text}` instead of
        # plain `text` parts. Route the text through the unified TEXT
        # lifecycle (FR-PROTO-03.3 boundary synthesis) while keeping the raw
        # part verbatim in rawParts for faithful replay.
        transcription_obj = part.get("audioTranscription")
        if isinstance(transcription_obj, Mapping):
            if self._current_open_stage == "THINKING":
                events.extend(self._close_current_open_stage())
            tr_text = transcription_obj.get("text")
            tr_text = str(tr_text) if tr_text is not None else ""
            if tr_text:
                if self._current_open_stage == "NONE":
                    self._current_open_stage = "TEXT"
                    self._text_buffer = []
                    self._text_signature = None
                    events.append(TextStartEvent(block_index=self._block_index))
                self._text_buffer.append(tr_text)
                events.append(
                    TextDeltaEvent(block_index=self._block_index, delta=tr_text)
                )
                if isinstance(sig, str) and sig:
                    self._text_signature = sig
            self._raw_parts.append(copy.deepcopy(part))
            return events

        # Case 4: Ordinary Text part (`text` present and `thought != True`)
        if "text" in part and part.get("text") is not None:
            text_val = str(part.get("text", ""))
            if (
                text_val == ""
                and isinstance(sig, str)
                and sig
                and self._current_open_stage == "THINKING"
            ):
                # Boundary signature: Gemini attaches the thought signature of
                # the finished thinking phase to an empty text part. Attach it
                # to the pending thought part in rawParts instead of keeping a
                # separate `{"text": ""}` part — replaying empty text parts
                # back to the server risks a 400 and would separate the
                # signature from the thinking block it belongs to.
                self._thinking_signature = sig
                if self._raw_parts and self._raw_parts[-1].get("thought") is True:
                    self._raw_parts[-1]["thoughtSignature"] = sig
                else:  # defensive: no thought part tracked yet
                    self._append_or_merge_raw_part(part)
                events.extend(self._close_current_open_stage())
                return events

            if self._current_open_stage == "THINKING":
                events.extend(self._close_current_open_stage())

            if text_val == "" and self._current_open_stage == "NONE":
                # Servers emit trailing `{"text": ""}` terminator parts (seen
                # with transcription models). They carry no content: keep the
                # part in rawParts for faithful replay, but never open a
                # degenerate empty TEXT block for the UI.
                self._append_or_merge_raw_part(part)
                return events

            if self._current_open_stage == "NONE":
                self._current_open_stage = "TEXT"
                self._text_buffer = []
                self._text_signature = None
                events.append(TextStartEvent(block_index=self._block_index))

            if text_val:
                self._text_buffer.append(text_val)
                events.append(
                    TextDeltaEvent(block_index=self._block_index, delta=text_val)
                )
            if isinstance(sig, str) and sig:
                self._text_signature = sig

            self._append_or_merge_raw_part(part)
            return events

        # Case 5: Binary multimodal output parts carried by `inlineData`.
        if is_audio_part:
            # TTS audio chunks: synthesize the audio_start/delta/stop
            # lifecycle (FR-STATE-09). Consecutive same-mime chunks merge
            # into one audio block; a mime change closes and reopens it.
            events.extend(self._close_current_open_stage())
            assert isinstance(inline_obj, Mapping)
            mime = str(inline_obj.get("mimeType", ""))
            data = str(inline_obj.get("data", ""))
            if self._audio_open and self._audio_mimeType != mime:
                events.extend(self._close_audio_stage())
            if not self._audio_open:
                self._audio_open = True
                self._audio_mimeType = mime
                self._audio_base64_parts = []
                self._audio_block_index = self._block_index
                self._block_index += 1
                events.append(
                    AudioStartEvent(
                        block_index=self._audio_block_index, mime_type=mime
                    )
                )
            self._audio_base64_parts.append(data)
            events.append(
                AudioDeltaEvent(
                    block_index=self._audio_block_index,
                    audio_delta=data,
                    mime_type=mime,
                )
            )
            self._raw_parts.append(copy.deepcopy(part))
            return events

        # Non-audio binary output (e.g. generated images): no dedicated
        # lifecycle events yet; keep the part verbatim for replay fidelity.
        events.extend(self._close_current_open_stage())
        self._raw_parts.append(copy.deepcopy(part))
        return events

    def _close_audio_stage(self) -> list[LLMStreamEvent[GeminiPart, GeminiContent]]:
        if not self._audio_open:
            return []
        stop = AudioStopEvent(
            block_index=self._audio_block_index,
            mime_type=self._audio_mimeType or "",
            total_base64_length=sum(len(p) for p in self._audio_base64_parts),
        )
        self._audio_open = False
        self._audio_mimeType = None
        self._audio_base64_parts = []
        return [stop]

    def _close_current_open_stage(
        self,
    ) -> list[LLMStreamEvent[GeminiPart, GeminiContent]]:
        events: list[LLMStreamEvent[GeminiPart, GeminiContent]] = []
        if self._current_open_stage == "THINKING":
            full_thinking = "".join(self._thinking_buffer)
            raw_item: GeminiPart = {"thought": True, "text": full_thinking}
            if self._thinking_signature:
                raw_item["thoughtSignature"] = self._thinking_signature
            events.append(
                ThinkingStopEvent(
                    block_index=self._block_index,
                    text=full_thinking,
                    signature=self._thinking_signature,
                    raw_item=raw_item,
                )
            )
            self._block_index += 1
            self._current_open_stage = "NONE"
            self._thinking_buffer = []
            self._thinking_signature = None

        elif self._current_open_stage == "TEXT":
            full_text = "".join(self._text_buffer)
            raw_item = {"text": full_text}
            if self._text_signature:
                raw_item["thoughtSignature"] = self._text_signature
            events.append(
                TextStopEvent(
                    block_index=self._block_index,
                    text=full_text,
                    raw_item=raw_item,
                )
            )
            self._block_index += 1
            self._current_open_stage = "NONE"
            self._text_buffer = []
            self._text_signature = None

        return events

    def _append_or_merge_raw_part(self, incoming_part: GeminiPart) -> None:
        if not self._raw_parts:
            self._raw_parts.append(copy.deepcopy(incoming_part))
            return

        last = self._raw_parts[-1]
        is_incoming_thought = bool(incoming_part.get("thought") is True)
        is_last_thought = bool(last.get("thought") is True)

        if (
            "text" in incoming_part
            and "text" in last
            and is_incoming_thought == is_last_thought
            and "functionCall" not in incoming_part
            and "functionCall" not in last
        ):
            last["text"] = str(last.get("text", "")) + str(
                incoming_part.get("text", "")
            )
            if incoming_part.get("thoughtSignature"):
                last["thoughtSignature"] = incoming_part["thoughtSignature"]
        else:
            self._raw_parts.append(copy.deepcopy(incoming_part))

    @staticmethod
    def _safe_usage_int(value: Any) -> int:
        # Defensive: usage fields are numbers per spec, but a null from a
        # misbehaving gateway must not raise a bare TypeError.
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return 0
        return int(value)

    def _build_token_usage(self) -> TokenUsage:
        inp = self._safe_usage_int(self._usage_meta_dict.get("promptTokenCount", 0))
        out = self._safe_usage_int(
            self._usage_meta_dict.get("candidatesTokenCount", 0)
        )
        thoughts = self._safe_usage_int(
            self._usage_meta_dict.get("thoughtsTokenCount", 0)
        )
        cached = self._safe_usage_int(
            self._usage_meta_dict.get("cachedContentTokenCount", 0)
        )
        # Per docs/GEMINI_STREAM_GENERATE_CONTENT_API.md Section 3.3:
        # totalTokenCount = promptTokenCount + candidatesTokenCount + thoughtsTokenCount
        tot = self._safe_usage_int(
            self._usage_meta_dict.get("totalTokenCount", inp + out + thoughts)
        )
        raw_copy = dict(self._usage_meta_dict)
        if self._grounding_metadata is not None:
            raw_copy["groundingMetadata"] = self._grounding_metadata
        if self._url_context_metadata is not None:
            raw_copy["urlContextMetadata"] = self._url_context_metadata
        if self._safety_ratings is not None:
            raw_copy["safetyRatings"] = self._safety_ratings
        if self._citation_metadata is not None:
            raw_copy["citationMetadata"] = self._citation_metadata
        if self._logprobs_result is not None:
            raw_copy["logprobsResult"] = self._logprobs_result
        if self._prompt_feedback is not None:
            raw_copy["promptFeedback"] = self._prompt_feedback

        return TokenUsage(
            input_tokens=inp,
            output_tokens=out,
            reasoning_tokens=thoughts,
            cache_read_input_tokens=cached,
            total_tokens=tot,
            raw_usage=raw_copy,
        )


class GeminiStreamClient(
    BaseProtocolClient[GeminiStreamRequest, GeminiPart, GeminiContent]
):
    """
    Dedicated client for Google Gemini `POST /v1beta/models/{model}:streamGenerateContent?alt=sse`
    (FR-PROTO-03).
    """

    def __init__(
        self,
        config: ClientConfig,
        transport: Optional[AsyncHttpTransport] = None,
        backoff_strategy: Optional[BackoffStrategy] = None,
    ) -> None:
        super().__init__(
            config=config,
            transport=transport,
            backoff_strategy=backoff_strategy,
        )

    @property
    def provider_name(self) -> ProviderName:
        return "gemini"

    def _build_url_and_headers(
        self,
        request: GeminiStreamRequest,
        options: RequestOptions,
    ) -> tuple[str, dict[str, str]]:
        base = (self._config.base_url or DEFAULT_GEMINI_BASE_URL).rstrip("/")
        model_id = request.model
        if model_id.startswith("models/"):
            model_path = model_id
        else:
            model_path = f"models/{model_id}"
        # Path segments must be percent-encoded (e.g. models with ':' or '/').
        model_path = "/".join(quote(seg, safe="") for seg in model_path.split("/"))
        url = f"{base}/{model_path}:streamGenerateContent?alt=sse"

        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "x-goog-api-key": self._config.api_key,
        }
        for k, v in self._config.custom_headers.items():
            headers[k] = v
        if options.custom_headers:
            for k, v in options.custom_headers.items():
                headers[k] = v
        return url, headers

    def _serialize_request_to_root_dict(
        self,
        request: GeminiStreamRequest,
        options: RequestOptions,
    ) -> dict[str, Any]:
        root: dict[str, Any] = {
            "contents": to_serializable_dict(request.contents),
        }
        optional_fields = (
            "systemInstruction",
            "tools",
            "toolConfig",
            "safetySettings",
            "generationConfig",
            "cachedContent",
            "labels",
        )
        for field_name in optional_fields:
            val = getattr(request, field_name)
            if val is not None:
                root[field_name] = to_serializable_dict(val)

        if request.extra_fields:
            for k, v in request.extra_fields.items():
                root[k] = to_serializable_dict(v)

        return root

    def _create_state_machine(
        self,
        request: GeminiStreamRequest,
    ) -> ProtocolStreamStateMachine[GeminiPart, GeminiContent]:
        return GeminiStreamStateMachine(requested_model=request.model)
