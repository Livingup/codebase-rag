from __future__ import annotations

from typing import Any, Literal, Mapping, Optional, Sequence, TypedDict

from .base_client import ClientConfig, RequestOptions
from .errors import ErrorKind, LLMClientError
from .json_api_client import BaseJsonApiClient
from .retry import BackoffStrategy
from .transport import AsyncHttpTransport

DEFAULT_DASHSCOPE_EMBEDDING_BASE_URL = "https://dashscope.aliyuncs.com"

# POST https://dashscope.aliyuncs.com/api/v1/services/embeddings/text-embedding/text-embedding
DASHSCOPE_TEXT_EMBEDDING_PATH = (
    "/api/v1/services/embeddings/text-embedding/text-embedding"
)

# text-embedding-v4: 单次请求最多 10 条文本
DASHSCOPE_EMBEDDING_MAX_BATCH_SIZE = 10
DASHSCOPE_EMBEDDING_MAX_DIMENSION = 2048

DashScopeTextType = Literal["document", "query"]

DASHSCOPE_TEXT_TYPES: frozenset[str] = frozenset({"document", "query"})


# Wire-level types, snake_case to mirror the response exactly.


class DashScopeSparseEmbeddingEntry(TypedDict, total=False):
    index: int
    value: float
    token: str


class DashScopeEmbeddingItem(TypedDict, total=False):
    text_index: int
    sparse_embedding: list[DashScopeSparseEmbeddingEntry]
    # dense 模式下由服务端返回，这里保留原始字段以维持 wire 保真
    embedding: list[float]


class DashScopeEmbeddingOutput(TypedDict, total=False):
    embeddings: list[DashScopeEmbeddingItem]


class DashScopeEmbeddingUsage(TypedDict, total=False):
    total_tokens: int


class DashScopeSparseEmbeddingResponse(TypedDict, total=False):
    output: DashScopeEmbeddingOutput
    usage: DashScopeEmbeddingUsage
    request_id: str
    code: str
    message: str


class DashScopeSparseVector(TypedDict):
    """Normalized sparse vector: 按位置一一对应的 index/value 数组。"""

    indices: list[int]
    values: list[float]


def _bad_request(message: str) -> LLMClientError:
    return LLMClientError(
        kind=ErrorKind.BAD_REQUEST,
        message=message,
        is_retryable=False,
        attempt=0,
    )


class DashScopeSparseEmbeddingClient(BaseJsonApiClient):
    """
    Client for DashScope `text-embedding-v4` with `output_type=sparse`
    (BM25 风格稀疏向量，用于关键词/混合检索)。

    请求体固定为::

        {
          "model": "text-embedding-v4",
          "input": {"texts": [...]},
          "parameters": {"text_type": "document"|"query",
                         "dimension": 2048,
                         "output_type": "sparse"}
        }

    `base_url` 既可以指向服务根地址（默认补全标准端点路径），
    也可以直接给到完整端点（此时不再追加路径）。
    参数在本地校验（非空文本、批量上限、text_type 枚举、dimension 范围），
    400 直接抛出不可重试的 BAD_REQUEST；429/5xx 由 RetryPolicy 自动重试。
    """

    def __init__(
        self,
        config: ClientConfig,
        model: str = "text-embedding-v4",
        *,
        dimension: int = DASHSCOPE_EMBEDDING_MAX_DIMENSION,
        text_type: DashScopeTextType = "document",
        max_batch_size: int = DASHSCOPE_EMBEDDING_MAX_BATCH_SIZE,
        transport: Optional[AsyncHttpTransport] = None,
        backoff_strategy: Optional[BackoffStrategy] = None,
    ) -> None:
        super().__init__(
            config=config, transport=transport, backoff_strategy=backoff_strategy
        )
        self._model = model
        self._dimension = dimension
        self._text_type: DashScopeTextType = text_type
        self._max_batch_size = max_batch_size

    @property
    def provider_name(self):
        return "dashscope"

    @property
    def max_batch_size(self) -> int:
        return self._max_batch_size

    def _base_url(self) -> str:
        return self._config.base_url or DEFAULT_DASHSCOPE_EMBEDDING_BASE_URL

    def _auth_headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._config.api_key}"}

    def _endpoint_path(self) -> str:
        base = self._base_url().rstrip("/")
        if base.endswith("/text-embedding"):
            return ""
        return DASHSCOPE_TEXT_EMBEDDING_PATH

    # --------------------------------------------------------------- sparse

    async def embed_texts(
        self,
        texts: Sequence[str],
        *,
        text_type: Optional[DashScopeTextType] = None,
        dimension: Optional[int] = None,
        options: Optional[RequestOptions] = None,
    ) -> list[DashScopeSparseVector]:
        """为一批文本生成稀疏向量，返回顺序与入参严格一致。"""
        if isinstance(texts, str) or not isinstance(texts, (list, tuple)):
            raise _bad_request("texts must be a non-empty sequence of strings")
        if not texts:
            raise _bad_request("texts must be a non-empty sequence of strings")
        if len(texts) > self._max_batch_size:
            raise _bad_request(
                f"batch size must not exceed {self._max_batch_size}"
            )
        for idx, text in enumerate(texts):
            if not isinstance(text, str) or text == "":
                raise _bad_request(f"texts[{idx}] must be a non-empty string")

        effective_text_type = text_type or self._text_type
        if effective_text_type not in DASHSCOPE_TEXT_TYPES:
            raise _bad_request(
                f"text_type must be one of {sorted(DASHSCOPE_TEXT_TYPES)}"
            )

        effective_dimension = self._dimension if dimension is None else dimension
        if not isinstance(effective_dimension, int) or not (
            1 <= effective_dimension <= DASHSCOPE_EMBEDDING_MAX_DIMENSION
        ):
            raise _bad_request(
                f"dimension must be an integer in 1..{DASHSCOPE_EMBEDDING_MAX_DIMENSION}"
            )

        body: dict[str, Any] = {
            "model": self._model,
            "input": {"texts": list(texts)},
            "parameters": {
                "text_type": effective_text_type,
                "dimension": effective_dimension,
                "output_type": "sparse",
            },
        }

        payload = await self.post_json(self._endpoint_path(), body, options=options)
        self._raise_for_api_code(payload)

        output = payload.get("output")
        embeddings = output.get("embeddings") if isinstance(output, Mapping) else None
        if not isinstance(embeddings, list) or len(embeddings) != len(texts):
            raise LLMClientError(
                kind=ErrorKind.PROTOCOL_ERROR,
                message=(
                    "Embedding response must contain output.embeddings[] "
                    "aligned with the request order/length"
                ),
                is_retryable=False,
                attempt=0,
                raw_body=str(payload)[:2000],
            )

        ordered = sorted(
            embeddings,
            key=lambda item: item.get("text_index", 0)
            if isinstance(item, Mapping)
            else 0,
        )
        return [self._normalize_sparse_vector(item, idx) for idx, item in enumerate(ordered)]

    async def embed_query(
        self,
        texts: Sequence[str],
        *,
        dimension: Optional[int] = None,
        options: Optional[RequestOptions] = None,
    ) -> list[DashScopeSparseVector]:
        """按 `text_type=query` 生成检索查询侧的稀疏向量。"""
        return await self.embed_texts(
            texts,
            text_type="query",
            dimension=dimension,
            options=options,
        )

    # ------------------------------------------------------------- internal

    @staticmethod
    def _raise_for_api_code(payload: Mapping[str, Any]) -> None:
        code = payload.get("code")
        if not code:
            return
        raise LLMClientError(
            kind=ErrorKind.BAD_REQUEST,
            message=f"DashScope API error: code={code}, message={payload.get('message')}",
            is_retryable=False,
            attempt=0,
            provider_error_code=str(code),
            raw_body=str(payload)[:2000],
        )

    @staticmethod
    def _normalize_sparse_vector(
        item: Any,
        position: int,
    ) -> DashScopeSparseVector:
        if not isinstance(item, Mapping):
            raise LLMClientError(
                kind=ErrorKind.PROTOCOL_ERROR,
                message=f"output.embeddings[{position}] must be an object",
                is_retryable=False,
                attempt=0,
            )
        entries = item.get("sparse_embedding")
        if not isinstance(entries, list) or not entries:
            raise LLMClientError(
                kind=ErrorKind.PROTOCOL_ERROR,
                message=(
                    f"output.embeddings[{position}].sparse_embedding must be a "
                    "non-empty array (did the request ask for output_type=sparse?)"
                ),
                is_retryable=False,
                attempt=0,
            )
        indices: list[int] = []
        values: list[float] = []
        for entry_idx, entry in enumerate(entries):
            if not isinstance(entry, Mapping):
                raise LLMClientError(
                    kind=ErrorKind.PROTOCOL_ERROR,
                    message=(
                        f"output.embeddings[{position}].sparse_embedding[{entry_idx}] "
                        "must be an object"
                    ),
                    is_retryable=False,
                    attempt=0,
                )
            index = entry.get("index")
            value = entry.get("value")
            if not isinstance(index, int) or isinstance(index, bool):
                raise LLMClientError(
                    kind=ErrorKind.PROTOCOL_ERROR,
                    message=(
                        f"output.embeddings[{position}].sparse_embedding[{entry_idx}].index "
                        "must be an integer"
                    ),
                    is_retryable=False,
                    attempt=0,
                )
            if not isinstance(value, (int, float)) or isinstance(value, bool):
                raise LLMClientError(
                    kind=ErrorKind.PROTOCOL_ERROR,
                    message=(
                        f"output.embeddings[{position}].sparse_embedding[{entry_idx}].value "
                        "must be a number"
                    ),
                    is_retryable=False,
                    attempt=0,
                )
            indices.append(index)
            values.append(float(value))
        return {"indices": indices, "values": values}
