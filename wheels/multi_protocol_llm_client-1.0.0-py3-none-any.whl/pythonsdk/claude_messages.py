from __future__ import annotations

import copy
import json
from dataclasses import dataclass, field
from typing import Any, Literal, Mapping, Optional, Sequence, TypedDict, Union

from .base_client import (
    BaseProtocolClient,
    ClientConfig,
    ProtocolStreamStateMachine,
    RequestOptions,
    to_serializable_dict,
)
from .errors import ErrorKind, LLMClientError
from .events import (
    LLMStreamEvent,
    ResponseCompleteEvent,
    ResponseStartEvent,
    ServerToolDeltaEvent,
    ServerToolStartEvent,
    ServerToolStopEvent,
    TextDeltaEvent,
    TextStartEvent,
    TextStopEvent,
    ThinkingDeltaEvent,
    ThinkingStartEvent,
    ThinkingStopEvent,
    TokenUsage,
    ToolCallDeltaEvent,
    ToolCallStartEvent,
    ToolCallStopEvent,
)
from .inspector import ProviderName
from .json_api_client import BaseJsonApiClient
from .retry import BackoffStrategy
from .sse import SseEventFrame
from .transport import AsyncHttpTransport

DEFAULT_CLAUDE_BASE_URL = "https://api.anthropic.com/v1"
DEFAULT_ANTHROPIC_VERSION = "2023-06-01"

# ============================================================================
# 1. Cache Control & Citation Location Types (docs/CLAUDE_MESSAGES_API.md Section 6.1)
# ============================================================================


class CacheControlEphemeral(TypedDict, total=False):
    type: Literal["ephemeral"]
    ttl: Literal["5m", "1h"]


class CharLocationCitation(TypedDict, total=False):
    type: Literal["char_location"]
    cited_text: str
    document_index: int
    document_title: Optional[str]
    start_char_index: int
    end_char_index: int


class PageLocationCitation(TypedDict, total=False):
    type: Literal["page_location"]
    cited_text: str
    document_index: int
    document_title: Optional[str]
    start_page_number: int
    end_page_number: int


class ContentBlockLocationCitation(TypedDict, total=False):
    type: Literal["content_block_location"]
    cited_text: str
    document_index: int
    document_title: Optional[str]
    start_block_index: int
    end_block_index: int


class WebSearchResultLocationCitation(TypedDict, total=False):
    type: Literal["web_search_result_location"]
    cited_text: str
    url: str
    title: Optional[str]
    encrypted_index: str


class SearchResultLocationCitation(TypedDict, total=False):
    type: Literal["search_result_location"]
    cited_text: str
    source: str
    title: Optional[str]
    search_result_index: int
    start_block_index: int
    end_block_index: int


CitationLocation = Union[
    CharLocationCitation,
    PageLocationCitation,
    ContentBlockLocationCitation,
    WebSearchResultLocationCitation,
    SearchResultLocationCitation,
    dict[str, Any],
]


# ============================================================================
# 2. ContentBlockParam (All 13 Variants in docs/CLAUDE_MESSAGES_API.md Section 6.2)
# ============================================================================


class TextBlockParam(TypedDict, total=False):
    type: Literal["text"]
    text: str
    citations: Optional[list[CitationLocation]]
    cache_control: Optional[CacheControlEphemeral]


class Base64ImageSource(TypedDict):
    type: Literal["base64"]
    media_type: Literal["image/jpeg", "image/png", "image/gif", "image/webp"]
    data: str


class UrlImageSource(TypedDict):
    type: Literal["url"]
    url: str


class FileImageSource(TypedDict):
    type: Literal["file"]
    file_id: str


class ImageBlockParam(TypedDict, total=False):
    type: Literal["image"]
    source: Union[Base64ImageSource, UrlImageSource, FileImageSource, dict[str, Any]]
    cache_control: Optional[CacheControlEphemeral]


class Base64PdfSource(TypedDict):
    type: Literal["base64"]
    media_type: Literal["application/pdf"]
    data: str


class UrlPdfSource(TypedDict):
    type: Literal["url"]
    url: str


class PlainTextDocumentSource(TypedDict):
    type: Literal["text"]
    media_type: Literal["text/plain"]
    data: str


class CustomContentDocumentSource(TypedDict):
    type: Literal["content"]
    content: Union[str, list[Union[TextBlockParam, ImageBlockParam, dict[str, Any]]]]


class FileDocumentSource(TypedDict):
    type: Literal["file"]
    file_id: str


class DocumentBlockParam(TypedDict, total=False):
    type: Literal["document"]
    source: Union[
        Base64PdfSource,
        UrlPdfSource,
        PlainTextDocumentSource,
        CustomContentDocumentSource,
        FileDocumentSource,
        dict[str, Any],
    ]
    title: Optional[str]
    context: Optional[str]
    citations: dict[str, bool]
    cache_control: Optional[CacheControlEphemeral]


class SearchResultBlockParam(TypedDict, total=False):
    type: Literal["search_result"]
    source: str
    title: str
    content: list[TextBlockParam]
    citations: dict[str, bool]
    cache_control: Optional[CacheControlEphemeral]


class ToolUseBlockParam(TypedDict, total=False):
    type: Literal["tool_use"]
    id: str
    name: str
    input: dict[str, Any]
    cache_control: Optional[CacheControlEphemeral]


class ToolResultBlockParam(TypedDict, total=False):
    type: Literal["tool_result"]
    tool_use_id: str
    content: Union[
        str,
        list[
            Union[
                TextBlockParam,
                ImageBlockParam,
                DocumentBlockParam,
                SearchResultBlockParam,
                dict[str, Any],
            ]
        ],
    ]
    is_error: bool
    cache_control: Optional[CacheControlEphemeral]


class ThinkingBlockParam(TypedDict):
    type: Literal["thinking"]
    thinking: str
    signature: str


class RedactedThinkingBlockParam(TypedDict):
    type: Literal["redacted_thinking"]
    data: str


class ServerToolUseBlockParam(TypedDict, total=False):
    type: Literal["server_tool_use"]
    id: str
    name: Union[Literal["web_search", "code_execution"], str]
    input: dict[str, Any]
    cache_control: Optional[CacheControlEphemeral]


class WebSearchResultItem(TypedDict, total=False):
    type: Literal["web_search_result"]
    url: str
    title: str
    encrypted_content: str
    page_age: Optional[str]


class WebSearchToolResultError(TypedDict, total=False):
    type: Literal["web_search_tool_result_error"]
    error_code: Union[
        Literal[
            "invalid_tool_input",
            "unavailable",
            "max_uses_exceeded",
            "too_many_requests",
            "query_too_long",
        ],
        str,
    ]


class WebSearchToolResultBlockParam(TypedDict, total=False):
    type: Literal["web_search_tool_result"]
    tool_use_id: str
    content: Union[
        list[Union[WebSearchResultItem, dict[str, Any]]],
        WebSearchToolResultError,
        dict[str, Any],
    ]
    cache_control: Optional[CacheControlEphemeral]


class CodeExecutionOutputItem(TypedDict):
    type: Literal["code_execution_output"]
    file_id: str


class CodeExecutionToolResultContent(TypedDict, total=False):
    type: Union[
        Literal["code_execution_result", "code_execution_tool_result_error"],
        str,
    ]
    stdout: str
    stderr: str
    return_code: int
    content: list[Union[CodeExecutionOutputItem, dict[str, Any]]]
    error_code: str


class CodeExecutionToolResultBlockParam(TypedDict, total=False):
    type: Literal["code_execution_tool_result"]
    tool_use_id: str
    content: Union[CodeExecutionToolResultContent, dict[str, Any]]
    cache_control: Optional[CacheControlEphemeral]


class McpToolUseBlockParam(TypedDict, total=False):
    type: Literal["mcp_tool_use"]
    id: str
    name: str
    server_name: str
    input: dict[str, Any]
    cache_control: Optional[CacheControlEphemeral]


class McpToolResultBlockParam(TypedDict, total=False):
    type: Literal["mcp_tool_result"]
    tool_use_id: str
    is_error: bool
    content: Union[str, list[TextBlockParam]]
    cache_control: Optional[CacheControlEphemeral]


ClaudeContentBlock = Union[
    TextBlockParam,
    ImageBlockParam,
    DocumentBlockParam,
    SearchResultBlockParam,
    ToolUseBlockParam,
    ToolResultBlockParam,
    ThinkingBlockParam,
    RedactedThinkingBlockParam,
    ServerToolUseBlockParam,
    WebSearchToolResultBlockParam,
    CodeExecutionToolResultBlockParam,
    McpToolUseBlockParam,
    McpToolResultBlockParam,
    dict[str, Any],
]


class ClaudeMessageParam(TypedDict):
    role: Literal["user", "assistant"]
    content: Union[str, Sequence[ClaudeContentBlock]]


# ============================================================================
# 3. Tool Definitions, MCP Server & Config Types (docs/CLAUDE_MESSAGES_API.md Section 6.3)
# ============================================================================


class ClaudeCustomToolParam(TypedDict, total=False):
    type: Literal["custom"]
    name: str
    description: str
    input_schema: dict[str, Any]
    cache_control: Optional[CacheControlEphemeral]


class ClaudeWebSearchToolParam(TypedDict, total=False):
    type: Literal["web_search_20250305"]
    name: Literal["web_search"]
    max_uses: int
    allowed_domains: list[str]
    blocked_domains: list[str]
    user_location: dict[str, Any]
    cache_control: Optional[CacheControlEphemeral]


class ClaudeCodeExecutionToolParam(TypedDict, total=False):
    type: Literal["code_execution_20250522", "code_execution_20250825"]
    name: Literal["code_execution"]
    cache_control: Optional[CacheControlEphemeral]


class ClaudeBashToolParam(TypedDict, total=False):
    type: Literal["bash_20250124"]
    name: Literal["bash"]
    cache_control: Optional[CacheControlEphemeral]


class ClaudeTextEditorToolParam(TypedDict, total=False):
    type: Literal[
        "text_editor_20250124", "text_editor_20250429", "text_editor_20250728"
    ]
    name: Literal["str_replace_editor", "str_replace_based_edit_tool"]
    max_characters: int
    cache_control: Optional[CacheControlEphemeral]


class ClaudeComputerUseToolParam(TypedDict, total=False):
    type: Literal["computer_20250124"]
    name: Literal["computer"]
    display_width_px: int
    display_height_px: int
    display_number: int
    cache_control: Optional[CacheControlEphemeral]


ClaudeToolDefinition = Union[
    ClaudeCustomToolParam,
    ClaudeWebSearchToolParam,
    ClaudeCodeExecutionToolParam,
    ClaudeBashToolParam,
    ClaudeTextEditorToolParam,
    ClaudeComputerUseToolParam,
    dict[str, Any],
]


class ClaudeMcpServer(TypedDict, total=False):
    type: Literal["url"]
    url: str
    name: str
    authorization_token: Optional[str]
    tool_configuration: dict[str, Any]


class ClaudeToolChoice(TypedDict, total=False):
    type: Literal["auto", "any", "tool", "none"]
    name: str
    disable_parallel_tool_use: bool


class ClaudeThinkingConfigParam(TypedDict, total=False):
    type: Literal["adaptive", "enabled", "disabled"]
    budget_tokens: int


ClaudeEffortLevel = Literal["low", "medium", "high", "xhigh", "max"]


class ClaudeOutputConfig(TypedDict, total=False):
    effort: ClaudeEffortLevel
    format: dict[str, Any]
    task_budget: int


@dataclass
class ClaudeMessagesRequest:
    """
    Complete, non-simplified native request payload for Anthropic Claude `POST /v1/messages`
    matching every field in `docs/CLAUDE_MESSAGES_API.md` (Section 6.3).
    """

    model: str
    max_tokens: int
    messages: Sequence[Union[ClaudeMessageParam, dict[str, Any]]]
    system: Optional[Union[str, Sequence[Union[TextBlockParam, dict[str, Any]]]]] = None
    thinking: Optional[Union[ClaudeThinkingConfigParam, dict[str, Any]]] = None
    output_config: Optional[Union[ClaudeOutputConfig, dict[str, Any]]] = None
    tools: Optional[Sequence[ClaudeToolDefinition]] = None
    tool_choice: Optional[Union[ClaudeToolChoice, dict[str, Any]]] = None
    mcp_servers: Optional[Sequence[Union[ClaudeMcpServer, dict[str, Any]]]] = None
    container: Optional[str] = None
    stop_sequences: Optional[Sequence[str]] = None
    metadata: Optional[Mapping[str, Any]] = None
    service_tier: Optional[Literal["auto", "standard_only"]] = None
    temperature: Optional[float] = None
    top_p: Optional[float] = None
    top_k: Optional[int] = None
    extra_fields: Mapping[str, Any] = field(default_factory=dict)


# ============================================================================
# 4. Response & Raw SSE Event Types (docs/CLAUDE_MESSAGES_API.md Section 6.4)
# ============================================================================

ClaudeStopReason = Literal[
    "end_turn",
    "max_tokens",
    "stop_sequence",
    "tool_use",
    "pause_turn",
    "refusal",
]


class ClaudeUsage(TypedDict, total=False):
    input_tokens: int
    cache_creation_input_tokens: Optional[int]
    cache_read_input_tokens: Optional[int]
    output_tokens: int
    server_tool_use: dict[str, int]


class ClaudeContainerInfo(TypedDict):
    id: str
    expires_at: str


class ClaudeMessageResponse(TypedDict, total=False):
    id: str
    type: Literal["message"]
    role: Literal["assistant"]
    model: str
    content: list[ClaudeContentBlock]
    stop_reason: Optional[ClaudeStopReason]
    stop_sequence: Optional[str]
    usage: ClaudeUsage
    container: Optional[ClaudeContainerInfo]


@dataclass
class _ActiveClaudeBlock:
    index: int
    block_type: str
    raw_block: dict[str, Any]
    text_parts: list[str] = field(default_factory=list)
    thinking_parts: list[str] = field(default_factory=list)
    signature_parts: list[str] = field(default_factory=list)
    json_parts: list[str] = field(default_factory=list)
    citations: list[dict[str, Any]] = field(default_factory=list)


class ClaudeMessagesStateMachine(
    ProtocolStreamStateMachine[ClaudeContentBlock, list[ClaudeContentBlock]]
):
    """
    State Pattern implementation mapping Claude `/v1/messages` SSE frames
    (`message_start`, `content_block_start`, `content_block_delta`, `content_block_stop`,
    `message_delta`, `message_stop`, `ping`, `error`) to unified `LLMStreamEvent` objects (Section 5.4.2).
    """

    def __init__(self) -> None:
        self._message_id: str = ""
        self._model: str = ""
        # Server-reported stop reason. None until message_delta actually
        # delivers one — the SDK never fabricates a reason it was not told.
        self._stop_reason: Optional[str] = None
        self._stop_sequence: Optional[str] = None
        self._container_info: Optional[dict[str, Any]] = None
        self._active_blocks: dict[int, _ActiveClaudeBlock] = {}
        self._completed_blocks: list[ClaudeContentBlock] = []
        self._usage_dict: dict[str, Any] = {}
        self._emitted_complete: bool = False
        self._saw_message_stop: bool = False

    def process_frame(
        self,
        frame: SseEventFrame,
        trace_id: str,
        attempt: int,
    ) -> list[LLMStreamEvent[ClaudeContentBlock, list[ClaudeContentBlock]]]:
        raw_data = frame.data.strip()
        if not raw_data:
            return []

        event_name = frame.event or ""
        if event_name == "ping":
            return []

        try:
            payload: dict[str, Any] = json.loads(raw_data)
        except Exception as exc:
            raise LLMClientError(
                kind=ErrorKind.PROTOCOL_ERROR,
                message=f"Failed to parse Claude SSE JSON frame: {exc}",
                is_retryable=False,
                attempt=attempt,
                raw_body=raw_data,
                cause=exc,
            ) from exc

        event_type = event_name or str(payload.get("type", ""))
        if event_type == "ping":
            return []

        events: list[LLMStreamEvent[ClaudeContentBlock, list[ClaudeContentBlock]]] = []

        # 1. message_start -> response_start
        if event_type == "message_start":
            msg = payload.get("message", {})
            self._message_id = str(msg.get("id", ""))
            self._model = str(msg.get("model", ""))
            if isinstance(msg.get("container"), Mapping):
                self._container_info = dict(msg["container"])
            if isinstance(msg.get("usage"), Mapping):
                self._usage_dict.update(msg["usage"])
            events.append(
                ResponseStartEvent(
                    trace_id=trace_id,
                    attempt=attempt,
                    response_id=self._message_id,
                    model=self._model,
                )
            )
            return events

        # 2. content_block_start -> immediate stage start event
        if event_type == "content_block_start":
            idx = int(payload.get("index", 0))
            cblock: dict[str, Any] = copy.deepcopy(payload.get("content_block", {}))
            btype = str(cblock.get("type", ""))

            active = _ActiveClaudeBlock(
                index=idx,
                block_type=btype,
                raw_block=cblock,
            )
            if btype == "thinking" and cblock.get("thinking"):
                active.thinking_parts.append(str(cblock["thinking"]))
            if btype == "text" and cblock.get("text"):
                active.text_parts.append(str(cblock["text"]))
            self._active_blocks[idx] = active

            if btype in ("thinking", "redacted_thinking"):
                events.append(ThinkingStartEvent(block_index=idx))
            elif btype == "text":
                events.append(TextStartEvent(block_index=idx))
            elif btype == "tool_use":
                # FR-STATE-06: Immediate tool_call_start notification upon content_block_start
                call_id = str(cblock.get("id", f"toolu_{idx}"))
                name = str(cblock.get("name", ""))
                events.append(
                    ToolCallStartEvent(
                        block_index=idx,
                        call_id=call_id,
                        name=name,
                        tool_type="function",
                    )
                )
            elif btype in (
                "server_tool_use",
                "mcp_tool_use",
                "web_search_tool_result",
                "code_execution_tool_result",
                "mcp_tool_result",
            ):
                item_id = str(
                    cblock.get("id") or cblock.get("tool_use_id") or f"srv_{idx}"
                )
                tool_name = str(cblock.get("name") or btype)
                events.append(
                    ServerToolStartEvent(
                        block_index=idx,
                        item_id=item_id,
                        tool_name=tool_name,
                    )
                )
            return events

        # 3. content_block_delta -> incremental deltas
        if event_type == "content_block_delta":
            idx = int(payload.get("index", 0))
            delta_obj = payload.get("delta", {})
            dtype = str(delta_obj.get("type", ""))
            active = self._active_blocks.get(idx)
            if active is None:
                return events

            if dtype == "thinking_delta":
                chunk = str(delta_obj.get("thinking", ""))
                if chunk:
                    active.thinking_parts.append(chunk)
                    events.append(ThinkingDeltaEvent(block_index=idx, delta=chunk))
            elif dtype == "signature_delta":
                sig_chunk = str(delta_obj.get("signature", ""))
                if sig_chunk:
                    active.signature_parts.append(sig_chunk)
            elif dtype == "text_delta":
                txt_chunk = str(delta_obj.get("text", ""))
                if txt_chunk:
                    active.text_parts.append(txt_chunk)
                    events.append(TextDeltaEvent(block_index=idx, delta=txt_chunk))
            elif dtype == "citations_delta":
                cit = delta_obj.get("citation")
                if isinstance(cit, Mapping):
                    active.citations.append(dict(cit))
            elif dtype == "input_json_delta":
                partial_json = str(delta_obj.get("partial_json", ""))
                if partial_json:
                    active.json_parts.append(partial_json)
                    if active.block_type == "tool_use":
                        call_id = str(active.raw_block.get("id", f"toolu_{idx}"))
                        events.append(
                            ToolCallDeltaEvent(
                                block_index=idx,
                                call_id=call_id,
                                arguments_delta=partial_json,
                            )
                        )
                    else:
                        item_id = str(active.raw_block.get("id", f"srv_{idx}"))
                        events.append(
                            ServerToolDeltaEvent(
                                block_index=idx,
                                item_id=item_id,
                                delta_type="input_json_delta",
                                delta_payload=partial_json,
                            )
                        )
            return events

        # 4. content_block_stop -> finalize block and emit *_stop event
        if event_type == "content_block_stop":
            idx = int(payload.get("index", 0))
            active = self._active_blocks.pop(idx, None)
            if active is None:
                return events

            btype = active.block_type
            final_block = copy.deepcopy(active.raw_block)

            if btype == "thinking":
                full_thinking = "".join(active.thinking_parts)
                full_signature = "".join(active.signature_parts) or final_block.get(
                    "signature"
                )
                final_block["thinking"] = full_thinking
                if full_signature:
                    final_block["signature"] = full_signature
                self._completed_blocks.append(final_block)
                events.append(
                    ThinkingStopEvent(
                        block_index=idx,
                        text=full_thinking,
                        signature=str(full_signature) if full_signature else None,
                        raw_item=final_block,
                    )
                )
            elif btype == "redacted_thinking":
                redacted_data = str(final_block.get("data", ""))
                self._completed_blocks.append(final_block)
                events.append(
                    ThinkingStopEvent(
                        block_index=idx,
                        text="",
                        redacted_data=redacted_data,
                        raw_item=final_block,
                    )
                )
            elif btype == "text":
                full_text = "".join(active.text_parts)
                final_block["text"] = full_text
                if active.citations:
                    final_block["citations"] = list(active.citations)
                self._completed_blocks.append(final_block)
                events.append(
                    TextStopEvent(
                        block_index=idx,
                        text=full_text,
                        raw_item=final_block,
                    )
                )
            elif btype == "tool_use":
                call_id = str(final_block.get("id", f"toolu_{idx}"))
                name = str(final_block.get("name", ""))
                args_raw = "".join(active.json_parts)
                if args_raw:
                    try:
                        final_block["input"] = json.loads(args_raw)
                    except Exception as exc:
                        # A tool_use whose accumulated partial_json deltas do
                        # not form valid JSON means the stream was corrupted or
                        # truncated. Replaying a tool_use with silently emptied
                        # input into the next turn would corrupt agent state.
                        raise LLMClientError(
                            kind=ErrorKind.PROTOCOL_ERROR,
                            message=(
                                f"tool_use '{name}' arguments are not valid "
                                f"JSON: {exc}"
                            ),
                            is_retryable=False,
                            attempt=attempt,
                            raw_body=args_raw,
                            cause=exc,
                        ) from exc
                elif "input" not in final_block:
                    final_block["input"] = {}
                else:
                    args_raw = json.dumps(final_block["input"], ensure_ascii=False)

                self._completed_blocks.append(final_block)
                events.append(
                    ToolCallStopEvent(
                        block_index=idx,
                        call_id=call_id,
                        name=name,
                        arguments_raw=args_raw or "{}",
                        raw_item=final_block,
                    )
                )
            else:
                # Server-side tool use or result block
                if active.json_parts:
                    raw_srv_json = "".join(active.json_parts)
                    try:
                        final_block["input"] = json.loads(raw_srv_json)
                    except Exception:
                        pass
                item_id = str(
                    final_block.get("id")
                    or final_block.get("tool_use_id")
                    or f"srv_{idx}"
                )
                tool_name = str(final_block.get("name") or btype)
                self._completed_blocks.append(final_block)
                events.append(
                    ServerToolStopEvent(
                        block_index=idx,
                        item_id=item_id,
                        tool_name=tool_name,
                        raw_item=final_block,
                    )
                )
            return events

        # 5. message_delta -> update stop_reason, stop_sequence, container, and cumulative usage
        if event_type == "message_delta":
            delta_obj = payload.get("delta", {})
            if delta_obj.get("stop_reason"):
                self._stop_reason = str(delta_obj["stop_reason"])
            if "stop_sequence" in delta_obj and delta_obj["stop_sequence"] is not None:
                self._stop_sequence = str(delta_obj["stop_sequence"])
            if isinstance(delta_obj.get("container"), Mapping):
                self._container_info = dict(delta_obj["container"])
            if isinstance(payload.get("usage"), Mapping):
                self._usage_dict.update(payload["usage"])
            return events

        # 6. message_stop -> response_complete
        if event_type == "message_stop":
            self._saw_message_stop = True
            self._emitted_complete = True
            events.append(
                ResponseCompleteEvent(
                    response_id=self._message_id,
                    stop_reason=self._stop_reason,
                    usage=self._build_token_usage(),
                    output=list(self._completed_blocks),
                )
            )
            return events

        # 7. error -> raise LLMClientError
        if event_type == "error":
            err_obj = payload.get("error", {})
            err_type = str(err_obj.get("type", "api_error"))
            err_msg = str(err_obj.get("message", "Claude stream error"))
            if err_type == "overloaded_error":
                kind = ErrorKind.OVERLOADED
                is_retryable = True
            elif err_type == "rate_limit_error":
                kind = ErrorKind.RATE_LIMIT
                is_retryable = True
            elif err_type == "api_error":
                kind = ErrorKind.SERVER_ERROR
                is_retryable = True
            elif err_type in ("authentication_error", "permission_error"):
                kind = ErrorKind.AUTH_ERROR
                is_retryable = False
            elif err_type in (
                "invalid_request_error",
                "not_found_error",
                "request_too_large",
            ):
                kind = ErrorKind.BAD_REQUEST
                is_retryable = False
            else:
                kind = ErrorKind.BAD_REQUEST
                is_retryable = False

            raise LLMClientError(
                kind=kind,
                message=err_msg,
                is_retryable=is_retryable,
                attempt=attempt,
                provider_error_code=err_type,
                raw_body=raw_data,
            )

        return events

    def finish_stream(
        self,
        trace_id: str,
        attempt: int,
    ) -> list[LLMStreamEvent[ClaudeContentBlock, list[ClaudeContentBlock]]]:
        if self._emitted_complete:
            return []
        self._emitted_complete = True
        if not self._saw_message_stop:
            # A clean EOF without `message_stop` means the SSE stream was
            # truncated (e.g. proxy closed the exchange early). Fabricating a
            # successful response_complete would hand the upstream a partial
            # output list that breaks the next stateless turn.
            raise LLMClientError(
                kind=ErrorKind.PROTOCOL_ERROR,
                message="SSE stream ended without a message_stop event",
                is_retryable=False,
                attempt=attempt,
            )
        return []

    @staticmethod
    def _safe_usage_int(value: Any) -> int:
        # Defensive: usage fields are numbers per spec, but a null from a
        # misbehaving gateway must not raise a bare TypeError.
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            return 0
        return int(value)

    def _build_token_usage(self) -> TokenUsage:
        inp = self._safe_usage_int(self._usage_dict.get("input_tokens", 0))
        out = self._safe_usage_int(self._usage_dict.get("output_tokens", 0))
        cache_read = self._safe_usage_int(
            self._usage_dict.get("cache_read_input_tokens", 0)
        )
        cache_create = self._safe_usage_int(
            self._usage_dict.get("cache_creation_input_tokens", 0)
        )
        # raw_usage mirrors the native usage object only; stop_sequence and
        # container belong to the message envelope, not to usage.
        return TokenUsage(
            input_tokens=inp,
            output_tokens=out,
            cache_read_input_tokens=cache_read,
            cache_creation_input_tokens=cache_create,
            total_tokens=inp + out + cache_read + cache_create,
            raw_usage=dict(self._usage_dict),
        )


class ClaudeMessagesClient(
    BaseProtocolClient[
        ClaudeMessagesRequest,
        ClaudeContentBlock,
        list[ClaudeContentBlock],
    ]
):
    """
    Dedicated client for Anthropic Claude `POST /v1/messages` (FR-PROTO-02).
    Defaults to `anthropic-version: 2023-06-01` and sends both `x-api-key` and
    `Authorization: Bearer` headers for universal compatibility across official
    Anthropic endpoints and proxy gateways (docs/CLAUDE_MESSAGES_API.md Section 7).
    """

    def __init__(
        self,
        config: ClientConfig,
        anthropic_version: str = DEFAULT_ANTHROPIC_VERSION,
        anthropic_beta: Optional[Sequence[str]] = None,
        transport: Optional[AsyncHttpTransport] = None,
        backoff_strategy: Optional[BackoffStrategy] = None,
    ) -> None:
        super().__init__(
            config=config,
            transport=transport,
            backoff_strategy=backoff_strategy,
        )
        self._anthropic_version = anthropic_version
        self._anthropic_beta = list(anthropic_beta) if anthropic_beta else []

    @property
    def provider_name(self) -> ProviderName:
        return "claude"

    def _effective_anthropic_version(self, options: RequestOptions) -> str:
        """
        Resolves the anthropic-version that will actually be sent: request-level
        custom headers override client-level ones, which override the constructor
        default. Version-dependent body transforms (e.g. stripping deprecated
        sampling params on 2026-10-21) must follow this effective version, or
        the header and the body would disagree and the server would reject the
        request with 400.
        """
        merged_lower: dict[str, str] = {
            k.lower(): v for k, v in self._config.custom_headers.items()
        }
        if options.custom_headers:
            merged_lower.update(
                {k.lower(): v for k, v in options.custom_headers.items()}
            )
        override = merged_lower.get("anthropic-version")
        return str(override) if override else self._anthropic_version

    def _build_url_and_headers(
        self,
        request: ClaudeMessagesRequest,
        options: RequestOptions,
    ) -> tuple[str, dict[str, str]]:
        base = (self._config.base_url or DEFAULT_CLAUDE_BASE_URL).rstrip("/")
        url = f"{base}/messages"
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
            "x-api-key": self._config.api_key,
            "Authorization": f"Bearer {self._config.api_key}",
            "anthropic-version": self._effective_anthropic_version(options),
        }
        if self._anthropic_beta:
            headers["anthropic-beta"] = ",".join(self._anthropic_beta)

        for k, v in self._config.custom_headers.items():
            headers[k] = v
        if options.custom_headers:
            for k, v in options.custom_headers.items():
                headers[k] = v
        return url, headers

    def _serialize_request_to_root_dict(
        self,
        request: ClaudeMessagesRequest,
        options: RequestOptions,
    ) -> dict[str, Any]:
        root: dict[str, Any] = {
            "model": request.model,
            "max_tokens": request.max_tokens,
            "messages": to_serializable_dict(request.messages),
            "stream": True,
        }
        optional_fields = (
            "system",
            "thinking",
            "output_config",
            "tools",
            "tool_choice",
            "mcp_servers",
            "container",
            "stop_sequences",
            "metadata",
            "service_tier",
            "temperature",
            "top_p",
            "top_k",
        )
        for field_name in optional_fields:
            val = getattr(request, field_name)
            if val is not None:
                root[field_name] = to_serializable_dict(val)

        # Defensive cleanup per docs/CLAUDE_MESSAGES_API.md Section 7:
        # When the *effective* anthropic-version >= '2026-10-21' (including a
        # request-level header override), strip deprecated sampling params.
        if self._effective_anthropic_version(options) >= "2026-10-21":
            root.pop("temperature", None)
            root.pop("top_p", None)
            root.pop("top_k", None)

        if request.extra_fields:
            for k, v in request.extra_fields.items():
                root[k] = to_serializable_dict(v)

        return root

    def _create_state_machine(
        self,
        request: ClaudeMessagesRequest,
    ) -> ProtocolStreamStateMachine[ClaudeContentBlock, list[ClaudeContentBlock]]:
        return ClaudeMessagesStateMachine()


class ClaudeCountTokensRequest(TypedDict, total=False):
    model: str
    messages: list[Union[ClaudeMessageParam, dict[str, Any]]]
    system: Union[str, Sequence[Union[TextBlockParam, dict[str, Any]]]]
    tools: list[ClaudeToolDefinition]
    thinking: Union[ClaudeThinkingConfigParam, dict[str, Any]]


class ClaudeCountTokensResponse(TypedDict, total=False):
    input_tokens: int


class ClaudeCountTokensClient(BaseJsonApiClient):
    """
    Client for Anthropic `POST /v1/messages/count_tokens`
    (docs/CLAUDE_MESSAGES_API.md), the non-streaming JSON sibling of
    `/v1/messages`. Shares the SDK transport / retry / error taxonomy.
    """

    def __init__(
        self,
        config: ClientConfig,
        anthropic_version: str = DEFAULT_ANTHROPIC_VERSION,
        anthropic_beta: Optional[Sequence[str]] = None,
        transport: Optional[AsyncHttpTransport] = None,
        backoff_strategy: Optional[BackoffStrategy] = None,
    ) -> None:
        super().__init__(
            config=config, transport=transport, backoff_strategy=backoff_strategy
        )
        self._anthropic_version = anthropic_version
        self._anthropic_beta = list(anthropic_beta) if anthropic_beta else []

    @property
    def provider_name(self) -> ProviderName:
        return "claude"

    def _base_url(self) -> str:
        return self._config.base_url or DEFAULT_CLAUDE_BASE_URL

    def _auth_headers(self) -> dict[str, str]:
        headers = {
            "x-api-key": self._config.api_key,
            "anthropic-version": self._anthropic_version,
        }
        if self._anthropic_beta:
            headers["anthropic-beta"] = ",".join(self._anthropic_beta)
        return headers

    async def count_tokens(
        self,
        request: ClaudeCountTokensRequest,
        *,
        options: Optional[RequestOptions] = None,
    ) -> int:
        """Returns `input_tokens` for one full request payload (no completion)."""
        model = request.get("model")
        if not isinstance(model, str) or model == "":
            raise LLMClientError(
                kind=ErrorKind.BAD_REQUEST,
                message="model must be a non-empty string",
                is_retryable=False,
                attempt=0,
            )
        messages = request.get("messages")
        if not isinstance(messages, (list, tuple)) or not messages:
            raise LLMClientError(
                kind=ErrorKind.BAD_REQUEST,
                message="messages must be a non-empty sequence",
                is_retryable=False,
                attempt=0,
            )

        body: dict[str, Any] = to_serializable_dict(dict(request))
        payload = await self.post_json("/messages/count_tokens", body, options=options)
        total = payload.get("input_tokens")
        if not isinstance(total, int) or isinstance(total, bool) or total < 0:
            raise LLMClientError(
                kind=ErrorKind.PROTOCOL_ERROR,
                message="count_tokens response must contain a non-negative integer input_tokens",
                is_retryable=False,
                attempt=0,
            )
        return total
